# 🏢 Walk The Plan — Enterprise Modular Platform

> **Walk The Plan** is a modular web platform and 1:1 Scale Floor Plan Projection Studio ecosystem, built with completely separated, independent modules for the **Public Website**, **1:1 Projection Studio**, **Admin Dashboard**, and **B2B Sales CRM Portal**.
> Powered by a unified Node.js Express backend and deployed directly to a production VPS with Nginx, PM2, and SSL.

---

## 🏗️ Modular Architecture

Each component of the platform is completely isolated into its own folder with independent dependencies and dev server:

```
walk/
├── backend/            # ⚙️ Unified Express API Server & SQLite DB (Port 5000 / 5001)
│   ├── data/           # Seed blogs and fixtures
│   ├── routes/         # CRM routes, lead parsers, auth
│   ├── server.js       # Main API server
│   └── uploads/        # Uploaded media assets
│
├── website/            # 🌐 Public Customer Marketing Website (Port 5173)
│   ├── src/website/    # Home, About, Services, Franchise, Career, Blog, Gallery, Legal
│   ├── src/shared/     # Navbar, Footer, InstantLeadModal, NotificationPrompt
│   └── vite.config.js  # Base: '/'
│
├── projection/         # 📐 1:1 Scale Architectural Projection Studio (Port 5175)
│   ├── src/            # ProjectionStudio.jsx, CAD calibration, Three.js 3D engine
│   └── vite.config.js  # Base: '/projection/'
│
├── dashboard/          # 📊 Admin Management & Analytics Dashboard (Port 5176)
│   ├── src/pages/      # AdminDashboard.jsx, AdminLogin.jsx, FitscalezAdmin.jsx
│   └── vite.config.js  # Base: '/admin/'
│
├── crm/                # 💼 Dedicated B2B Sales CRM Portal (Port 5174)
│   ├── frontend/src/   # CRMDashboard.jsx, CRMLoginPage.jsx, dialer, audio notes
│   └── frontend/       # Base: '/crm/'
│
├── deploy.js           # 🚀 Automated Zero-Downtime VPS Deployment Script
├── package.json        # Root scripts to build & run all modules
└── README.md           # Documentation
```

---

## 🚀 Local Development

### 1. Install Dependencies
Run once from the root directory:
```bash
npm run install:all
```

### 2. Run All Modules Concurrently
```bash
npm run dev
```

### 3. Run Individual Modules Separately

| Module | Command | Local URL | Description |
| :--- | :--- | :--- | :--- |
| **Backend API** | `npm run server:watch` | `http://localhost:5000/api` | Unified Express Server |
| **Public Website** | `npm run dev:website` | `http://localhost:5173` | Customer Marketing Site |
| **Projection Studio** | `npm run dev:projection` | `http://localhost:5175/projection` | 1:1 Scale Floor Plan Studio |
| **Admin Dashboard** | `npm run dev:dashboard` | `http://localhost:5176/admin` | Management & Settings |
| **CRM Portal** | `npm run dev:crm` | `http://localhost:5174/crm` | Sales Lead Engine & Dialer |

---

## 🔒 Default Credentials

| Portal | URL Path | Username / Email | Password | Role |
| :--- | :--- | :--- | :--- | :--- |
| **Admin Dashboard** | `/admin/login` | `admin` / `fitscalez` | `walk@321` | Master Admin |
| **Sales CRM** | `/crm/login` | `admin@walktheplan.in` | `walk@321` | Super Administrator |

*(Passwords are securely hashed with bcrypt. You can manage roles and users in the CRM and Admin settings.)*

---

## 🌐 Production VPS Infrastructure

The platform runs 100% on a dedicated VPS (`72.61.238.132` / `walktheplan.in`). No Render or Vercel dependencies.

### Production URLs & Nginx Routing

| URL Path | Served From | Description |
| :--- | :--- | :--- |
| `https://walktheplan.in/` | `/var/www/walktheplan.in/website/dist` | Main Public Website |
| `https://walktheplan.in/projection` | `/var/www/walktheplan.in/projection/dist` | 1:1 Projection Studio |
| `https://walktheplan.in/admin` | `/var/www/walktheplan.in/dashboard/dist` | Admin Management Dashboard |
| `https://walktheplan.in/crm` | `/var/www/walktheplan.in/crm/dist` | B2B Sales CRM Portal |
| `https://walktheplan.in/api/` | `http://localhost:5001/api/` | PM2 Unified Backend Service |
| `https://walktheplan.in/uploads/` | `/var/www/walktheplan.in/backend/uploads/` | Uploaded images, audio & media |

### One-Command Deployment to VPS

```bash
npm run deploy
```

#### What `npm run deploy` does:
1. Builds production bundles for all 4 frontend applications (`website`, `projection`, `dashboard`, `crm`).
2. Packages the backend and all frontend builds into `deployment.zip` (protecting databases and uploads).
3. Connects via SSH to VPS `72.61.238.132`.
4. Extracts, installs production dependencies, and migrates database tables.
5. Restarts the PM2 backend service (`walktheplan-backend` on port 5001).
6. Configures Nginx reverse proxy routing for all 4 sub-paths and applies SSL (`certbot`).

---

## ⚙️ Server Maintenance Commands

SSH into VPS:
```bash
ssh root@72.61.238.132
```

Check PM2 logs:
```bash
pm2 status
pm2 logs walktheplan-backend
```

Restart Nginx:
```bash
nginx -t
systemctl restart nginx
```
