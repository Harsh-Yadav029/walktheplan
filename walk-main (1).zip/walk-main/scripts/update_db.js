const sqlite3 = require('../crm/backend/node_modules/sqlite3').verbose();
const path = require('path');

const dbs = [
  path.join(__dirname, '../crm/backend/database.db'),
  path.join(__dirname, '../backend/database.db')
];

dbs.forEach(dbPath => {
  const db = new sqlite3.Database(dbPath);
  db.serialize(() => {
    db.run("UPDATE crm_leads SET lead_category = 'meta'");
    db.run("UPDATE crm_leads SET status = 'Blank Lead' WHERE source LIKE '%sheet%' OR source LIKE '%google%'");
    db.all("SELECT id, name, status, source, lead_category FROM crm_leads ORDER BY id DESC LIMIT 5", (err, rows) => {
      if (err) {
        console.error(`Error querying leads for ${dbPath}:`, err);
      } else {
        console.log(`Updated leads in ${dbPath}:`);
        console.log(JSON.stringify(rows, null, 2));
      }
      db.close();
    });
  });
});
