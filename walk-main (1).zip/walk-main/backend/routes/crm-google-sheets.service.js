// ═══════════════════════════════════════════════════════════════════════════════
// Walk The Plan CRM — Google Sheets Direct Live Synchronization Service
// Ingests & synchronizes Meta Facebook & Instagram leads directly from Google Sheets
// Multi-Tier Reader: Tier 1 (API v4) -> Tier 2 (Public GViz CSV) -> Tier 3 (Export CSV Fallback)
// ═══════════════════════════════════════════════════════════════════════════════

const XLSX = require('xlsx');
const { cleanPhoneNumber, cleanEmail, isInvalidClientName, normalizeStatus } = require('./crm-lead.parser');

/**
 * 1. extractSpreadsheetId(input)
 * Parses full Google Sheets URLs or raw alphanumeric ID strings
 */
function extractSpreadsheetId(input) {
  if (!input || typeof input !== 'string') return null;
  const trimmed = input.trim();

  // Match /spreadsheets/d/e/<ID> published sheets first
  const matchPub = trimmed.match(/\/spreadsheets\/d\/e\/([a-zA-Z0-9-_]+)/);
  if (matchPub && matchPub[1]) {
    return matchPub[1];
  }

  // Match /spreadsheets/d/<ID>
  const matchStandard = trimmed.match(/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/);
  if (matchStandard && matchStandard[1] && matchStandard[1] !== 'e') {
    return matchStandard[1];
  }

  // Raw alphanumeric ID (typically 15-64 chars)
  if (/^[a-zA-Z0-9-_]{15,64}$/.test(trimmed)) {
    return trimmed;
  }

  return null;
}

/**
 * Helper to fetch with timeout
 */
async function fetchWithTimeout(url, options = {}, timeoutMs = 12000) {
  const controller = new AbortController();
  const id = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, { ...options, signal: controller.signal });
    clearTimeout(id);
    return res;
  } catch (err) {
    clearTimeout(id);
    throw err;
  }
}

/**
 * Helper: Sanitizes phone numbers by stripping country codes (+91), spaces, and dashes down to 10 digits
 */
function sanitize10DigitPhone(val) {
  if (val === null || val === undefined) return null;
  const digits = String(val).replace(/\D/g, '');
  if (digits.length < 10) return null;
  return digits.slice(-10);
}

/**
 * 2. detectHeaderAndExtractRows(matrix)
 * Smart Header Auto-Detection:
 * Handles sheets where Rows 1–3 contain KPI summary banners (e.g., "Meta Leads Tracker", "Total Leads: 11").
 * Evaluates the first 15 rows with a keyword scoring engine (fullname, name, phone, mobile, email, city, plotsize, campaign, stage, etc.).
 * Extracts true column headers from the highest-scoring row and treats all subsequent rows as lead data.
 */
function detectHeaderAndExtractRows(matrix) {
  if (!matrix || !Array.isArray(matrix) || matrix.length === 0) {
    return { headers: [], rows: [], headerRowIdx: 0 };
  }

  const KEYWORDS = [
    { pattern: /full\s*name/i, weight: 5 },
    { pattern: /\bname\b/i, weight: 3 },
    { pattern: /client\s*name/i, weight: 4 },
    { pattern: /prospect\s*name/i, weight: 4 },
    { pattern: /phone/i, weight: 5 },
    { pattern: /mobile/i, weight: 5 },
    { pattern: /contact/i, weight: 4 },
    { pattern: /whatsapp/i, weight: 4 },
    { pattern: /email/i, weight: 5 },
    { pattern: /mail/i, weight: 3 },
    { pattern: /city/i, weight: 4 },
    { pattern: /location/i, weight: 3 },
    { pattern: /plot\s*size/i, weight: 4 },
    { pattern: /plotsize/i, weight: 4 },
    { pattern: /floor\s*plan/i, weight: 4 },
    { pattern: /floorplan/i, weight: 4 },
    { pattern: /requirement/i, weight: 4 },
    { pattern: /campaign/i, weight: 4 },
    { pattern: /ad\s*name/i, weight: 4 },
    { pattern: /ad\s*id/i, weight: 3 },
    { pattern: /stage/i, weight: 3 },
    { pattern: /status/i, weight: 3 },
    { pattern: /lead\s*status/i, weight: 4 },
    { pattern: /created/i, weight: 3 },
    { pattern: /timestamp/i, weight: 3 },
    { pattern: /date/i, weight: 2 },
    { pattern: /platform/i, weight: 3 }
  ];

  const BANNER_PATTERNS = [
    /meta\s*leads?\s*tracker/i,
    /total\s*leads?/i,
    /overview/i,
    /kpi/i,
    /dashboard/i,
    /summary/i
  ];

  const maxScanRows = Math.min(15, matrix.length);
  let bestHeaderRowIdx = 0;
  let highestScore = -1;

  for (let r = 0; r < maxScanRows; r++) {
    const row = matrix[r];
    if (!row || !Array.isArray(row)) continue;

    let score = 0;
    let nonEmptyCount = 0;

    for (const cell of row) {
      if (cell === null || cell === undefined) continue;
      const val = String(cell).trim();
      if (!val) continue;
      nonEmptyCount++;

      for (const kw of KEYWORDS) {
        if (kw.pattern.test(val)) {
          score += kw.weight;
        }
      }

      for (const bp of BANNER_PATTERNS) {
        if (bp.test(val)) {
          score -= 5;
        }
      }
    }

    if (nonEmptyCount >= 2 && score > highestScore) {
      highestScore = score;
      bestHeaderRowIdx = r;
    }
  }

  const headerRow = matrix[bestHeaderRowIdx] || [];
  const rawHeaders = headerRow.map((c, i) => {
    const val = c !== null && c !== undefined ? String(c).trim() : '';
    return val || `Col_${i + 1}`;
  });

  // Filter trailing empty column placeholders
  let lastValidIdx = -1;
  for (let i = 0; i < rawHeaders.length; i++) {
    if (!rawHeaders[i].startsWith('Col_')) {
      lastValidIdx = i;
    }
  }
  const headers = lastValidIdx >= 0 ? rawHeaders.slice(0, lastValidIdx + 1) : rawHeaders;

  const rows = [];
  for (let r = bestHeaderRowIdx + 1; r < matrix.length; r++) {
    const rowArr = matrix[r] || [];
    const obj = {};
    let hasData = false;
    headers.forEach((h, idx) => {
      const val = rowArr[idx] !== undefined && rowArr[idx] !== null ? String(rowArr[idx]).trim() : '';
      obj[h] = val;
      if (val) hasData = true;
    });
    if (hasData) {
      rows.push(obj);
    }
  }

  return {
    headers,
    rows,
    headerRowIdx: bestHeaderRowIdx
  };
}

/**
 * 3. fetchSheetData(spreadsheetId, sheetName, apiKey)
 * Extraction Protocol: Fetches the public CSV stream (/gviz/tq?tqx=out:csv),
 * falling back to the standard export URL, GViz JSON, or Sheets API v4.
 */
async function fetchSheetData(spreadsheetId, sheetName = 'Sheet1', apiKey = '') {
  if (!spreadsheetId) {
    throw new Error('Spreadsheet ID is required');
  }

  const cleanSheetName = (sheetName || 'Sheet1').trim();
  let errors = [];

  // ── Tier 1: Google Sheets API v4 (if API Key provided) ─────────────────────
  if (apiKey && apiKey.trim()) {
    try {
      const v4Url = `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(cleanSheetName)}?key=${apiKey.trim()}`;
      const res = await fetchWithTimeout(v4Url, {
        headers: { 'User-Agent': 'WalkThePlan-CRM/1.0' }
      });
      if (res.ok) {
        const json = await res.json();
        const values = json.values || [];
        if (values.length > 0) {
          const { headers, rows, headerRowIdx } = detectHeaderAndExtractRows(values);
          if (headers.length > 0) {
            return {
              headers,
              rows,
              sampleRows: rows.slice(0, 3),
              sourceMethod: 'Google Sheets API v4 (Tier 1)',
              rawRowCount: values.length,
              headerRowIdx
            };
          }
        }
      } else {
        const errText = await res.text().catch(() => '');
        errors.push(`Tier 1 (API v4): HTTP ${res.status} ${errText.slice(0, 100)}`);
      }
    } catch (t1Err) {
      errors.push(`Tier 1 (API v4) failed: ${t1Err.message}`);
    }
  }

  // ── Tier 2: Public CSV Stream (/gviz/tq?tqx=out:csv & /export?format=csv) ──
  const csvUrls = [
    `https://docs.google.com/spreadsheets/d/${spreadsheetId}/gviz/tq?tqx=out:csv&sheet=${encodeURIComponent(cleanSheetName)}`,
    `https://docs.google.com/spreadsheets/d/${spreadsheetId}/export?format=csv&sheet=${encodeURIComponent(cleanSheetName)}`
  ];

  for (const url of csvUrls) {
    try {
      const res = await fetchWithTimeout(url, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        }
      });
      if (res.ok) {
        const csvText = await res.text();
        if (csvText && csvText.trim() && !csvText.includes('<!DOCTYPE html>')) {
          const workbook = XLSX.read(Buffer.from(csvText), { type: 'buffer', raw: true });
          const sheet = workbook.Sheets[workbook.SheetNames[0]];
          const matrix = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: '' });
          if (matrix && matrix.length > 0) {
            const { headers, rows, headerRowIdx } = detectHeaderAndExtractRows(matrix);
            if (headers.length > 0) {
              const methodName = url.includes('/gviz/tq')
                ? 'Public GViz CSV Stream (Tier 2)'
                : 'Direct CSV Export Stream (Tier 2 Fallback)';
              return {
                headers,
                rows,
                sampleRows: rows.slice(0, 3),
                sourceMethod: methodName,
                rawRowCount: matrix.length,
                headerRowIdx
              };
            }
          }
        }
      } else {
        errors.push(`CSV Fetch (${url.slice(0, 60)}...): HTTP ${res.status}`);
      }
    } catch (csvErr) {
      errors.push(`CSV Fetch failed (${url.slice(0, 60)}...): ${csvErr.message}`);
    }
  }

  // ── Tier 3: Google GViz JSON Stream Fallback ────────────────────────────────
  try {
    const gvizUrl = `https://docs.google.com/spreadsheets/d/${spreadsheetId}/gviz/tq?tqx=out:json&sheet=${encodeURIComponent(cleanSheetName)}`;
    const res = await fetchWithTimeout(gvizUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      }
    });

    if (res.ok) {
      const text = await res.text();
      const jsonStart = text.indexOf('{');
      const jsonEnd = text.lastIndexOf('}');
      if (jsonStart !== -1 && jsonEnd !== -1) {
        const jsonStr = text.substring(jsonStart, jsonEnd + 1);
        const parsed = JSON.parse(jsonStr);
        if (parsed.table) {
          const cols = parsed.table.cols || [];
          const rawRows = parsed.table.rows || [];

          // Convert GViz table structure into 2D matrix
          const matrix = [];
          const hasColLabels = cols.some(c => c && c.label && c.label.trim() && !/^Col[0-9]+$/i.test(c.label.trim()));
          if (hasColLabels) {
            matrix.push(cols.map((c, i) => (c && c.label ? c.label.trim() : `Col_${i + 1}`)));
          }

          rawRows.forEach(r => {
            const cells = r.c || [];
            const rowArr = cells.map(cell => {
              if (!cell) return '';
              const val = cell.f !== undefined && cell.f !== null ? cell.f : (cell.v !== null && cell.v !== undefined ? cell.v : '');
              return String(val).trim();
            });
            matrix.push(rowArr);
          });

          if (matrix.length > 0) {
            const { headers, rows, headerRowIdx } = detectHeaderAndExtractRows(matrix);
            if (headers.length > 0) {
              return {
                headers,
                rows,
                sampleRows: rows.slice(0, 3),
                sourceMethod: 'Google GViz JSON stream (Tier 3)',
                rawRowCount: rawRows.length,
                headerRowIdx
              };
            }
          }
        }
      }
    } else {
      errors.push(`Tier 3 (GViz JSON): HTTP ${res.status}`);
    }
  } catch (t3Err) {
    errors.push(`Tier 3 (GViz JSON) failed: ${t3Err.message}`);
  }

  throw new Error(
    `Failed to fetch Google Sheet data across all extraction protocols. Details: ${errors.join(' | ')}. ` +
    `Ensure the sheet sharing is set to "Anyone with the link can view", or provide a valid Google Cloud API Key.`
  );
}

/**
 * 4. proposeAutoMapping(headers)
 * Smart header matcher proposing default mappings to CRM lead schema keys:
 * Full Name ➔ name
 * Phone Number ➔ phone
 * Email Address ➔ email
 * City ➔ city
 * Plot Size ➔ plot_size
 * Floor Plan Status ➔ requirement (and floor_plan_status)
 * Campaign Name ➔ campaign (and campaign_name)
 * Lead Status ➔ status
 */
function proposeAutoMapping(headers = []) {
  const mapping = {
    name: '',
    phone: '',
    email: '',
    city: '',
    plot_size: '',
    requirement: '',
    floor_plan_status: '',
    campaign: '',
    campaign_name: '',
    status: '',
    ad_name: '',
    platform: '',
    date: ''
  };

  const usedHeaders = new Set();

  // 1. Phone Number (High Priority: prevent phone numbers matching 'name')
  headers.forEach(h => {
    const raw = String(h || '').trim();
    if (!raw) return;
    const lower = raw.toLowerCase();
    const norm = lower.replace(/[^a-z0-9]/g, '');

    if (!mapping.phone && (
      norm.includes('phone') || norm.includes('mobile') || norm.includes('whatsapp') ||
      norm.includes('contactnumber') || norm.includes('phonenumber') || norm === 'contact' ||
      norm === 'cell' || norm === 'tel'
    )) {
      mapping.phone = raw;
      usedHeaders.add(raw);
    }
  });

  // 2. Email Address
  headers.forEach(h => {
    const raw = String(h || '').trim();
    if (!raw || usedHeaders.has(raw)) return;
    const lower = raw.toLowerCase();
    const norm = lower.replace(/[^a-z0-9]/g, '');

    if (!mapping.email && (
      norm.includes('email') || norm === 'mail' || norm.includes('emailaddress')
    )) {
      mapping.email = raw;
      usedHeaders.add(raw);
    }
  });

  // 3. Floor Plan Status / Requirement
  headers.forEach(h => {
    const raw = String(h || '').trim();
    if (!raw || usedHeaders.has(raw)) return;
    const lower = raw.toLowerCase();
    const norm = lower.replace(/[^a-z0-9]/g, '');

    if (!mapping.requirement && (
      lower.includes('floor plan') || norm.includes('floorplan') || norm.includes('planstatus') ||
      norm.includes('requirement') || norm.includes('projecttype') || norm.includes('statusfloor')
    )) {
      mapping.requirement = raw;
      mapping.floor_plan_status = raw;
      usedHeaders.add(raw);
    }
  });

  // 4. Plot Size
  headers.forEach(h => {
    const raw = String(h || '').trim();
    if (!raw || usedHeaders.has(raw)) return;
    const lower = raw.toLowerCase();
    const norm = lower.replace(/[^a-z0-9]/g, '');

    if (!mapping.plot_size && (
      lower.includes('plot size') || norm.includes('plotsize') || lower.includes('plot area') ||
      norm.includes('sqyard') || norm.includes('plotsizearea') || norm.includes('areasize')
    )) {
      mapping.plot_size = raw;
      usedHeaders.add(raw);
    }
  });

  // 5. Campaign Name
  headers.forEach(h => {
    const raw = String(h || '').trim();
    if (!raw || usedHeaders.has(raw)) return;
    const lower = raw.toLowerCase();
    const norm = lower.replace(/[^a-z0-9]/g, '');

    if (!mapping.campaign && (
      norm.includes('campaignname') || norm.includes('campaign') || norm.includes('adcampaign')
    )) {
      mapping.campaign = raw;
      mapping.campaign_name = raw;
      usedHeaders.add(raw);
    }
  });

  // 6. Lead Status / Stage
  headers.forEach(h => {
    const raw = String(h || '').trim();
    if (!raw || usedHeaders.has(raw)) return;
    const lower = raw.toLowerCase();
    const norm = lower.replace(/[^a-z0-9]/g, '');

    if (!mapping.status && (
      norm.includes('leadstatus') || norm === 'stage' || norm === 'status' || norm.includes('pipelinestatus')
    )) {
      mapping.status = raw;
      usedHeaders.add(raw);
    }
  });

  // 7. Ad Name
  headers.forEach(h => {
    const raw = String(h || '').trim();
    if (!raw || usedHeaders.has(raw)) return;
    const lower = raw.toLowerCase();
    const norm = lower.replace(/[^a-z0-9]/g, '');

    if (!mapping.ad_name && (
      !norm.includes('address') && (
        norm.includes('adname') || norm.includes('adid') || norm.includes('adset') ||
        norm.includes('formname') || /^(ad\s*name|ad\s*id|meta\s*ad)/i.test(lower) ||
        lower === 'ad' || lower === 'ad name'
      )
    )) {
      mapping.ad_name = raw;
      usedHeaders.add(raw);
    }
  });

  // 8. Platform / Channel
  headers.forEach(h => {
    const raw = String(h || '').trim();
    if (!raw || usedHeaders.has(raw)) return;
    const lower = raw.toLowerCase();
    const norm = lower.replace(/[^a-z0-9]/g, '');

    if (!mapping.platform && (
      norm.includes('platform') || norm.includes('metaplatform') || norm === 'source' || norm === 'channel'
    )) {
      mapping.platform = raw;
      usedHeaders.add(raw);
    }
  });

  // 9. Date / Timestamp
  headers.forEach(h => {
    const raw = String(h || '').trim();
    if (!raw || usedHeaders.has(raw)) return;
    const lower = raw.toLowerCase();
    const norm = lower.replace(/[^a-z0-9]/g, '');

    if (!mapping.date && (
      norm.includes('createdtime') || norm.includes('timestamp') || norm.includes('createdat') ||
      norm.includes('submissiontime') || norm === 'date' || norm === 'time'
    )) {
      mapping.date = raw;
      usedHeaders.add(raw);
    }
  });

  // 10. City / Location
  headers.forEach(h => {
    const raw = String(h || '').trim();
    if (!raw || usedHeaders.has(raw)) return;
    const lower = raw.toLowerCase();
    const norm = lower.replace(/[^a-z0-9]/g, '');

    if (!mapping.city && (
      norm.includes('city') || norm.includes('town') || norm.includes('location') || norm.includes('district')
    )) {
      mapping.city = raw;
      usedHeaders.add(raw);
    }
  });

  // 11. Client Full Name
  headers.forEach(h => {
    const raw = String(h || '').trim();
    if (!raw || usedHeaders.has(raw)) return;
    const lower = raw.toLowerCase();
    const norm = lower.replace(/[^a-z0-9]/g, '');

    if (!mapping.name && (
      norm.includes('fullname') || norm.includes('clientname') || norm.includes('customername') ||
      norm.includes('prospectname') || norm.includes('leadname') || norm === 'name' ||
      lower === 'full name' || lower === 'client name'
    )) {
      mapping.name = raw;
      usedHeaders.add(raw);
    }
  });

  return mapping;
}

/**
 * 5. syncGoogleSheetToCRM(db, config, syncType)
 * Syncs rows into crm_leads with deduplication, phone cleaning, and audit logs
 */
async function syncGoogleSheetToCRM(db, config, syncType = 'manual') {
  if (!config || !config.spreadsheet_id) {
    throw new Error('Active Google Sheet configuration missing');
  }

  // Update config status to syncing
  await new Promise((resolve) => {
    db.run(
      `UPDATE crm_google_sheets_config SET last_sync_status = 'syncing', updated_at = CURRENT_TIMESTAMP WHERE id = ?`,
      [config.id],
      () => resolve()
    );
  });

  try {
    const { headers, rows, sourceMethod } = await module.exports.fetchSheetData(
      config.spreadsheet_id,
      config.sheet_name || 'Sheet1',
      config.api_key || ''
    );

    let mapping = {};
    if (config.column_mapping) {
      try {
        mapping = typeof config.column_mapping === 'string' ? JSON.parse(config.column_mapping) : config.column_mapping;
      } catch {
        mapping = {};
      }
    }

    // If mapping is not set or missing phone, propose auto mapping
    if (Object.keys(mapping).length === 0 || (!mapping.phone && !mapping.email)) {
      mapping = module.exports.proposeAutoMapping(headers);
    }

    let syncedCount = 0;
    let skippedCount = 0;

    for (const row of rows) {
      const rawName = (mapping.name && row[mapping.name]) || row['Full Name'] || row['Name'] || row['Client Name'];
      const rawPhone = (mapping.phone && row[mapping.phone]) || row['Phone Number'] || row['Mobile'] || row['Phone'] || row['Contact'];
      const rawEmail = (mapping.email && row[mapping.email]) || row['Email Address'] || row['Email'] || row['Mail'];
      const rawCity = (mapping.city && row[mapping.city]) || row['City'] || row['Location'];
      const rawPlot = (mapping.plot_size && row[mapping.plot_size]) || row['Plot Size'] || row['What is your plot size?'];
      const rawReq = (mapping.requirement && row[mapping.requirement]) || (mapping.floor_plan_status && row[mapping.floor_plan_status]) || row['Floor Plan Status'] || row['What is your floor plan status?'] || row['Requirement'];
      const rawCamp = (mapping.campaign && row[mapping.campaign]) || (mapping.campaign_name && row[mapping.campaign_name]) || row['Campaign Name'] || row['Campaign'];
      const rawStatus = (mapping.status && row[mapping.status]) || row['Lead Status'] || row['Status'] || row['Stage'];
      const rawAd = (mapping.ad_name && row[mapping.ad_name]) || row['Ad Name'] || row['Ad ID'];
      const rawPlat = (mapping.platform && row[mapping.platform]) || row['Platform'] || 'Meta Ads';
      const rawDate = (mapping.date && row[mapping.date]) || row['Created Time'] || row['Date'] || row['Timestamp'];

      const phone10 = sanitize10DigitPhone(rawPhone);
      const email = cleanEmail(rawEmail);
      const phoneToStore = phone10 ? `+91 ${phone10}` : cleanPhoneNumber(rawPhone);

      // Skip invalid empty leads
      if (!phone10 && !email) {
        skippedCount++;
        continue;
      }

      // Format clean client human name
      let name = String(rawName || '').trim();
      if (!name || isInvalidClientName(name)) {
        name = `Lead (${phone10 || (email ? email.split('@')[0] : 'Walk In')})`;
      }

      // ── Deduplication Check ────────────────────────────────────────────────
      // Queries SELECT id FROM crm_leads WHERE phone LIKE ? before inserting.
      // If the lead exists, it skips insertion and updates the audit log (skipped_count).
      const existing = await new Promise((resolve, reject) => {
        if (phone10) {
          db.get('SELECT id FROM crm_leads WHERE phone LIKE ? LIMIT 1', [`%${phone10}%`], (err, r) => {
            if (err) reject(err);
            else resolve(r);
          });
        } else if (email) {
          db.get('SELECT id FROM crm_leads WHERE email = ? LIMIT 1', [email], (err, r) => {
            if (err) reject(err);
            else resolve(r);
          });
        } else {
          resolve(null);
        }
      });

      if (existing) {
        skippedCount++;
        continue;
      }

      // ── Insert New Lead into crm_leads ──────────────────────────────────────
      const platformDisplay = rawPlat ? String(rawPlat).trim() : 'Meta Ads';
      const isMeta = /meta|facebook|fb|instagram|ig/i.test(platformDisplay) || /meta/i.test(String(rawCamp || ''));
      const sourceStr = isMeta ? `Meta Ads via Google Sheet (${platformDisplay})` : `Google Sheet Live Sync (${platformDisplay})`;
      const normalizedStatus = rawStatus ? normalizeStatus(rawStatus) : 'Blank Lead';

      let createdAtStr = new Date().toISOString();
      if (rawDate) {
        const parsedD = new Date(rawDate);
        if (!isNaN(parsedD.getTime())) {
          createdAtStr = parsedD.toISOString();
        }
      }

      const insertId = await new Promise((resolve, reject) => {
        db.run(
          `INSERT INTO crm_leads (
            name, email, phone, city, plot_size, requirement, floor_plan_status,
            meta_ad_name, meta_campaign_name, meta_platform,
            lead_category, source, status, priority, created_at, updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'meta', ?, ?, 'medium', ?, ?)`,
          [
            name,
            email || null,
            phoneToStore || null,
            rawCity ? String(rawCity).trim() : null,
            rawPlot ? String(rawPlot).trim() : null,
            rawReq ? String(rawReq).trim() : null,
            rawReq ? String(rawReq).trim() : null,
            rawAd ? String(rawAd).trim() : null,
            rawCamp ? String(rawCamp).trim() : null,
            platformDisplay,
            sourceStr,
            normalizedStatus,
            createdAtStr,
            new Date().toISOString()
          ],
          function (err) {
            if (err) reject(err);
            else resolve(this.lastID);
          }
        );
      });

      // Insert audit trail activity
      db.run(
        `INSERT INTO crm_lead_activities (lead_id, action, note, interaction_type, author_name, author_role)
         VALUES (?, 'Lead Ingested', ?, 'System Automation', 'Google Sheets Sync Engine', 'automation')`,
        [insertId, `Lead Auto-Synced from Google Sheet (${config.sheet_name || 'Sheet1'})`]
      );

      syncedCount++;
    }

    // ── Update crm_google_sheets_config Telemetry ─────────────────────────────
    await new Promise((resolve) => {
      db.run(
        `UPDATE crm_google_sheets_config
         SET total_synced_count = total_synced_count + ?,
             last_synced_row = ?,
             last_sync_at = CURRENT_TIMESTAMP,
             last_sync_status = 'success',
             last_sync_error = NULL,
             updated_at = CURRENT_TIMESTAMP
         WHERE id = ?`,
        [syncedCount, rows.length + 1, config.id],
        () => resolve()
      );
    });

    // ── Record Audit Trail Sync Log ───────────────────────────────────────────
    await new Promise((resolve) => {
      db.run(
        `INSERT INTO crm_google_sheets_sync_logs (sync_type, synced_count, skipped_count, status, error_message)
         VALUES (?, ?, ?, 'success', NULL)`,
        [syncType, syncedCount, skippedCount],
        () => resolve()
      );
    });

    return {
      success: true,
      synced_count: syncedCount,
      skipped_count: skippedCount,
      total_rows: rows.length,
      sourceMethod
    };
  } catch (err) {
    // Record error telemetry
    db.run(
      `UPDATE crm_google_sheets_config
       SET last_sync_status = 'error', last_sync_error = ?, updated_at = CURRENT_TIMESTAMP
       WHERE id = ?`,
      [err.message, config.id]
    );

    db.run(
      `INSERT INTO crm_google_sheets_sync_logs (sync_type, synced_count, skipped_count, status, error_message)
       VALUES (?, 0, 0, 'error', ?)`,
      [syncType, err.message]
    );

    throw err;
  }
}

module.exports = {
  extractSpreadsheetId,
  detectHeaderAndExtractRows,
  fetchSheetData,
  proposeAutoMapping,
  syncGoogleSheetToCRM,
  sanitize10DigitPhone
};
