const { Client } = require('ssh2');
const fs = require('fs');
const path = require('path');
const archiver = require('archiver');
const { execSync } = require('child_process');

// Production VPS Credentials
const config = {
  host: process.env.DEPLOY_HOST || '72.61.238.132',
  username: process.env.DEPLOY_USER || 'root',
  password: process.env.DEPLOY_PASSWORD || 'Jaishreeram@1234#',
  domain: process.env.DEPLOY_DOMAIN || 'walktheplan.in'
};

const localZipPath = path.join(__dirname, 'deployment.zip');
const remoteDestDir = `/var/www/${config.domain}`;
const remoteZipPath = `/var/www/deployment.zip`;

// 1. Build and package all separate modules
function zipProject() {
  if (process.env.SKIP_BUILD && fs.existsSync(localZipPath)) {
    console.log('SKIP_BUILD active: using existing deployment.zip');
    return Promise.resolve();
  }
  return new Promise((resolve, reject) => {
    try {
      console.log('1/4 Building Website production bundle...');
      execSync('npm run build', { cwd: path.join(__dirname, 'website'), stdio: 'inherit' });

      console.log('2/4 Building Projection Studio production bundle...');
      execSync('npm run build', { cwd: path.join(__dirname, 'projection'), stdio: 'inherit' });

      console.log('3/4 Building Admin Dashboard production bundle...');
      execSync('npm run build', { cwd: path.join(__dirname, 'dashboard'), stdio: 'inherit' });

      console.log('4/4 Building CRM Portal production bundle...');
      execSync('npm run build', { cwd: path.join(__dirname, 'crm/frontend'), stdio: 'inherit' });
    } catch (err) {
      return reject(new Error('Frontend build failed. Deployment aborted. ' + err.message));
    }

    console.log('Packaging all apps into deployment.zip...');
    const output = fs.createWriteStream(localZipPath);
    const archive = new archiver.ZipArchive({ zlib: { level: 5 } });

    output.on('close', () => {
      console.log(`Successfully packed project! Total size: ${(archive.pointer() / 1024 / 1024).toFixed(2)} MB`);
      resolve();
    });

    archive.on('error', (err) => {
      reject(err);
    });

    archive.pipe(output);

    // Package backend files as backend/
    archive.directory('backend/', 'backend', (entry) => {
      const name = entry.name;
      if (
        name.startsWith('node_modules') || 
        name.includes('/node_modules/') ||
        name.endsWith('.mp4') ||
        name.endsWith('.db') ||
        name.endsWith('.db-wal') ||
        name.endsWith('.db-shm') ||
        name.endsWith('.db-journal')
      ) {
        return false;
      }
      return entry;
    });

    // Package separate frontend dist bundles
    archive.glob('**/*', { cwd: 'website/dist', ignore: ['**/*.mp4'] }, { prefix: 'website/dist' });
    archive.glob('**/*', { cwd: 'projection/dist', ignore: ['**/*.mp4'] }, { prefix: 'projection/dist' });
    archive.glob('**/*', { cwd: 'dashboard/dist', ignore: ['**/*.mp4'] }, { prefix: 'dashboard/dist' });
    archive.glob('**/*', { cwd: 'crm/frontend/dist', ignore: ['**/*.mp4'] }, { prefix: 'crm/dist' });

    archive.file('package.json', { name: 'package.json' });
    archive.file('package-lock.json', { name: 'package-lock.json' });

    archive.finalize();
  });
}

// Helper to execute command over SSH
function runRemoteCommand(conn, cmd) {
  return new Promise((resolve, reject) => {
    console.log(`Executing remote: ${cmd}`);
    conn.exec(cmd, (err, stream) => {
      if (err) return reject(err);
      
      let stdout = '';
      let stderr = '';
      
      stream.on('close', (code, signal) => {
        if (code !== 0) {
          console.error(`Command failed with code ${code}. Error: ${stderr}`);
          reject(new Error(`Command failed with exit code ${code}`));
        } else {
          resolve(stdout);
        }
      }).on('data', (data) => {
        stdout += data.toString();
        process.stdout.write(data);
      }).stderr.on('data', (data) => {
        stderr += data.toString();
        process.stderr.write(data);
      });
    });
  });
}

function uploadFile(conn, localPath, remotePath) {
  return new Promise((resolve, reject) => {
    console.log(`Uploading ${localPath} to remote ${remotePath}...`);
    conn.sftp((err, sftp) => {
      if (err) return reject(err);
      
      const stats = fs.statSync(localPath);
      const totalBytes = stats.size;
      let transferred = 0;
      let lastReport = 0;

      const readStream = fs.createReadStream(localPath);
      const writeStream = sftp.createWriteStream(remotePath, { flags: 'w' });

      readStream.on('data', (chunk) => {
        transferred += chunk.length;
        const percent = ((transferred / totalBytes) * 100).toFixed(1);
        const now = Date.now();
        if (now - lastReport > 2000 || transferred === totalBytes) {
          console.log(`Upload progress: ${percent}% (${(transferred / 1024 / 1024).toFixed(2)} / ${(totalBytes / 1024 / 1024).toFixed(2)} MB)`);
          lastReport = now;
        }
      });

      writeStream.on('close', () => {
        console.log('File upload completed successfully via SFTP stream.');
        resolve();
      });

      writeStream.on('error', (streamErr) => {
        console.error('SFTP stream error:', streamErr.message);
        reject(streamErr);
      });

      readStream.on('error', (readErr) => {
        console.error('Local read error:', readErr.message);
        reject(readErr);
      });

      readStream.pipe(writeStream);
    });
  });
}

async function deploy() {
  try {
    // 1. Pack the project
    await zipProject();

    // 2. Connect to VPS
    console.log(`Connecting to VPS at ${config.host}...`);
    const conn = new Client();
    
    conn.on('error', (err) => {
      console.error('SSH connection error:', err.message);
    });

    conn.on('ready', async () => {
      console.log('SSH connection established successfully.');
      try {
        // Create destination directory
        await runRemoteCommand(conn, `mkdir -p ${remoteDestDir}`);

        // Upload zip file
        await uploadFile(conn, localZipPath, remoteZipPath);

        // Install system dependencies on server
        console.log('Installing server dependencies (Node.js, Nginx, PM2, unzip)...');
        const setupScript = `
          if ! command -v node &> /dev/null; then
            echo "Installing Node.js..."
            curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
            apt-get install -y nodejs
          fi
          
          if ! command -v pm2 &> /dev/null; then
            echo "Installing PM2..."
            npm install -g pm2
          fi

          if ! command -v nginx &> /dev/null; then
            echo "Installing Nginx..."
            apt-get update
            apt-get install -y nginx
          fi

          if ! command -v unzip &> /dev/null; then
            echo "Installing unzip..."
            apt-get install -y unzip
          fi
        `;
        await runRemoteCommand(conn, setupScript);

        // Extract files on the server
        console.log('Extracting project files...');
        await runRemoteCommand(conn, `unzip -o ${remoteZipPath} -d ${remoteDestDir} && rm ${remoteZipPath}`);

        // Install dependencies on remote server
        console.log('Installing npm dependencies on server...');
        await runRemoteCommand(conn, `cd ${remoteDestDir} && rm -rf backend/node_modules && npm install --production --legacy-peer-deps && npm install --prefix backend --production --legacy-peer-deps`);

        // Update database settings, admin password, and seed 10 blogs on remote server
        console.log('Updating database settings and seeding blogs on server...');
        const remoteSeedCode = [
          `const fs = require('fs');`,
          `const sqlite3 = require('${remoteDestDir}/backend/node_modules/sqlite3').verbose();`,
          `const bcrypt = require('${remoteDestDir}/backend/node_modules/bcryptjs');`,
          `const db = new sqlite3.Database('${remoteDestDir}/backend/database.db');`,
          `const hash = bcrypt.hashSync('walk@321', 10);`,
          `db.serialize(() => {`,
          `  db.run("DELETE FROM users WHERE username = 'parth'");`,
          `  db.run("DELETE FROM crm_users WHERE email IN ('admin@walktheplant.com', 'admin@walktheplan.com')");`,
          `  db.run("INSERT OR REPLACE INTO users (username, password_hash) VALUES ('fitscalez', '" + hash + "')");`,
          `  db.run("UPDATE users SET password_hash = '" + hash + "' WHERE username IN ('admin', 'fitscalez')");`,
          `  db.run("DELETE FROM push_subscriptions WHERE is_admin = 1");`,
          `  db.run("INSERT OR REPLACE INTO website_settings (key, value) VALUES ('whatsapp_number', '+91 97110 22075')");`,
          `  db.run("INSERT OR REPLACE INTO website_settings (key, value) VALUES ('show_leads_public', '1')");`,
          `  db.run("UPDATE studio_locations SET phone = '+91 97110 22075' WHERE phone LIKE '%92177%'");`,
          `  try {`,
          `    const blogsMod = fs.existsSync('${remoteDestDir}/backend/data/blogs.data.js') ? '${remoteDestDir}/backend/data/blogs.data.js' : '${remoteDestDir}/backend/blogs_data.js';`,
          `    const { seedBlogsAndImages } = require(blogsMod);`,
          `    seedBlogsAndImages(db, '${remoteDestDir}/backend/uploads');`,
          `  } catch(e) { console.error('Blog seed error:', e); }`,
          `});`,
          `setTimeout(() => db.close(), 2500);`
        ].join(' ');
        await runRemoteCommand(conn, `node -e ${JSON.stringify(remoteSeedCode)} || true`);

        // Start backend server via PM2
        console.log('Starting backend server with PM2...');
        await runRemoteCommand(conn, `cd ${remoteDestDir} && pm2 delete walktheplan-backend || true`);
        await runRemoteCommand(conn, `cd ${remoteDestDir} && PORT=5001 pm2 start backend/server.js --name "walktheplan-backend" --update-env`);
        await runRemoteCommand(conn, `pm2 save`);

        // Configure Nginx with clean separation for website, projection, dashboard, and CRM
        console.log('Configuring Nginx Reverse Proxy with Modular Architecture...');
        const nginxConfig = `
server {
    listen 80;
    server_name ${config.domain} www.${config.domain};

    # Allow large video uploads up to 300MB
    client_max_body_size 300M;
    client_body_timeout 300s;

    # 1. Dedicated B2B Sales CRM Portal
    location = /crm {
        return 301 /crm/;
    }
    location /crm/ {
        alias ${remoteDestDir}/crm/dist/;
        index index.html;
        try_files $uri $uri/ /crm/index.html;
    }

    # 2. Dedicated 1:1 Scale Floor Plan Projection Studio
    location = /projection {
        return 301 /projection/;
    }
    location /projection/ {
        alias ${remoteDestDir}/projection/dist/;
        index index.html;
        try_files $uri $uri/ /projection/index.html;
    }

    # 3. Dedicated Admin / Fitscalez Management Dashboard
    location = /admin {
        return 301 /admin/;
    }
    location /admin/ {
        alias ${remoteDestDir}/dashboard/dist/;
        index index.html;
        try_files $uri $uri/ /admin/index.html;
    }

    location /login {
        return 301 /admin/login;
    }

    location /fitscalez {
        return 301 /admin/fitscalez;
    }

    # 4. Main Public Website
    location / {
        root ${remoteDestDir}/website/dist;
        index index.html;
        try_files $uri $uri/ /index.html;
    }

    # 5. Unified Express Backend API
    location /api/ {
        proxy_pass http://localhost:5001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        client_max_body_size 300M;
        proxy_read_timeout 300s;
        proxy_connect_timeout 300s;
        proxy_send_timeout 300s;
        proxy_request_buffering off;
    }

    # 6. Uploaded Media Assets
    location /uploads/ {
        alias ${remoteDestDir}/backend/uploads/;
        expires 30d;
        add_header Cache-Control "public, no-transform";
    }
}
`;
        
        // Write Nginx config
        const writeNginxCmd = `cat << 'EOF' > /etc/nginx/sites-available/${config.domain}
${nginxConfig}
EOF
        `;
        await runRemoteCommand(conn, writeNginxCmd);

        // Enable Nginx site configuration
        console.log('Enabling Nginx configurations...');
        await runRemoteCommand(conn, `ln -sf /etc/nginx/sites-available/${config.domain} /etc/nginx/sites-enabled/`);
        await runRemoteCommand(conn, `rm -f /etc/nginx/sites-enabled/default || true`);
        await runRemoteCommand(conn, `nginx -t`);
        await runRemoteCommand(conn, `systemctl restart nginx`);

        // Install SSL via Certbot Let's Encrypt
        console.log('Configuring SSL certificates...');
        const sslScript = `
          if ! command -v certbot &> /dev/null; then
            apt-get install -y certbot python3-certbot-nginx
          fi
          # Run certbot non-interactively
          certbot --nginx --non-interactive --agree-tos --email admin@${config.domain} -d ${config.domain} -d www.${config.domain} || echo "SSL configuration skipped or failed (check DNS propagation)"
        `;
        await runRemoteCommand(conn, sslScript);

        console.log('\\n=========================================');
        console.log('DEPLOYMENT COMPLETE SUCCESSFULLY!');
        console.log('Website:     https://' + config.domain);
        console.log('Projection:  https://' + config.domain + '/projection');
        console.log('Dashboard:   https://' + config.domain + '/admin');
        console.log('CRM Portal:  https://' + config.domain + '/crm');
        console.log('API Base:    https://' + config.domain + '/api');
        console.log('=========================================\\n');

      } catch (err) {
        console.error('Error during remote execution:', err);
      } finally {
        conn.end();
        if (fs.existsSync(localZipPath)) {
          fs.unlinkSync(localZipPath);
        }
      }
    }).connect({
      host: config.host,
      username: config.username,
      password: config.password,
      readyTimeout: 60000,
      keepaliveInterval: 15000,
      keepaliveCountMax: 30
    });

  } catch (err) {
    console.error('Deployment script error:', err);
  }
}

deploy();
