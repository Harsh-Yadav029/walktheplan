/**
 * architecturalEngine.jsx
 * Walk The Plan · Advanced 3D Architectural CAD & Modeling Engine
 * Inspired by open-source CAD & 3D floor plan engines (FloorPlan-3D-OpenSource)
 * 
 * Features:
 * - Parametric 3D Walls with Apertures for Doors & Windows
 * - Architectural Doors (Single, French Double, Sliding, Archway) with frames & lever handles
 * - Architectural Windows (Single Casement, Double Slider, Picture Window, Ventilator) with glass
 * - Structural RCC Columns (Square & Round)
 * - Toggleable Ceilings & False Ceilings with Warm LED Cove Lighting
 * - Dynamic Sun Study & Interior Downlights that activate automatically at evening/night
 * - High-Detail Procedural 3D Furniture & Architectural Fixtures
 * - Visual Render Styles: Photorealistic PBR, Cyan Laser Projection, Clay Model, Wireframe CAD
 */

import React, { useMemo, useRef } from 'react';
import * as THREE from 'three';
import { Text } from '@react-three/drei';

// ─────────────────────────────────────────────────────────────────────────────
// ARCHITECTURAL FINISHES & MATERIALS
// ─────────────────────────────────────────────────────────────────────────────

export const ARCH_MATERIALS = {
  // Walls
  wall_pure_white: { name: 'Architectural Pure White Plaster', color: '#f8fafc', roughness: 0.85, metalness: 0.05 },
  wall_slate_gray: { name: 'Contemporary Slate Gray', color: '#475569', roughness: 0.8, metalness: 0.1 },
  wall_charcoal: { name: 'Nordic Charcoal Minimal', color: '#1e293b', roughness: 0.85, metalness: 0.08 },
  wall_warm_sand: { name: 'Warm Terracotta Stucco', color: '#7c533e', roughness: 0.9, metalness: 0.02 },
  wall_champagne_gold: { name: 'Royal Champagne Plaster', color: '#bfa063', roughness: 0.6, metalness: 0.25 },
  wall_blueprint_cyan: { name: 'Glowing Blueprint Cyan', color: '#0369a1', roughness: 0.3, metalness: 0.4, glow: '#00f0ff' },

  // Flooring
  floor_calacatta: { name: 'Calacatta Gold Italian Marble', color: '#f7f4ee', roughness: 0.12, metalness: 0.15 },
  floor_carrara: { name: 'Carrara Pure White Marble', color: '#e8edf3', roughness: 0.14, metalness: 0.12 },
  floor_smoked_walnut: { name: 'Smoked Walnut Parquet', color: '#3d2516', roughness: 0.62, metalness: 0.05 },
  floor_nordic_oak: { name: 'Nordic Light Oak Planks', color: '#9d7c55', roughness: 0.58, metalness: 0.05 },
  floor_polished_concrete: { name: 'Microcement Polished Concrete', color: '#526071', roughness: 0.35, metalness: 0.12 },
  floor_dark_terrazzo: { name: 'Venetian Dark Terrazzo', color: '#1a2332', roughness: 0.42, metalness: 0.1 },
  floor_obsidian_laser: { name: 'Obsidian Laser Stage Glass', color: '#031422', roughness: 0.08, metalness: 0.75 },

  // Architectural Metals & Glass
  frame_black_alu: { color: '#181b20', roughness: 0.4, metalness: 0.85 },
  frame_brass_gold: { color: '#d4af37', roughness: 0.3, metalness: 0.9 },
  frame_warm_wood: { color: '#5c3a21', roughness: 0.6, metalness: 0.05 },
  glass_translucent: { color: '#cde4f7', roughness: 0.05, metalness: 0.2, transmission: 0.9, opacity: 0.35, transparent: true },
  glass_mirror: { color: '#e2e8f0', roughness: 0.02, metalness: 0.98 },
  chrome_metal: { color: '#f1f5f9', roughness: 0.1, metalness: 0.95 }
};

// ─────────────────────────────────────────────────────────────────────────────
// MATERIAL RESOLVER FOR RENDER STYLES
// ─────────────────────────────────────────────────────────────────────────────

export function getStyleMaterial({
  color,
  roughness = 0.5,
  metalness = 0.1,
  renderStyle = 'realistic',
  isSelected = false,
  isGlass = false,
  opacity = 1.0,
  glow = null
}) {
  if (isSelected) {
    return new THREE.MeshStandardMaterial({
      color: '#00f0ff',
      emissive: '#0284c7',
      emissiveIntensity: 0.4,
      roughness: 0.3,
      metalness: 0.2
    });
  }

  if (renderStyle === 'clay') {
    // Pure minimalist architectural model (white plaster foam-board)
    return new THREE.MeshStandardMaterial({
      color: isGlass ? '#cbd5e1' : '#f8fafc',
      roughness: 0.92,
      metalness: 0.02,
      opacity: isGlass ? 0.4 : 1.0,
      transparent: isGlass
    });
  }

  if (renderStyle === 'cyan_laser') {
    // Holographic laser blueprint style
    return new THREE.MeshStandardMaterial({
      color: isGlass ? '#00f0ff' : '#0369a1',
      emissive: '#00f0ff',
      emissiveIntensity: isGlass ? 0.6 : 0.2,
      roughness: 0.2,
      metalness: 0.6,
      opacity: isGlass ? 0.5 : 0.88,
      transparent: isGlass
    });
  }

  if (renderStyle === 'wireframe') {
    return new THREE.MeshBasicMaterial({
      color: isGlass ? '#38bdf8' : color,
      wireframe: true
    });
  }

  // Realistic PBR
  if (isGlass) {
    return new THREE.MeshPhysicalMaterial({
      color: '#d0e7ff',
      roughness: 0.05,
      metalness: 0.1,
      transmission: 0.85,
      opacity: 0.35,
      transparent: true,
      reflectivity: 0.9
    });
  }

  return new THREE.MeshStandardMaterial({
    color,
    roughness,
    metalness,
    opacity,
    transparent: opacity < 1.0
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// 3D ARCHITECTURAL OPENINGS (DOORS & WINDOWS)
// ─────────────────────────────────────────────────────────────────────────────

export function Door3D({
  door,
  wallHeight = 3.0,
  wallThick = 0.2,
  renderStyle = 'realistic',
  isSelected = false
}) {
  const width = door.w || 0.9;
  const height = Math.min(door.h || 2.1, wallHeight);
  const style = door.style || 'single';
  const isOpen = door.isOpen ?? true;
  const swingAngle = isOpen ? (door.swing === 'left' ? -0.45 : 0.45) : 0;

  const frameMat = useMemo(() => getStyleMaterial({
    color: '#1e293b',
    roughness: 0.4,
    metalness: 0.7,
    renderStyle,
    isSelected
  }), [renderStyle, isSelected]);

  const leafMat = useMemo(() => getStyleMaterial({
    color: style === 'french_glass' ? '#0f172a' : '#452b1b',
    roughness: 0.6,
    metalness: 0.1,
    renderStyle,
    isSelected
  }), [renderStyle, isSelected, style]);

  const glassMat = useMemo(() => getStyleMaterial({
    isGlass: true,
    renderStyle,
    isSelected
  }), [renderStyle, isSelected]);

  const handleMat = useMemo(() => getStyleMaterial({
    color: '#e2e8f0',
    roughness: 0.2,
    metalness: 0.95,
    renderStyle
  }), [renderStyle]);

  return (
    <group position={[0, height / 2, 0]}>
      {/* Outer Door Frame: Left Jamb */}
      <mesh position={[-width / 2 + 0.025, 0, 0]} castShadow receiveShadow>
        <boxGeometry args={[0.05, height, wallThick + 0.02]} />
        <primitive object={frameMat} attach="material" />
      </mesh>

      {/* Outer Door Frame: Right Jamb */}
      <mesh position={[width / 2 - 0.025, 0, 0]} castShadow receiveShadow>
        <boxGeometry args={[0.05, height, wallThick + 0.02]} />
        <primitive object={frameMat} attach="material" />
      </mesh>

      {/* Outer Door Frame: Header Transom */}
      <mesh position={[0, height / 2 - 0.025, 0]} castShadow receiveShadow>
        <boxGeometry args={[width, 0.05, wallThick + 0.02]} />
        <primitive object={frameMat} attach="material" />
      </mesh>

      {/* Door Leaf (Hinged Pivot) */}
      {style !== 'archway' && (
        <group position={[-width / 2 + 0.05, 0, 0]} rotation={[0, swingAngle, 0]}>
          {/* Main Leaf Panel */}
          <mesh position={[(width - 0.1) / 2, 0, 0]} castShadow receiveShadow>
            <boxGeometry args={[width - 0.1, height - 0.06, 0.04]} />
            <primitive object={leafMat} attach="material" />
          </mesh>

          {/* Glass Insert for French/Modern Doors */}
          {style === 'french_glass' && (
            <mesh position={[(width - 0.1) / 2, 0, 0]}>
              <boxGeometry args={[width * 0.7, height * 0.75, 0.02]} />
              <primitive object={glassMat} attach="material" />
            </mesh>
          )}

          {/* Lever Handle & Escutcheon Plate */}
          <group position={[width - 0.22, 0, 0.03]}>
            {/* Latch Plate */}
            <mesh>
              <boxGeometry args={[0.04, 0.18, 0.008]} />
              <primitive object={handleMat} attach="material" />
            </mesh>
            {/* Lever Rod */}
            <mesh position={[0.03, 0.02, 0.035]} rotation={[0, 0, -Math.PI / 2]}>
              <cylinderGeometry args={[0.012, 0.012, 0.12, 12]} />
              <primitive object={handleMat} attach="material" />
            </mesh>
          </group>
        </group>
      )}
    </group>
  );
}

export function Window3D({
  windowItem,
  wallHeight = 3.0,
  wallThick = 0.2,
  renderStyle = 'realistic',
  isSelected = false
}) {
  const width = windowItem.w || 1.4;
  const height = Math.min(windowItem.h || 1.2, wallHeight - 0.3);
  const sillH = windowItem.sillH ?? 0.9;
  const style = windowItem.style || 'casement';

  const frameMat = useMemo(() => getStyleMaterial({
    color: '#0f172a',
    roughness: 0.35,
    metalness: 0.8,
    renderStyle,
    isSelected
  }), [renderStyle, isSelected]);

  const glassMat = useMemo(() => getStyleMaterial({
    isGlass: true,
    renderStyle,
    isSelected
  }), [renderStyle, isSelected]);

  const sillMat = useMemo(() => getStyleMaterial({
    color: '#e2e8f0',
    roughness: 0.3,
    metalness: 0.15,
    renderStyle
  }), [renderStyle]);

  const centerY = sillH + height / 2;

  return (
    <group position={[0, centerY, 0]}>
      {/* Outer Window Sill Ledge (Projecting slightly out) */}
      <mesh position={[0, -height / 2 - 0.02, 0]} castShadow receiveShadow>
        <boxGeometry args={[width + 0.12, 0.04, wallThick + 0.08]} />
        <primitive object={sillMat} attach="material" />
      </mesh>

      {/* Window Frame Perimeter */}
      <mesh position={[-width / 2 + 0.025, 0, 0]} castShadow receiveShadow>
        <boxGeometry args={[0.05, height, wallThick + 0.01]} />
        <primitive object={frameMat} attach="material" />
      </mesh>
      <mesh position={[width / 2 - 0.025, 0, 0]} castShadow receiveShadow>
        <boxGeometry args={[0.05, height, wallThick + 0.01]} />
        <primitive object={frameMat} attach="material" />
      </mesh>
      <mesh position={[0, height / 2 - 0.025, 0]} castShadow receiveShadow>
        <boxGeometry args={[width, 0.05, wallThick + 0.01]} />
        <primitive object={frameMat} attach="material" />
      </mesh>
      <mesh position={[0, -height / 2 + 0.025, 0]} castShadow receiveShadow>
        <boxGeometry args={[width, 0.05, wallThick + 0.01]} />
        <primitive object={frameMat} attach="material" />
      </mesh>

      {/* Center Vertical Mullion Bar */}
      {width > 1.0 && (
        <mesh position={[0, 0, 0]} castShadow receiveShadow>
          <boxGeometry args={[0.04, height - 0.08, wallThick * 0.7]} />
          <primitive object={frameMat} attach="material" />
        </mesh>
      )}

      {/* Horizontal Transom Bar (for tall picture windows) */}
      {height > 1.4 && (
        <mesh position={[0, height * 0.25, 0]} castShadow receiveShadow>
          <boxGeometry args={[width - 0.08, 0.035, wallThick * 0.7]} />
          <primitive object={frameMat} attach="material" />
        </mesh>
      )}

      {/* Reflective Architectural Glass Pane */}
      <mesh castShadow={false} receiveShadow>
        <boxGeometry args={[width - 0.06, height - 0.06, 0.015]} />
        <primitive object={glassMat} attach="material" />
      </mesh>
    </group>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// PARAMETRIC 3D WALL WITH APERTURES (DOORS & WINDOWS CUTOUTS)
// ─────────────────────────────────────────────────────────────────────────────

export function ParametricApertureWall({
  wall,
  openings = [],
  wallHeight = 3.0,
  wallThick = 0.2,
  wallMatKey = 'wall_pure_white',
  renderStyle = 'realistic',
  isSelected = false,
  onSelect = null
}) {
  const length = wall.length || wall.w || 4.0;
  const height = Math.min(wall.height || wallHeight, wallHeight);
  const thick = wall.thick || wallThick;

  const wallMat = useMemo(() => {
    const preset = ARCH_MATERIALS[wallMatKey] || ARCH_MATERIALS.wall_pure_white;
    return getStyleMaterial({
      color: preset.color,
      roughness: preset.roughness,
      metalness: preset.metalness,
      renderStyle,
      isSelected
    });
  }, [wallMatKey, renderStyle, isSelected]);

  // If no openings on this wall, render clean solid wall slab
  if (!openings || openings.length === 0) {
    return (
      <group
        onClick={(e) => {
          if (onSelect) {
            e.stopPropagation();
            onSelect(wall);
          }
        }}
      >
        <mesh position={[0, height / 2, 0]} castShadow receiveShadow>
          <boxGeometry args={[length, height, thick]} />
          <primitive object={wallMat} attach="material" />
        </mesh>
      </group>
    );
  }

  // Sort openings along wall length
  const sorted = [...openings].sort((a, b) => (a.offset || 0) - (b.offset || 0));

  let currentX = -length / 2;
  const elements = [];

  sorted.forEach((op, index) => {
    const opWidth = op.w || (op.type === 'door' ? 0.9 : 1.4);
    const opHeight = op.h || (op.type === 'door' ? 2.1 : 1.2);
    const sillH = op.type === 'door' ? 0 : (op.sillH ?? 0.9);
    const opStartX = -length / 2 + (op.offset || (length / 2 - opWidth / 2));
    const segmentWidth = Math.max(0, opStartX - currentX);

    // Wall segment before this opening
    if (segmentWidth > 0.05) {
      elements.push(
        <mesh
          key={`wall-seg-${index}`}
          position={[currentX + segmentWidth / 2, height / 2, 0]}
          castShadow
          receiveShadow
        >
          <boxGeometry args={[segmentWidth, height, thick]} />
          <primitive object={wallMat} attach="material" />
        </mesh>
      );
    }

    // Lintel wall header above opening
    const lintelHeight = Math.max(0, height - (sillH + opHeight));
    if (lintelHeight > 0.04) {
      elements.push(
        <mesh
          key={`lintel-${index}`}
          position={[opStartX + opWidth / 2, sillH + opHeight + lintelHeight / 2, 0]}
          castShadow
          receiveShadow
        >
          <boxGeometry args={[opWidth, lintelHeight, thick]} />
          <primitive object={wallMat} attach="material" />
        </mesh>
      );
    }

    // Sill wall below window opening
    if (sillH > 0.05) {
      elements.push(
        <mesh
          key={`sill-${index}`}
          position={[opStartX + opWidth / 2, sillH / 2, 0]}
          castShadow
          receiveShadow
        >
          <boxGeometry args={[opWidth, sillH, thick]} />
          <primitive object={wallMat} attach="material" />
        </mesh>
      );
    }

    // 3D Door or Window placed inside aperture
    const openingCenter = [opStartX + opWidth / 2, 0, 0];
    if (op.type === 'door') {
      elements.push(
        <group key={`door-${index}`} position={openingCenter}>
          <Door3D
            door={op}
            wallHeight={height}
            wallThick={thick}
            renderStyle={renderStyle}
            isSelected={isSelected}
          />
        </group>
      );
    } else {
      elements.push(
        <group key={`win-${index}`} position={openingCenter}>
          <Window3D
            windowItem={op}
            wallHeight={height}
            wallThick={thick}
            renderStyle={renderStyle}
            isSelected={isSelected}
          />
        </group>
      );
    }

    currentX = opStartX + opWidth;
  });

  // Remaining wall segment to end
  const remainingWidth = length / 2 - currentX;
  if (remainingWidth > 0.05) {
    elements.push(
      <mesh
        key="wall-seg-end"
        position={[currentX + remainingWidth / 2, height / 2, 0]}
        castShadow
        receiveShadow
      >
        <boxGeometry args={[remainingWidth, height, thick]} />
        <primitive object={wallMat} attach="material" />
      </mesh>
    );
  }

  return (
    <group
      onClick={(e) => {
        if (onSelect) {
          e.stopPropagation();
          onSelect(wall);
        }
      }}
    >
      {elements}
    </group>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// 3D PARAMETRIC CUSTOM DRAWN WALL (OPENPLAN3D COMPATIBLE)
// ─────────────────────────────────────────────────────────────────────────────

export function CustomWall3D({
  wall,
  openings = [],
  wallHeight = 3.0,
  renderStyle = 'realistic',
  isSelected = false,
  onSelect = null,
  elevation = 0
}) {
  const x1 = Number(wall.x1 || 0);
  const z1 = Number(wall.z1 || 0);
  const x2 = Number(wall.x2 !== undefined ? wall.x2 : x1 + (wall.length || 3.0));
  const z2 = Number(wall.z2 !== undefined ? wall.z2 : z1);

  const dx = x2 - x1;
  const dz = z2 - z1;
  const length = Math.hypot(dx, dz);
  if (length < 0.05) return null;

  const cx = (x1 + x2) / 2;
  const cz = (z1 + z2) / 2;
  const rotY = -Math.atan2(dz, dx);
  const height = Math.min(wall.height || wallHeight, wallHeight);
  const thick = wall.thick || 0.23;
  const wallMatKey = wall.wallMat || 'wall_pure_white';

  return (
    <group
      position={[cx, elevation, cz]}
      rotation={[0, rotY, 0]}
      onClick={(e) => {
        if (onSelect) {
          e.stopPropagation();
          onSelect(wall);
        }
      }}
    >
      <ParametricApertureWall
        wall={{ ...wall, length, height, thick }}
        openings={openings}
        wallHeight={height}
        wallThick={thick}
        wallMatKey={wallMatKey}
        renderStyle={renderStyle}
        isSelected={isSelected}
        onSelect={onSelect}
      />

      {/* Architectural Base Skirting Board Trim (North & South Faces) */}
      {renderStyle === 'realistic' && (
        <>
          <mesh position={[0, 0.05, thick / 2 + 0.006]} castShadow>
            <boxGeometry args={[length, 0.1, 0.012]} />
            <meshStandardMaterial color="#334155" roughness={0.5} metalness={0.1} />
          </mesh>
          <mesh position={[0, 0.05, -thick / 2 - 0.006]} castShadow>
            <boxGeometry args={[length, 0.1, 0.012]} />
            <meshStandardMaterial color="#334155" roughness={0.5} metalness={0.1} />
          </mesh>
        </>
      )}

      {/* Selected Indicator Outline in 3D */}
      {isSelected && (
        <lineSegments position={[0, height / 2, 0]}>
          <edgesGeometry args={[new THREE.BoxGeometry(length + 0.04, height + 0.04, thick + 0.04)]} />
          <lineBasicMaterial color="#00f0ff" linewidth={3} />
        </lineSegments>
      )}
    </group>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// STRUCTURAL CONCRETE COLUMN / PILLAR
// ─────────────────────────────────────────────────────────────────────────────

export function Column3D({
  column,
  wallHeight = 3.0,
  renderStyle = 'realistic',
  isSelected = false,
  onSelect = null
}) {
  const isRound = column.shape === 'round';
  const size = column.size || 0.4;
  const height = wallHeight;

  const colMat = useMemo(() => {
    return getStyleMaterial({
      color: '#475569',
      roughness: 0.8,
      metalness: 0.1,
      renderStyle,
      isSelected
    });
  }, [renderStyle, isSelected]);

  return (
    <group
      position={[column.x, 0, column.z]}
      onClick={(e) => {
        if (onSelect) {
          e.stopPropagation();
          onSelect(column);
        }
      }}
    >
      {isRound ? (
        <mesh position={[0, height / 2, 0]} castShadow receiveShadow>
          <cylinderGeometry args={[size / 2, size / 2, height, 24]} />
          <primitive object={colMat} attach="material" />
        </mesh>
      ) : (
        <mesh position={[0, height / 2, 0]} castShadow receiveShadow>
          <boxGeometry args={[size, height, size]} />
          <primitive object={colMat} attach="material" />
        </mesh>
      )}

      {/* Decorative Capital and Base Rings */}
      <mesh position={[0, 0.06, 0]}>
        <boxGeometry args={[size + 0.08, 0.12, size + 0.08]} />
        <primitive object={colMat} attach="material" />
      </mesh>
      <mesh position={[0, height - 0.06, 0]}>
        <boxGeometry args={[size + 0.08, 0.12, size + 0.08]} />
        <primitive object={colMat} attach="material" />
      </mesh>
    </group>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// CEILING & LUXURY FALSE CEILING COVE LIGHTING
// ─────────────────────────────────────────────────────────────────────────────

export function Ceiling3D({
  room,
  elevation = 0,
  wallHeight = 3.0,
  mode = 'cove_led', // 'flat' | 'cove_led' | 'none'
  renderStyle = 'realistic'
}) {
  if (mode === 'none') return null;

  const cx = room.x + room.w / 2;
  const cz = room.z + room.d / 2;
  const cy = elevation + wallHeight;

  const ceilingMat = useMemo(() => {
    return getStyleMaterial({
      color: '#f8fafc',
      roughness: 0.9,
      metalness: 0.02,
      renderStyle
    });
  }, [renderStyle]);

  const coveGlowMat = useMemo(() => {
    return new THREE.MeshBasicMaterial({
      color: '#fff3db'
    });
  }, []);

  return (
    <group position={[cx, cy, cz]}>
      {/* Flat Ceiling Main Slab */}
      <mesh position={[0, 0.02, 0]} receiveShadow>
        <boxGeometry args={[room.w, 0.04, room.d]} />
        <primitive object={ceilingMat} attach="material" />
      </mesh>

      {/* Luxury False Ceiling Drop with Cove LED Reveal */}
      {mode === 'cove_led' && room.w > 2.0 && room.d > 2.0 && (
        <group position={[0, -0.1, 0]}>
          {/* Recessed False Ceiling Panel */}
          <mesh receiveShadow>
            <boxGeometry args={[room.w - 0.6, 0.06, room.d - 0.6]} />
            <primitive object={ceilingMat} attach="material" />
          </mesh>

          {/* Glowing Cove LED Strips along the 4 recessed borders */}
          <mesh position={[0, 0.04, -(room.d - 0.55) / 2]}>
            <boxGeometry args={[room.w - 0.65, 0.02, 0.03]} />
            <primitive object={coveGlowMat} attach="material" />
          </mesh>
          <mesh position={[0, 0.04, (room.d - 0.55) / 2]}>
            <boxGeometry args={[room.w - 0.65, 0.02, 0.03]} />
            <primitive object={coveGlowMat} attach="material" />
          </mesh>
          <mesh position={[-(room.w - 0.55) / 2, 0.04, 0]}>
            <boxGeometry args={[0.03, 0.02, room.d - 0.65]} />
            <primitive object={coveGlowMat} attach="material" />
          </mesh>
          <mesh position={[(room.w - 0.55) / 2, 0.04, 0]}>
            <boxGeometry args={[0.03, 0.02, room.d - 0.65]} />
            <primitive object={coveGlowMat} attach="material" />
          </mesh>
        </group>
      )}
    </group>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// ROOM INTERIOR DOWNLIGHTS & SPOTLIGHTS (WARM ARCHITECTURAL AMBIENCE)
// ─────────────────────────────────────────────────────────────────────────────

export function RoomInteriorDownlights({
  rooms,
  timeOfDay = 12,
  elevation = 0,
  wallHeight = 3.0
}) {
  // Turn on interior lights when evening or night (before 7am or after 17:30)
  const isNight = timeOfDay < 6.8 || timeOfDay > 17.5;
  if (!isNight) return null;

  return (
    <group>
      {rooms.map((room) => {
        const cx = room.x + room.w / 2;
        const cz = room.z + room.d / 2;
        const lightY = elevation + wallHeight - 0.2;

        return (
          <group key={`downlight-${room.id}`} position={[cx, lightY, cz]}>
            {/* Recessed Ceiling Fixture Bezel */}
            <mesh position={[0, 0.15, 0]}>
              <cylinderGeometry args={[0.12, 0.12, 0.04, 16]} />
              <meshStandardMaterial color="#0f172a" roughness={0.3} metalness={0.8} />
            </mesh>

            {/* Glowing Bulb Disc */}
            <mesh position={[0, 0.13, 0]}>
              <circleGeometry args={[0.09, 16]} />
              <meshBasicMaterial color="#ffe8c2" />
            </mesh>

            {/* Architectural Warm Downlight */}
            <pointLight
              color="#ffecd1"
              intensity={1.8}
              distance={room.w + room.d}
              decay={2}
              castShadow
              shadow-mapSize-width={512}
              shadow-mapSize-height={512}
              shadow-bias={-0.002}
            />
          </group>
        );
      })}
    </group>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// HIGH-FIDELITY PROCEDURAL 3D ARCHITECTURAL FURNITURE & PROPS
// ─────────────────────────────────────────────────────────────────────────────

export function Detailed3DFurniture({
  item,
  isSelected,
  onSelect,
  elevation = 0,
  renderStyle = 'realistic'
}) {
  const rad = ((item.rot || 0) * Math.PI) / 180;
  const type = item.type || 'sofa';
  const color = item.color || '#1e3a5f';

  const baseMat = useMemo(() => getStyleMaterial({
    color,
    roughness: 0.5,
    metalness: 0.15,
    renderStyle,
    isSelected
  }), [color, renderStyle, isSelected]);

  const woodMat = useMemo(() => getStyleMaterial({
    color: '#4a2e1b',
    roughness: 0.65,
    metalness: 0.05,
    renderStyle
  }), [renderStyle]);

  const fabricMat = useMemo(() => getStyleMaterial({
    color: isSelected ? '#00f0ff' : color,
    roughness: 0.85,
    metalness: 0.05,
    renderStyle
  }), [color, renderStyle, isSelected]);

  const whiteMat = useMemo(() => getStyleMaterial({
    color: '#f8fafc',
    roughness: 0.3,
    metalness: 0.1,
    renderStyle
  }), [renderStyle]);

  const metalMat = useMemo(() => getStyleMaterial({
    color: '#94a3b8',
    roughness: 0.2,
    metalness: 0.9,
    renderStyle
  }), [renderStyle]);

  const glassMat = useMemo(() => getStyleMaterial({
    isGlass: true,
    renderStyle
  }), [renderStyle]);

  return (
    <group
      position={[item.x, elevation, item.z]}
      rotation={[0, rad, 0]}
      onClick={(e) => {
        e.stopPropagation();
        onSelect(item);
      }}
    >
      {/* ────────────────── BED (KING / QUEEN) ────────────────── */}
      {type.includes('bed') && (
        <group>
          {/* Bed Base Platform */}
          <mesh position={[0, 0.15, 0]} castShadow receiveShadow>
            <boxGeometry args={[item.w, 0.3, item.d]} />
            <primitive object={woodMat} attach="material" />
          </mesh>

          {/* Upholstered Tufted Headboard */}
          <mesh position={[0, (item.h || 1.0) / 2 + 0.1, -item.d / 2 + 0.08]} castShadow receiveShadow>
            <boxGeometry args={[item.w + 0.1, item.h || 1.0, 0.16]} />
            <primitive object={fabricMat} attach="material" />
          </mesh>

          {/* Plush Mattress */}
          <mesh position={[0, 0.38, 0.04]} castShadow receiveShadow>
            <boxGeometry args={[item.w - 0.12, 0.26, item.d - 0.2]} />
            <primitive object={whiteMat} attach="material" />
          </mesh>

          {/* Dual Pillows */}
          <mesh position={[-item.w * 0.26, 0.55, -item.d / 2 + 0.42]} rotation={[0.2, 0, 0]} castShadow>
            <boxGeometry args={[item.w * 0.38, 0.12, 0.42]} />
            <primitive object={whiteMat} attach="material" />
          </mesh>
          <mesh position={[item.w * 0.26, 0.55, -item.d / 2 + 0.42]} rotation={[0.2, 0, 0]} castShadow>
            <boxGeometry args={[item.w * 0.38, 0.12, 0.42]} />
            <primitive object={whiteMat} attach="material" />
          </mesh>

          {/* Duvet / Folded Bed Runner */}
          <mesh position={[0, 0.52, 0.28]} castShadow receiveShadow>
            <boxGeometry args={[item.w - 0.1, 0.04, item.d * 0.52]} />
            <primitive object={fabricMat} attach="material" />
          </mesh>

          {/* Cantilevered Floating Nightstands */}
          <mesh position={[-item.w / 2 - 0.28, 0.22, -item.d / 2 + 0.35]} castShadow>
            <boxGeometry args={[0.45, 0.35, 0.42]} />
            <primitive object={woodMat} attach="material" />
          </mesh>
          <mesh position={[item.w / 2 + 0.28, 0.22, -item.d / 2 + 0.35]} castShadow>
            <boxGeometry args={[0.45, 0.35, 0.42]} />
            <primitive object={woodMat} attach="material" />
          </mesh>
        </group>
      )}

      {/* ────────────────── SOFA / SECTIONAL ────────────────── */}
      {type.includes('sofa') && (
        <group>
          {/* Main Seat Base Cushion */}
          <mesh position={[0, 0.25, 0.05]} castShadow receiveShadow>
            <boxGeometry args={[item.w, 0.28, item.d * 0.8]} />
            <primitive object={fabricMat} attach="material" />
          </mesh>

          {/* High Padded Backrest */}
          <mesh position={[0, 0.58, -item.d / 2 + 0.12]} castShadow receiveShadow>
            <boxGeometry args={[item.w, 0.48, item.d * 0.25]} />
            <primitive object={fabricMat} attach="material" />
          </mesh>

          {/* Left Armrest */}
          <mesh position={[-item.w / 2 + 0.1, 0.42, 0]} castShadow receiveShadow>
            <boxGeometry args={[0.2, 0.35, item.d]} />
            <primitive object={fabricMat} attach="material" />
          </mesh>

          {/* Right Armrest */}
          <mesh position={[item.w / 2 - 0.1, 0.42, 0]} castShadow receiveShadow>
            <boxGeometry args={[0.2, 0.35, item.d]} />
            <primitive object={fabricMat} attach="material" />
          </mesh>

          {/* 4 Wooden Tapered Legs */}
          {[-item.w / 2 + 0.15, item.w / 2 - 0.15].map((lx, i) =>
            [-item.d / 2 + 0.15, item.d / 2 - 0.15].map((lz, j) => (
              <mesh key={`sofa-leg-${i}-${j}`} position={[lx, 0.06, lz]}>
                <cylinderGeometry args={[0.025, 0.018, 0.12, 12]} />
                <primitive object={woodMat} attach="material" />
              </mesh>
            ))
          )}
        </group>
      )}

      {/* ────────────────── DINING TABLE & CHAIRS ────────────────── */}
      {type === 'dining_set' && (
        <group>
          {/* Solid Wood Tabletop */}
          <mesh position={[0, 0.74, 0]} castShadow receiveShadow>
            <boxGeometry args={[item.w, 0.06, item.d]} />
            <primitive object={woodMat} attach="material" />
          </mesh>

          {/* 4 Table Legs */}
          {[-item.w / 2 + 0.08, item.w / 2 - 0.08].map((lx, i) =>
            [-item.d / 2 + 0.08, item.d / 2 - 0.08].map((lz, j) => (
              <mesh key={`dt-leg-${i}-${j}`} position={[lx, 0.35, lz]} castShadow>
                <boxGeometry args={[0.08, 0.7, 0.08]} />
                <primitive object={woodMat} attach="material" />
              </mesh>
            ))
          )}

          {/* 6 Dining Chairs */}
          {[-item.w * 0.32, 0, item.w * 0.32].map((cx, idx) => (
            <React.Fragment key={`chair-pair-${idx}`}>
              {/* North Chair */}
              <group position={[cx, 0, -item.d / 2 - 0.28]}>
                <mesh position={[0, 0.44, 0]} castShadow>
                  <boxGeometry args={[0.42, 0.05, 0.42]} />
                  <primitive object={fabricMat} attach="material" />
                </mesh>
                <mesh position={[0, 0.72, -0.18]} castShadow>
                  <boxGeometry args={[0.42, 0.48, 0.05]} />
                  <primitive object={woodMat} attach="material" />
                </mesh>
              </group>
              {/* South Chair */}
              <group position={[cx, 0, item.d / 2 + 0.28]}>
                <mesh position={[0, 0.44, 0]} castShadow>
                  <boxGeometry args={[0.42, 0.05, 0.42]} />
                  <primitive object={fabricMat} attach="material" />
                </mesh>
                <mesh position={[0, 0.72, 0.18]} castShadow>
                  <boxGeometry args={[0.42, 0.48, 0.05]} />
                  <primitive object={woodMat} attach="material" />
                </mesh>
              </group>
            </React.Fragment>
          ))}
        </group>
      )}

      {/* ────────────────── COFFEE TABLE ────────────────── */}
      {type === 'table' && (
        <group>
          {/* Calacatta Marble Top Slab */}
          <mesh position={[0, (item.h || 0.45) - 0.02, 0]} castShadow receiveShadow>
            <boxGeometry args={[item.w, 0.04, item.d]} />
            <primitive object={whiteMat} attach="material" />
          </mesh>
          {/* Minimalist Metal Sled Legs */}
          <mesh position={[-item.w / 2 + 0.1, (item.h || 0.45) / 2, 0]} castShadow>
            <boxGeometry args={[0.04, (item.h || 0.45) - 0.04, item.d * 0.85]} />
            <primitive object={metalMat} attach="material" />
          </mesh>
          <mesh position={[item.w / 2 - 0.1, (item.h || 0.45) / 2, 0]} castShadow>
            <boxGeometry args={[0.04, (item.h || 0.45) - 0.04, item.d * 0.85]} />
            <primitive object={metalMat} attach="material" />
          </mesh>
        </group>
      )}

      {/* ────────────────── KITCHEN ISLAND & COUNTERS ────────────────── */}
      {(type === 'kitchen_island' || type.includes('kitchen')) && (
        <group>
          {/* Base Cabinet Units with Handles */}
          <mesh position={[0, 0.42, 0]} castShadow receiveShadow>
            <boxGeometry args={[item.w, 0.84, item.d]} />
            <primitive object={baseMat} attach="material" />
          </mesh>
          {/* Polished Quartz / Waterfall Countertop */}
          <mesh position={[0, 0.88, 0]} castShadow receiveShadow>
            <boxGeometry args={[item.w + 0.06, 0.06, item.d + 0.06]} />
            <primitive object={whiteMat} attach="material" />
          </mesh>
          {/* Undermount Stainless Sink Basin */}
          <mesh position={[item.w * 0.22, 0.89, 0]}>
            <boxGeometry args={[0.6, 0.02, 0.42]} />
            <primitive object={metalMat} attach="material" />
          </mesh>
          {/* Gooseneck Faucet */}
          <mesh position={[item.w * 0.22, 1.05, -0.18]} castShadow>
            <cylinderGeometry args={[0.015, 0.015, 0.28, 12]} />
            <primitive object={metalMat} attach="material" />
          </mesh>
        </group>
      )}

      {/* ────────────────── REFRIGERATOR ────────────────── */}
      {type === 'kitchen_fridge' && (
        <group>
          {/* Refrigerator Body */}
          <mesh position={[0, (item.h || 1.85) / 2, 0]} castShadow receiveShadow>
            <boxGeometry args={[item.w, item.h || 1.85, item.d]} />
            <primitive object={metalMat} attach="material" />
          </mesh>
          {/* Vertical Door Split Reveal Line */}
          <mesh position={[0, (item.h || 1.85) * 0.65, item.d / 2 + 0.01]}>
            <boxGeometry args={[0.01, (item.h || 1.85) * 0.65, 0.01]} />
            <meshBasicMaterial color="#0f172a" />
          </mesh>
          {/* Brushed Metal Vertical Handles */}
          <mesh position={[-0.05, (item.h || 1.85) * 0.6, item.d / 2 + 0.03]} castShadow>
            <cylinderGeometry args={[0.012, 0.012, 0.6, 12]} />
            <primitive object={metalMat} attach="material" />
          </mesh>
          <mesh position={[0.05, (item.h || 1.85) * 0.6, item.d / 2 + 0.03]} castShadow>
            <cylinderGeometry args={[0.012, 0.012, 0.6, 12]} />
            <primitive object={metalMat} attach="material" />
          </mesh>
        </group>
      )}

      {/* ────────────────── BATHROOM VANITY ────────────────── */}
      {type === 'bath_vanity' && (
        <group>
          {/* Floating Base Cabinet */}
          <mesh position={[0, 0.52, 0]} castShadow receiveShadow>
            <boxGeometry args={[item.w, 0.55, item.d]} />
            <primitive object={baseMat} attach="material" />
          </mesh>
          {/* Marble Vanity Top */}
          <mesh position={[0, 0.81, 0]} castShadow receiveShadow>
            <boxGeometry args={[item.w + 0.04, 0.04, item.d + 0.04]} />
            <primitive object={whiteMat} attach="material" />
          </mesh>
          {/* Ceramic Vessel Sink */}
          <mesh position={[0, 0.88, 0]} castShadow>
            <boxGeometry args={[0.55, 0.12, 0.38]} />
            <primitive object={whiteMat} attach="material" />
          </mesh>
          {/* Tall Chrome Faucet */}
          <mesh position={[0, 1.02, -0.16]} castShadow>
            <cylinderGeometry args={[0.014, 0.014, 0.22, 12]} />
            <primitive object={metalMat} attach="material" />
          </mesh>
          {/* Backlit LED Vanity Mirror */}
          <mesh position={[0, 1.5, -item.d / 2 + 0.02]} castShadow>
            <boxGeometry args={[item.w * 0.85, 0.85, 0.03]} />
            <primitive object={whiteMat} attach="material" />
          </mesh>
        </group>
      )}

      {/* ────────────────── FREESTANDING LUXURY BATHTUB ────────────────── */}
      {type === 'luxury_bathtub' && (
        <group position={[0, 0.32, 0]}>
          {/* Oval Tub Outer Shell */}
          <mesh castShadow receiveShadow>
            <cylinderGeometry args={[item.w / 2, item.w / 2.3, item.h || 0.65, 32]} />
            <primitive object={whiteMat} attach="material" />
          </mesh>
          {/* Floor-Mounted Chrome Tub Mixer Tap */}
          <mesh position={[item.w / 2 + 0.12, 0.35, 0]} castShadow>
            <cylinderGeometry args={[0.02, 0.02, 0.9, 12]} />
            <primitive object={metalMat} attach="material" />
          </mesh>
        </group>
      )}

      {/* ────────────────── WORK DESK & ERGONOMIC CHAIR ────────────────── */}
      {type === 'desk' && (
        <group>
          {/* Walnut Desktop Surface */}
          <mesh position={[0, 0.72, 0]} castShadow receiveShadow>
            <boxGeometry args={[item.w, 0.04, item.d]} />
            <primitive object={woodMat} attach="material" />
          </mesh>
          {/* Steel Sled Frame Legs */}
          <mesh position={[-item.w / 2 + 0.06, 0.35, 0]} castShadow>
            <boxGeometry args={[0.05, 0.7, item.d * 0.9]} />
            <primitive object={metalMat} attach="material" />
          </mesh>
          <mesh position={[item.w / 2 - 0.06, 0.35, 0]} castShadow>
            <boxGeometry args={[0.05, 0.7, item.d * 0.9]} />
            <primitive object={metalMat} attach="material" />
          </mesh>
          {/* Swivel Task Chair */}
          <group position={[0, 0, item.d / 2 + 0.38]}>
            <mesh position={[0, 0.46, 0]} castShadow>
              <boxGeometry args={[0.48, 0.08, 0.48]} />
              <primitive object={fabricMat} attach="material" />
            </mesh>
            <mesh position={[0, 0.78, 0.2]} castShadow>
              <boxGeometry args={[0.46, 0.52, 0.06]} />
              <primitive object={fabricMat} attach="material" />
            </mesh>
            <mesh position={[0, 0.22, 0]} castShadow>
              <cylinderGeometry args={[0.025, 0.025, 0.42, 12]} />
              <primitive object={metalMat} attach="material" />
            </mesh>
          </group>
        </group>
      )}

      {/* ────────────────── WARDROBE ────────────────── */}
      {type === 'wardrobe' && (
        <group>
          {/* Wardrobe Tall Body */}
          <mesh position={[0, (item.h || 2.4) / 2, 0]} castShadow receiveShadow>
            <boxGeometry args={[item.w, item.h || 2.4, item.d]} />
            <primitive object={woodMat} attach="material" />
          </mesh>
          {/* Vertical Panel Grooves */}
          {[-item.w / 4, 0, item.w / 4].map((px, i) => (
            <mesh key={`wardrobe-groove-${i}`} position={[px, (item.h || 2.4) / 2, item.d / 2 + 0.005]}>
              <boxGeometry args={[0.015, (item.h || 2.4) * 0.92, 0.01]} />
              <meshBasicMaterial color="#1a120b" />
            </mesh>
          ))}
        </group>
      )}

      {/* ────────────────── INDOOR POTTED PLANT ────────────────── */}
      {type === 'indoor_plant' && (
        <group>
          {/* Ceramic Fluted Planter */}
          <mesh position={[0, 0.28, 0]} castShadow>
            <cylinderGeometry args={[0.22, 0.16, 0.55, 20]} />
            <primitive object={whiteMat} attach="material" />
          </mesh>
          {/* Green Monstera Foliage */}
          <mesh position={[0, 0.85, 0]} castShadow>
            <sphereGeometry args={[0.38, 16, 16]} />
            <meshStandardMaterial color="#166534" roughness={0.7} metalness={0.05} />
          </mesh>
        </group>
      )}

      {/* ────────────────── CAR (SEDAN / SUV) ────────────────── */}
      {(type === 'car_sedan' || type === 'car_suv') && (
        <group>
          {/* Lower Aerodynamic Chassis */}
          <mesh position={[0, 0.45, 0]} castShadow receiveShadow>
            <boxGeometry args={[item.w, 0.55, item.d]} />
            <primitive object={baseMat} attach="material" />
          </mesh>
          {/* Glass Greenhouse Cabin */}
          <mesh position={[0, (item.h || 1.6) * 0.68, -0.2]} castShadow>
            <boxGeometry args={[item.w * 0.88, (item.h || 1.6) * 0.45, item.d * 0.54]} />
            <primitive object={glassMat} attach="material" />
          </mesh>
          {/* LED Headlights */}
          <mesh position={[-item.w * 0.35, 0.48, item.d / 2]}>
            <boxGeometry args={[0.22, 0.12, 0.04]} />
            <meshBasicMaterial color="#fef08a" />
          </mesh>
          <mesh position={[item.w * 0.35, 0.48, item.d / 2]}>
            <boxGeometry args={[0.22, 0.12, 0.04]} />
            <meshBasicMaterial color="#fef08a" />
          </mesh>
          {/* Red Taillights */}
          <mesh position={[-item.w * 0.35, 0.48, -item.d / 2]}>
            <boxGeometry args={[0.22, 0.1, 0.04]} />
            <meshBasicMaterial color="#ef4444" />
          </mesh>
          <mesh position={[item.w * 0.35, 0.48, -item.d / 2]}>
            <boxGeometry args={[0.22, 0.1, 0.04]} />
            <meshBasicMaterial color="#ef4444" />
          </mesh>
          {/* 4 Wheels with Alloy Rims */}
          {[-item.w / 2, item.w / 2].map((wx, i) =>
            [-item.d * 0.32, item.d * 0.32].map((wz, j) => (
              <mesh key={`wheel-${i}-${j}`} position={[wx, 0.28, wz]} rotation={[0, 0, Math.PI / 2]} castShadow>
                <cylinderGeometry args={[0.28, 0.28, 0.18, 20]} />
                <meshStandardMaterial color="#090d14" roughness={0.9} />
              </mesh>
            ))
          )}
        </group>
      )}

      {/* ────────────────── ARCHITECTURAL STAIRCASE ────────────────── */}
      {type.includes('stair') && (
        <Staircase3D
          item={item}
          renderStyle={renderStyle}
          isSelected={isSelected}
        />
      )}

      {/* ────────────────── TV MEDIA WALL CONSOLE ────────────────── */}
      {(type.includes('media') || type.includes('tv')) && (
        <MediaWallUnit3D
          item={item}
          renderStyle={renderStyle}
          isSelected={isSelected}
        />
      )}

      {/* ────────────────── KITCHEN COOKTOP & HOOD ────────────────── */}
      {(type.includes('cooktop') || type.includes('stove')) && (
        <Cooktop3D
          item={item}
          renderStyle={renderStyle}
          isSelected={isSelected}
        />
      )}

      {/* ────────────────── SCANDINAVIAN LOUNGE ARMCHAIR ────────────────── */}
      {(type === 'lounge_chair' || type === 'accent_chair') && (
        <LoungeChair3D
          item={item}
          renderStyle={renderStyle}
          isSelected={isSelected}
        />
      )}

      {/* ────────────────── FLOOR LAMP ────────────────── */}
      {(type === 'floor_lamp' || type.includes('lamp')) && (
        <FloorLamp3D
          item={item}
          renderStyle={renderStyle}
          isSelected={isSelected}
        />
      )}

      {/* ────────────────── FALLBACK BOX ────────────────── */}
      {!type.includes('bed') &&
        !type.includes('sofa') &&
        type !== 'dining_set' &&
        type !== 'table' &&
        !type.includes('kitchen') &&
        type !== 'bath_vanity' &&
        type !== 'luxury_bathtub' &&
        type !== 'desk' &&
        type !== 'wardrobe' &&
        type !== 'indoor_plant' &&
        !type.includes('car') &&
        !type.includes('stair') &&
        !type.includes('media') &&
        !type.includes('tv') &&
        !type.includes('cooktop') &&
        !type.includes('stove') &&
        type !== 'lounge_chair' &&
        type !== 'accent_chair' &&
        type !== 'floor_lamp' &&
        !type.includes('lamp') && (
          <mesh position={[0, (item.h || 0.8) / 2, 0]} castShadow receiveShadow>
            <boxGeometry args={[item.w, item.h || 0.8, item.d]} />
            <primitive object={baseMat} attach="material" />
          </mesh>
        )}

      {/* Clearance Ring Floor Projection */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.03, 0]}>
        <ringGeometry args={[item.w / 2 + 0.1, item.w / 2 + 0.24, 32]} />
        <meshBasicMaterial color="#00f0ff" transparent opacity={isSelected ? 0.75 : 0.25} />
      </mesh>
    </group>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// COMPONENT: ARCHITECTURAL STAIRCASE 3D
// ─────────────────────────────────────────────────────────────────────────────

export function Staircase3D({
  item,
  wallHeight = 3.0,
  renderStyle = 'realistic',
  isSelected = false
}) {
  const steps = 14;
  const totalH = item.h || wallHeight || 3.0;
  const stepH = totalH / steps;
  const stepD = (item.d || 3.2) / steps;
  const stepW = item.w || 1.1;

  const treadMat = useMemo(() => getStyleMaterial({
    color: '#8c6d48',
    roughness: 0.5,
    metalness: 0.05,
    renderStyle,
    isSelected
  }), [renderStyle, isSelected]);

  const glassMat = useMemo(() => getStyleMaterial({
    isGlass: true,
    renderStyle
  }), [renderStyle]);

  const handrailMat = useMemo(() => getStyleMaterial({
    color: '#3e2716',
    roughness: 0.4,
    metalness: 0.2,
    renderStyle
  }), [renderStyle]);

  const metalMat = useMemo(() => getStyleMaterial({
    color: '#1e293b',
    roughness: 0.2,
    metalness: 0.9,
    renderStyle
  }), [renderStyle]);

  return (
    <group position={[0, 0, 0]}>
      {/* Flight of Steps */}
      {Array.from({ length: steps }).map((_, i) => {
        const stepY = i * stepH + stepH / 2;
        const stepZ = -item.d / 2 + i * stepD + stepD / 2;
        return (
          <group key={`stair-step-${i}`}>
            {/* Step Tread Slab */}
            <mesh position={[0, stepY, stepZ]} castShadow receiveShadow>
              <boxGeometry args={[stepW, stepH * 0.92, stepD * 1.05]} />
              <primitive object={treadMat} attach="material" />
            </mesh>
            {/* Bullnose Trim */}
            <mesh position={[0, stepY + stepH * 0.44, stepZ + stepD * 0.52]} castShadow>
              <boxGeometry args={[stepW + 0.02, 0.025, 0.03]} />
              <primitive object={treadMat} attach="material" />
            </mesh>
          </group>
        );
      })}

      {/* Structural Slanted Steel Stringer Beams */}
      <mesh
        position={[-stepW / 2 + 0.06, totalH / 2 - 0.15, 0]}
        rotation={[Math.atan2(totalH, item.d), 0, 0]}
        castShadow
      >
        <boxGeometry args={[0.08, 0.2, Math.hypot(totalH, item.d)]} />
        <primitive object={metalMat} attach="material" />
      </mesh>
      <mesh
        position={[stepW / 2 - 0.06, totalH / 2 - 0.15, 0]}
        rotation={[Math.atan2(totalH, item.d), 0, 0]}
        castShadow
      >
        <boxGeometry args={[0.08, 0.2, Math.hypot(totalH, item.d)]} />
        <primitive object={metalMat} attach="material" />
      </mesh>

      {/* Tempered Glass Balustrade Guard */}
      <mesh
        position={[stepW / 2 + 0.02, totalH / 2 + 0.45, 0]}
        rotation={[Math.atan2(totalH, item.d), 0, 0]}
      >
        <boxGeometry args={[0.015, 0.9, Math.hypot(totalH, item.d)]} />
        <primitive object={glassMat} attach="material" />
      </mesh>

      {/* Continuous Timber Handrail */}
      <mesh
        position={[stepW / 2 + 0.02, totalH / 2 + 0.9, 0]}
        rotation={[Math.atan2(totalH, item.d), 0, 0]}
        castShadow
      >
        <cylinderGeometry args={[0.025, 0.025, Math.hypot(totalH, item.d), 16]} />
        <primitive object={handrailMat} attach="material" />
      </mesh>
    </group>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// COMPONENT: TV MEDIA WALL UNIT 3D
// ─────────────────────────────────────────────────────────────────────────────

export function MediaWallUnit3D({
  item,
  renderStyle = 'realistic',
  isSelected = false
}) {
  const w = item.w || 2.4;
  const d = item.d || 0.45;
  const h = item.h || 1.8;

  const woodMat = useMemo(() => getStyleMaterial({
    color: '#2a1a10',
    roughness: 0.6,
    metalness: 0.05,
    renderStyle,
    isSelected
  }), [renderStyle, isSelected]);

  const marbleMat = useMemo(() => getStyleMaterial({
    color: '#e2e8f0',
    roughness: 0.15,
    metalness: 0.15,
    renderStyle
  }), [renderStyle]);

  const screenMat = useMemo(() => getStyleMaterial({
    color: '#080c14',
    roughness: 0.1,
    metalness: 0.8,
    renderStyle
  }), [renderStyle]);

  return (
    <group position={[0, 0, 0]}>
      {/* Floating Low-profile Credenza */}
      <mesh position={[0, 0.25, 0]} castShadow receiveShadow>
        <boxGeometry args={[w, 0.38, d]} />
        <primitive object={woodMat} attach="material" />
      </mesh>

      {/* Architectural Acoustic Fluted Wood Backdrop */}
      <mesh position={[0, h / 2 + 0.25, -d / 2 + 0.02]} castShadow receiveShadow>
        <boxGeometry args={[w * 0.95, h * 0.85, 0.04]} />
        <primitive object={woodMat} attach="material" />
      </mesh>

      {/* Marble Feature Inset */}
      <mesh position={[0, h * 0.65, -d / 2 + 0.05]} castShadow>
        <boxGeometry args={[w * 0.75, h * 0.55, 0.02]} />
        <primitive object={marbleMat} attach="material" />
      </mesh>

      {/* Ambient LED Backlight Strip */}
      <mesh position={[0, h * 0.65, -d / 2 + 0.065]}>
        <boxGeometry args={[w * 0.68, h * 0.46, 0.005]} />
        <meshBasicMaterial color="#fae8a4" />
      </mesh>

      {/* Ultra-Thin 4K OLED TV Display */}
      <mesh position={[0, h * 0.65, -d / 2 + 0.08]} castShadow>
        <boxGeometry args={[w * 0.64, h * 0.42, 0.02]} />
        <primitive object={screenMat} attach="material" />
      </mesh>

      {/* Hi-Fi Soundbar */}
      <mesh position={[0, 0.48, -d / 2 + 0.12]} castShadow>
        <boxGeometry args={[w * 0.45, 0.06, 0.08]} />
        <meshStandardMaterial color="#0f172a" roughness={0.3} metalness={0.7} />
      </mesh>
    </group>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// COMPONENT: KITCHEN COOKTOP & HOOD 3D
// ─────────────────────────────────────────────────────────────────────────────

export function Cooktop3D({
  item,
  renderStyle = 'realistic',
  isSelected = false
}) {
  const w = item.w || 1.2;
  const d = item.d || 0.7;

  const islandMat = useMemo(() => getStyleMaterial({
    color: '#0f172a',
    roughness: 0.4,
    metalness: 0.15,
    renderStyle,
    isSelected
  }), [renderStyle, isSelected]);

  const quartzMat = useMemo(() => getStyleMaterial({
    color: '#f8fafc',
    roughness: 0.15,
    metalness: 0.1,
    renderStyle
  }), [renderStyle]);

  const glassTopMat = useMemo(() => getStyleMaterial({
    color: '#090d16',
    roughness: 0.05,
    metalness: 0.8,
    renderStyle
  }), [renderStyle]);

  const stainlessMat = useMemo(() => getStyleMaterial({
    color: '#e2e8f0',
    roughness: 0.2,
    metalness: 0.95,
    renderStyle
  }), [renderStyle]);

  return (
    <group position={[0, 0, 0]}>
      {/* Island Cabinet Base */}
      <mesh position={[0, 0.44, 0]} castShadow receiveShadow>
        <boxGeometry args={[w, 0.88, d]} />
        <primitive object={islandMat} attach="material" />
      </mesh>

      {/* Quartz Countertop Slab */}
      <mesh position={[0, 0.9, 0]} castShadow receiveShadow>
        <boxGeometry args={[w + 0.08, 0.05, d + 0.08]} />
        <primitive object={quartzMat} attach="material" />
      </mesh>

      {/* Induction Ceramic Cooktop Surface */}
      <mesh position={[0, 0.93, 0]} castShadow>
        <boxGeometry args={[w * 0.7, 0.015, d * 0.7]} />
        <primitive object={glassTopMat} attach="material" />
      </mesh>

      {/* 4 Induction Heating Rings */}
      {[-0.2, 0.2].map((bx, i) =>
        [-0.15, 0.15].map((bz, j) => (
          <mesh key={`burner-${i}-${j}`} position={[bx, 0.94, bz]} rotation={[-Math.PI / 2, 0, 0]}>
            <ringGeometry args={[0.07, 0.085, 24]} />
            <meshBasicMaterial color="#b45309" />
          </mesh>
        ))
      )}

      {/* Suspended Range Hood / Chimney */}
      <group position={[0, 2.15, 0]}>
        <mesh castShadow>
          <boxGeometry args={[w * 0.75, 0.12, d * 0.75]} />
          <primitive object={stainlessMat} attach="material" />
        </mesh>
        <mesh position={[0, 0.45, 0]} castShadow>
          <boxGeometry args={[0.28, 0.8, 0.28]} />
          <primitive object={stainlessMat} attach="material" />
        </mesh>
        <pointLight position={[0, -0.1, 0]} intensity={1.8} distance={2.5} color="#fffbeb" />
      </group>
    </group>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// COMPONENT: SCANDINAVIAN LOUNGE ARMCHAIR 3D
// ─────────────────────────────────────────────────────────────────────────────

export function LoungeChair3D({
  item,
  renderStyle = 'realistic',
  isSelected = false
}) {
  const w = item.w || 0.85;
  const d = item.d || 0.85;
  const color = item.color || '#334155';

  const fabricMat = useMemo(() => getStyleMaterial({
    color: isSelected ? '#00f0ff' : color,
    roughness: 0.85,
    metalness: 0.05,
    renderStyle
  }), [color, renderStyle, isSelected]);

  const woodMat = useMemo(() => getStyleMaterial({
    color: '#8c6d48',
    roughness: 0.6,
    metalness: 0.05,
    renderStyle
  }), [renderStyle]);

  return (
    <group position={[0, 0, 0]}>
      {/* Padded Seat Cushion */}
      <mesh position={[0, 0.38, 0.02]} castShadow receiveShadow>
        <boxGeometry args={[w, 0.18, d * 0.85]} />
        <primitive object={fabricMat} attach="material" />
      </mesh>

      {/* Curved Backrest */}
      <mesh position={[0, 0.68, -d / 2 + 0.12]} rotation={[-0.15, 0, 0]} castShadow receiveShadow>
        <boxGeometry args={[w, 0.48, 0.16]} />
        <primitive object={fabricMat} attach="material" />
      </mesh>

      {/* Armrests */}
      <mesh position={[-w / 2 + 0.07, 0.52, 0]} castShadow>
        <boxGeometry args={[0.14, 0.28, d * 0.75]} />
        <primitive object={fabricMat} attach="material" />
      </mesh>
      <mesh position={[w / 2 - 0.07, 0.52, 0]} castShadow>
        <boxGeometry args={[0.14, 0.28, d * 0.75]} />
        <primitive object={fabricMat} attach="material" />
      </mesh>

      {/* 4 Tapered Wood Legs */}
      {[-w / 2 + 0.12, w / 2 - 0.12].map((lx, i) =>
        [-d / 2 + 0.12, d / 2 - 0.12].map((lz, j) => (
          <mesh
            key={`leg-${i}-${j}`}
            position={[lx, 0.14, lz]}
            rotation={[lz > 0 ? 0.12 : -0.12, 0, lx > 0 ? -0.12 : 0.12]}
            castShadow
          >
            <cylinderGeometry args={[0.022, 0.015, 0.28, 12]} />
            <primitive object={woodMat} attach="material" />
          </mesh>
        ))
      )}
    </group>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// COMPONENT: ARCHITECTURAL FLOOR LAMP 3D
// ─────────────────────────────────────────────────────────────────────────────

export function FloorLamp3D({
  item,
  renderStyle = 'realistic',
  isSelected = false
}) {
  const metalMat = useMemo(() => getStyleMaterial({
    color: '#d4af37',
    roughness: 0.25,
    metalness: 0.9,
    renderStyle,
    isSelected
  }), [renderStyle, isSelected]);

  const shadeMat = useMemo(() => getStyleMaterial({
    color: '#fffbeb',
    roughness: 0.7,
    metalness: 0.05,
    renderStyle
  }), [renderStyle]);

  return (
    <group position={[0, 0, 0]}>
      {/* Weighted Brass Disc Base */}
      <mesh position={[0, 0.02, 0]} castShadow>
        <cylinderGeometry args={[0.22, 0.24, 0.04, 24]} />
        <primitive object={metalMat} attach="material" />
      </mesh>
      {/* Slim Vertical Stem */}
      <mesh position={[0, 0.85, 0]} castShadow>
        <cylinderGeometry args={[0.015, 0.015, 1.7, 12]} />
        <primitive object={metalMat} attach="material" />
      </mesh>
      {/* Conical Lamp Shade */}
      <mesh position={[0, 1.62, 0]} castShadow>
        <cylinderGeometry args={[0.18, 0.26, 0.32, 24]} />
        <primitive object={shadeMat} attach="material" />
      </mesh>
      {/* Warm Ambient Point Light */}
      <pointLight position={[0, 1.55, 0]} intensity={1.5} distance={3.8} color="#fae8a4" />
    </group>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// COMPONENT: ARCHITECTURAL EXTERIOR LANDSCAPE (GARDEN, PATIO, PERIMETER)
// ─────────────────────────────────────────────────────────────────────────────

export function ArchitecturalLandscape({
  plotWidth = 9.12,
  plotDepth = 22.91
}) {
  const lawnW = Math.max(40, plotWidth * 3.5);
  const lawnD = Math.max(50, plotDepth * 2.5);

  return (
    <group position={[0, -0.04, 0]}>
      {/* Manicured Lawn Grass Ground */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <planeGeometry args={[lawnW, lawnD]} />
        <meshStandardMaterial color="#1a3220" roughness={0.92} metalness={0.02} />
      </mesh>

      {/* Paved Stone Perimeter Plinth / Walkway */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.01, 0]} receiveShadow>
        <planeGeometry args={[plotWidth + 3.0, plotDepth + 3.0]} />
        <meshStandardMaterial color="#334155" roughness={0.7} metalness={0.1} />
      </mesh>

      {/* Clean Exterior Property Boundary Outline */}
      <lineSegments position={[0, 0.05, 0]}>
        <edgesGeometry args={[new THREE.BoxGeometry(plotWidth + 3.0, 0.1, plotDepth + 3.0)]} />
        <lineBasicMaterial color="#fae8a4" transparent opacity={0.4} />
      </lineSegments>
    </group>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// COMPREHENSIVE ARCHITECTURAL 3D ROOM (WALLS, FLOOR, OPENINGS, CEILING)
// ─────────────────────────────────────────────────────────────────────────────

export function Architectural3DRoom({
  room,
  isSelected,
  onSelect,
  viewMode = '3d_axo',
  unit = 'imperial',
  wallCutHeight = 3.0,
  elevation = 0,
  renderStyle = 'realistic',
  ceilingMode = 'cove_led'
}) {
  const meshRef = useRef();

  const floorMat = useMemo(() => {
    const preset = ARCH_MATERIALS[room.floorMat] || ARCH_MATERIALS.floor_calacatta;
    return getStyleMaterial({
      color: preset.color,
      roughness: preset.roughness,
      metalness: preset.metalness,
      renderStyle
    });
  }, [room.floorMat, renderStyle]);

  const height = Math.min(room.h || 3.0, wallCutHeight);
  const thick = room.wallThick || 0.2;
  const cx = room.x + room.w / 2;
  const cz = room.z + room.d / 2;
  const cy = elevation;

  // Derive openings per wall side:
  // Use room.openings array if present, or generate default door aperture from room.doorSide
  const roomOpenings = room.openings || [];
  const getSideOpenings = (side) => {
    const explicit = roomOpenings.filter((op) => op.side === side);
    if (explicit.length > 0) return explicit;
    if (room.doorSide === side) {
      return [{ id: `${room.id}-door-${side}`, type: 'door', style: 'single', side, offset: 0.5, w: 0.9, h: 2.1 }];
    }
    return [];
  };

  const northOpenings = getSideOpenings('north');
  const southOpenings = getSideOpenings('south');
  const westOpenings = getSideOpenings('west');
  const eastOpenings = getSideOpenings('east');

  return (
    <group
      ref={meshRef}
      onClick={(e) => {
        e.stopPropagation();
        onSelect(room);
      }}
    >
      {/* 1. Room Floor Slab */}
      <mesh
        rotation={[-Math.PI / 2, 0, 0]}
        position={[cx, cy + 0.015, cz]}
        receiveShadow
      >
        <planeGeometry args={[room.w, room.d]} />
        <primitive object={floorMat} attach="material" />
      </mesh>

      {/* 2. Selected Room Highlighting Bounding Outline */}
      {isSelected && (
        <lineSegments position={[cx, cy + 0.03, cz]}>
          <edgesGeometry args={[new THREE.BoxGeometry(room.w, 0.05, room.d)]} />
          <lineBasicMaterial color="#00f0ff" linewidth={3} />
        </lineSegments>
      )}

      {/* 3. North Wall */}
      {room.doorSide !== 'open' && (
        <group position={[cx, cy, room.z + thick / 2]}>
          <ParametricApertureWall
            wall={{ length: room.w, height, thick }}
            openings={northOpenings}
            wallHeight={height}
            wallThick={thick}
            wallMatKey={room.wallMat}
            renderStyle={renderStyle}
            isSelected={isSelected}
          />
        </group>
      )}

      {/* 4. South Wall */}
      {room.doorSide !== 'open' && (
        <group position={[cx, cy, room.z + room.d - thick / 2]}>
          <ParametricApertureWall
            wall={{ length: room.w, height, thick }}
            openings={southOpenings}
            wallHeight={height}
            wallThick={thick}
            wallMatKey={room.wallMat}
            renderStyle={renderStyle}
            isSelected={isSelected}
          />
        </group>
      )}

      {/* 5. West Wall */}
      {room.doorSide !== 'open' && (
        <group position={[room.x + thick / 2, cy, cz]} rotation={[0, Math.PI / 2, 0]}>
          <ParametricApertureWall
            wall={{ length: room.d, height, thick }}
            openings={westOpenings}
            wallHeight={height}
            wallThick={thick}
            wallMatKey={room.wallMat}
            renderStyle={renderStyle}
            isSelected={isSelected}
          />
        </group>
      )}

      {/* 6. East Wall */}
      {room.doorSide !== 'open' && (
        <group position={[room.x + room.w - thick / 2, cy, cz]} rotation={[0, Math.PI / 2, 0]}>
          <ParametricApertureWall
            wall={{ length: room.d, height, thick }}
            openings={eastOpenings}
            wallHeight={height}
            wallThick={thick}
            wallMatKey={room.wallMat}
            renderStyle={renderStyle}
            isSelected={isSelected}
          />
        </group>
      )}

      {/* 7. Optional Ceiling / Roof */}
      {wallCutHeight >= 2.5 && (
        <Ceiling3D
          room={room}
          elevation={elevation}
          wallHeight={height}
          mode={ceilingMode}
          renderStyle={renderStyle}
        />
      )}

      {/* 8. 3D Architectural Room Text Tag */}
      {viewMode !== '2d_blueprint' && (
        <Text
          position={[cx, cy + 0.05, cz]}
          rotation={[-Math.PI / 2, 0, 0]}
          fontSize={0.34}
          color="#ffffff"
          anchorX="center"
          anchorY="middle"
        >
          {room.name}
        </Text>
      )}
    </group>
  );
}
