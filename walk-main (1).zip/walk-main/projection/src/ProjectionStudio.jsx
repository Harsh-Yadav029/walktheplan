/**
 * ProjectionStudio.jsx
 * Walk The Plan · 1:1 Scale Architectural Projection & CAD Studio
 * Industry-Grade Multi-Floor Projection Engine & CAD Visualizer
 */

import React, {
  useState, useEffect, useRef, useMemo, useCallback, Suspense
} from 'react';
import { Link } from 'react-router-dom';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import {
  OrbitControls, Grid, Text, Box, Line,
  GizmoHelper, GizmoViewport
} from '@react-three/drei';
import * as THREE from 'three';
import * as XLSX from 'xlsx';
import {
  Ruler, Menu, X, ArrowLeft, MousePointer, PenTool, Layers, Box as BoxIcon,
  Eye, Sliders, Maximize2, Minimize2, Building, Sparkles, Plus, Check,
  Trash2, RotateCw, Palette, ShieldAlert, ShieldCheck, AlertTriangle, Sun,
  FileDown, ArrowRight, Download, Printer, Navigation, ZoomIn, ZoomOut,
  RotateCcw, CheckCircle2, HelpCircle, Search, Copy, Undo, Redo,
  ChevronUp, ChevronDown, ChevronLeft, ChevronRight, Compass, Car,
  FileSpreadsheet, Layers2, SplitSquareVertical, Maximize, Share2, Save,
  Upload, Activity, Info, Sparkle, UploadCloud, FileUp, Image as ImageIcon,
  Trees, Moon, Move, Grip, DollarSign, Calculator, Camera, Columns, Square,
  DoorOpen, Scissors
} from 'lucide-react';

import VRWalkthroughStudio from './VRWalkthroughStudio';
import { CadBlueprintViewport } from './CadBlueprintViewport';
import {
  ARCH_MATERIALS,
  getStyleMaterial,
  Door3D,
  Window3D,
  ParametricApertureWall,
  CustomWall3D,
  ArchitecturalLandscape,
  Column3D,
  Ceiling3D,
  RoomInteriorDownlights,
  Detailed3DFurniture,
  Architectural3DRoom
} from './architecturalEngine';
import {
  EXTENDED_FURNITURE_CATALOG,
  ARCHITECTURAL_DOOR_STYLES,
  ARCHITECTURAL_WINDOW_STYLES,
  STRUCTURAL_COLUMN_TYPES
} from './furnitureCatalog';
import {
  exportSceneToOBJ,
  exportSceneToGLTF,
  exportProjectJSON,
  captureCanvasSnapshot
} from './exporters';
import {
  parseUniversalFloorPlanJSON,
  parseAppleRoomPlanJSON
} from './importers';

import './ProjectionStudio.css';

// ─────────────────────────────────────────────────────────────────────────────
// UNITS & CONVERSION HELPERS
// ─────────────────────────────────────────────────────────────────────────────

export function toFeetInches(meters) {
  if (meters === undefined || meters === null || isNaN(meters)) return "0'-0\"";
  const totalInches = Math.round(meters * 39.3701);
  const feet = Math.floor(totalInches / 12);
  const inches = totalInches % 12;
  return `${feet}'-${inches}"`;
}

export function toSqFt(sqMeters) {
  if (!sqMeters || isNaN(sqMeters)) return 0;
  return Math.round(sqMeters * 10.7639);
}

export function formatDim(meters, unit) {
  if (unit === 'imperial') return toFeetInches(meters);
  return `${Number(meters).toFixed(2)}m`;
}

export function formatArea(sqM, unit) {
  if (unit === 'imperial') return `${toSqFt(sqM).toLocaleString()} sq.ft`;
  return `${Number(sqM).toFixed(1)} m²`;
}

// ─────────────────────────────────────────────────────────────────────────────
// LUXURY MATERIALS CATALOG
// ─────────────────────────────────────────────────────────────────────────────

export const FLOOR_MATERIALS = [
  { id: 'marble_calacatta', name: 'Calacatta Gold Marble', category: 'Luxury Stone', color: '#f5f0e6', roughness: 0.12, metalness: 0.18, preview: '#fdf4dc', tag: 'Gold Vein' },
  { id: 'marble_carrara', name: 'Carrara Italian Marble', category: 'Luxury Stone', color: '#e2e8f0', roughness: 0.14, metalness: 0.15, preview: '#e2e8f0', tag: 'High Sheen' },
  { id: 'walnut_hardwood', name: 'Smoked Walnut Hardwood', category: 'Natural Timber', color: '#3e2716', roughness: 0.65, metalness: 0.05, preview: '#5a3d28', tag: 'Warm Grain' },
  { id: 'scandinavian_oak', name: 'Nordic White Oak', category: 'Natural Timber', color: '#8c6d48', roughness: 0.60, metalness: 0.05, preview: '#a3845e', tag: 'Matte' },
  { id: 'polished_concrete', name: 'Polished Concrete', category: 'Modern Luxe', color: '#475569', roughness: 0.35, metalness: 0.15, preview: '#64748b', tag: 'Seamless' },
  { id: 'terrazzo_venetian', name: 'Venetian Dark Terrazzo', category: 'Luxury Stone', color: '#1e293b', roughness: 0.40, metalness: 0.12, preview: '#334155', tag: 'Speckled' },
  { id: 'blueprint_obsidian', name: 'Laser Obsidian Glass (1:1 Stage)', category: 'Projection Stage', color: '#031726', roughness: 0.08, metalness: 0.70, glow: '#00f0ff', preview: '#0284c7', tag: 'Laser Active' },
];

export const WALL_MATERIALS = [
  { id: 'wall_white_chalk', name: 'Architectural Pure White', color: '#f8fafc', preview: '#f8fafc', tag: 'Neutral 98%' },
  { id: 'wall_slate_gray', name: 'Contemporary Slate Gray', color: '#475569', preview: '#475569', tag: 'Modern Accent' },
  { id: 'wall_charcoal_dark', name: 'Nordic Charcoal Minimal', color: '#1e293b', preview: '#1e293b', tag: 'Deep Matte' },
  { id: 'wall_warm_sand', name: 'Warm Terracotta Stucco', color: '#7c533e', preview: '#9a6b52', tag: 'Earthy' },
  { id: 'wall_champagne_gold', name: 'Royal Champagne Plaster', color: '#997c47', preview: '#bfa063', tag: 'Gold Flake' },
  { id: 'wall_blueprint_cyan', name: 'Glowing Blueprint Cyan', color: '#0369a1', glow: '#00f0ff', preview: '#0284c7', tag: 'Laser Line' },
];

// ─────────────────────────────────────────────────────────────────────────────
// VASTU ZONES & ARCHITECTURAL STANDARDS
// ─────────────────────────────────────────────────────────────────────────────

export const VASTU_ZONES = [
  { id: 'NE', name: 'Ishaan (North-East)', element: 'Water / Divine', deity: 'Shiva', best: ['puja', 'living', 'balcony', 'open'], avoid: ['master', 'kitchen', 'bath', 'toilet'], color: '#38bdf8' },
  { id: 'E',  name: 'Indra (East)', element: 'Solar Energy', deity: 'Surya', best: ['living', 'verandah', 'puja', 'entrance'], avoid: ['bath', 'toilet'], color: '#fbbf24' },
  { id: 'SE', name: 'Agni (South-East)', element: 'Fire Energy', deity: 'Agni', best: ['kitchen', 'electricals', 'utility', 'panel'], avoid: ['master', 'bath', 'puja'], color: '#f97316' },
  { id: 'S',  name: 'Yama (South)', element: 'Earth / Rest', deity: 'Yama', best: ['bedroom', 'store', 'stairs'], avoid: ['kitchen', 'puja'], color: '#ef4444' },
  { id: 'SW', name: 'Niruthi (South-West)', element: 'Heavy Earth / Power', deity: 'Niruthi', best: ['master', 'heavy_store', 'wardrobe'], avoid: ['puja', 'kitchen', 'entrance', 'bath'], color: '#a855f7' },
  { id: 'W',  name: 'Varuna (West)', element: 'Water / Prosperity', deity: 'Varuna', best: ['dining', 'children', 'study', 'overhead_tank'], avoid: ['puja', 'kitchen'], color: '#6366f1' },
  { id: 'NW', name: 'Vayu (North-West)', element: 'Air / Movement', deity: 'Vayu', best: ['guest', 'parking', 'servant', 'pantry', 'toilet'], avoid: ['master', 'puja'], color: '#14b8a6' },
  { id: 'N',  name: 'Kubera (North)', element: 'Wealth / Water', deity: 'Kubera', best: ['living', 'locker', 'entrance', 'lobby'], avoid: ['kitchen', 'toilet'], color: '#10b981' },
  { id: 'C',  name: 'Brahmasthana (Center)', element: 'Space / Ether', deity: 'Brahma', best: ['courtyard', 'lobby', 'atrium', 'open'], avoid: ['toilet', 'kitchen', 'stairs', 'pillar'], color: '#fae8a4' }
];

// ─────────────────────────────────────────────────────────────────────────────
// REAL-WORLD LAND & PLOT PRESETS (FOR 1:1 OUTDOOR LAND PROJECTION)
// ─────────────────────────────────────────────────────────────────────────────

export const LAND_PLOT_PRESETS = [
  { id: 'plot_30x50', name: "30' × 50' (1,500 sq.ft)", width: 9.14, depth: 15.24, frontSetback: 3.0, rearSetback: 2.0, sideSetback: 1.2, tag: 'Urban Compact' },
  { id: 'plot_30x60', name: "30' × 60' (1,800 sq.ft)", width: 9.14, depth: 18.29, frontSetback: 3.5, rearSetback: 2.5, sideSetback: 1.2, tag: 'Standard Villa' },
  { id: 'plot_40x60', name: "40' × 60' (2,400 sq.ft)", width: 12.19, depth: 18.29, frontSetback: 4.5, rearSetback: 3.0, sideSetback: 1.5, tag: 'Luxury 4BHK' },
  { id: 'plot_50x80', name: "50' × 80' (4,000 sq.ft)", width: 15.24, depth: 24.38, frontSetback: 5.5, rearSetback: 3.5, sideSetback: 2.0, tag: 'Independent Estate' },
  { id: 'plot_60x100', name: "60' × 100' (6,000 sq.ft)", width: 18.29, depth: 30.48, frontSetback: 6.5, rearSetback: 4.5, sideSetback: 2.5, tag: 'Farmhouse Ground' },
];

// ─────────────────────────────────────────────────────────────────────────────
// CURATED 1-CLICK ARCHITECTURAL PRESETS (OPENPLAN3D ENGINE)
// ─────────────────────────────────────────────────────────────────────────────

export const ARCHITECTURAL_PRESETS = [
  {
    id: 'studio_1bhk',
    name: 'Modern 1BHK Studio Apartment',
    badge: 'Trending 1BHK',
    areaSqFt: 480,
    areaSqM: 44.6,
    desc: 'Contemporary open living, quartz kitchenette, master suite, luxury bath & glass balcony',
    plotWidth: 8.5,
    plotDepth: 12.0,
    rooms: [
      { id: 'r_living', type: 'living', name: 'Open Living & Kitchenette', x: -3.8, z: -5.0, w: 4.6, d: 5.5, h: 2.9, wallThick: 0.2, floorMat: 'marble_calacatta', wallMat: 'wall_white_chalk', doorSide: 'open' },
      { id: 'r_bed', type: 'master', name: 'Master Bedroom Suite', x: 0.8, z: -5.0, w: 3.2, d: 5.5, h: 2.9, wallThick: 0.2, floorMat: 'walnut_hardwood', wallMat: 'wall_white_chalk', doorSide: 'west' },
      { id: 'r_bath', type: 'bath', name: 'Ensuite Luxury Bath', x: 0.8, z: 0.5, w: 3.2, d: 2.4, h: 2.8, wallThick: 0.15, floorMat: 'marble_carrara', wallMat: 'wall_slate_gray', doorSide: 'north' },
      { id: 'r_balcony', type: 'balcony', name: 'Sunlit Deck Balcony', x: -3.8, z: 0.5, w: 4.6, d: 2.4, h: 1.1, wallThick: 0.15, floorMat: 'scandinavian_oak', wallMat: 'wall_slate_gray', doorSide: 'north' }
    ],
    furniture: [
      { id: 'f_sofa', type: 'sofa_sectional', name: 'L-Shaped Sectional Sofa', x: -2.2, z: -3.8, w: 2.6, d: 1.8, h: 0.85, rot: 0, color: '#1e3a5f' },
      { id: 'f_table', type: 'table', name: 'Marble Coffee Table', x: -2.2, z: -2.4, w: 1.2, d: 0.7, h: 0.45, rot: 0, color: '#f8fafc' },
      { id: 'f_tv', type: 'media_wall_unit', name: '4K OLED Media Unit', x: -2.2, z: -0.6, w: 2.2, d: 0.45, h: 1.8, rot: 180, color: '#1a1410' },
      { id: 'f_island', type: 'kitchen_island', name: 'Quartz Breakfast Island', x: -0.2, z: -3.5, w: 1.8, d: 0.9, h: 0.92, rot: 90, color: '#0369a1' },
      { id: 'f_bed', type: 'bed_king', name: 'King Platform Bed', x: 2.4, z: -3.2, w: 2.0, d: 2.0, h: 1.0, rot: 0, color: '#2a3547' },
      { id: 'f_wardrobe', type: 'wardrobe', name: 'Floor-to-Ceiling Wardrobe', x: 2.4, z: -4.6, w: 2.2, d: 0.65, h: 2.4, rot: 0, color: '#192231' },
      { id: 'f_tub', type: 'luxury_bathtub', name: 'Freestanding Soaking Tub', x: 2.4, z: 1.7, w: 1.6, d: 0.8, h: 0.65, rot: 0, color: '#f8fafc' },
      { id: 'f_plant', type: 'indoor_plant', name: 'Monstera Plant', x: -3.2, z: 1.8, w: 0.7, d: 0.7, h: 1.4, rot: 0, color: '#15803d' },
      { id: 'f_lounger', type: 'patio_lounger', name: 'Balcony Sun Lounger', x: -1.5, z: 1.8, w: 0.8, d: 1.9, h: 0.45, rot: 90, color: '#5c3a21' }
    ]
  },
  {
    id: 'villa_2bhk',
    name: 'Luxury 2BHK Minimalist Villa',
    badge: 'Executive Villa',
    areaSqFt: 1350,
    areaSqM: 125.4,
    desc: 'Spacious drawing hall, master king suite, guest bedroom, island kitchen, dining salon & meditation mandir',
    plotWidth: 10.5,
    plotDepth: 18.0,
    rooms: [
      { id: 'r_v_living', type: 'living', name: 'Grand Living & Drawing Hall', x: -4.8, z: -7.5, w: 5.6, d: 6.0, h: 3.2, wallThick: 0.23, floorMat: 'marble_calacatta', wallMat: 'wall_white_chalk', doorSide: 'open' },
      { id: 'r_v_dining', type: 'dining', name: 'Formal Dining Salon', x: 0.8, z: -7.5, w: 4.2, d: 4.0, h: 3.0, wallThick: 0.15, floorMat: 'marble_carrara', wallMat: 'wall_white_chalk', doorSide: 'west' },
      { id: 'r_v_kitchen', type: 'kitchen', name: 'Modular Island Kitchen', x: 0.8, z: -3.5, w: 4.2, d: 4.2, h: 2.9, wallThick: 0.23, floorMat: 'terrazzo_venetian', wallMat: 'wall_slate_gray', doorSide: 'west' },
      { id: 'r_v_master', type: 'master', name: 'Master Bedroom Suite', x: -4.8, z: -1.5, w: 5.6, d: 4.8, h: 3.0, wallThick: 0.23, floorMat: 'walnut_hardwood', wallMat: 'wall_white_chalk', doorSide: 'north' },
      { id: 'r_v_bed2', type: 'bedroom', name: 'Kids / Guest Bedroom', x: 0.8, z: 0.7, w: 4.2, d: 4.0, h: 3.0, wallThick: 0.15, floorMat: 'scandinavian_oak', wallMat: 'wall_white_chalk', doorSide: 'north' },
      { id: 'r_v_bath', type: 'bath', name: 'Master Ensuite Spa Bath', x: -4.8, z: 3.3, w: 3.2, d: 2.8, h: 2.8, wallThick: 0.15, floorMat: 'marble_carrara', wallMat: 'wall_slate_gray', doorSide: 'north' },
      { id: 'r_v_mandir', type: 'puja', name: 'Ishaan Meditation Mandir', x: -1.6, z: 3.3, w: 2.4, d: 2.8, h: 3.0, wallThick: 0.15, floorMat: 'marble_calacatta', wallMat: 'wall_champagne_gold', doorSide: 'west' },
      { id: 'r_v_balcony', type: 'balcony', name: 'Landscaped Garden Patio', x: 0.8, z: 4.7, w: 4.2, d: 2.2, h: 1.1, wallThick: 0.15, floorMat: 'scandinavian_oak', wallMat: 'wall_slate_gray', doorSide: 'north' }
    ],
    furniture: [
      { id: 'f_v_sofa', type: 'sofa', name: 'Italian 3-Seater Leather Sofa', x: -2.4, z: -5.8, w: 2.8, d: 1.0, h: 0.85, rot: 0, color: '#1e3a5f' },
      { id: 'f_v_chair', type: 'lounge_chair', name: 'Scandinavian Lounge Chair', x: -0.4, z: -4.8, w: 0.85, d: 0.85, h: 0.8, rot: -45, color: '#334155' },
      { id: 'f_v_table', type: 'table', name: 'Marble Coffee Table', x: -2.4, z: -4.5, w: 1.3, d: 0.8, h: 0.45, rot: 0, color: '#f8fafc' },
      { id: 'f_v_tv', type: 'media_wall_unit', name: 'OLED Media Wall', x: -2.4, z: -2.2, w: 2.4, d: 0.45, h: 1.8, rot: 180, color: '#1a1410' },
      { id: 'f_v_dining', type: 'dining_set', name: '8-Seat Solid Teak Dining Suite', x: 2.9, z: -5.5, w: 2.4, d: 1.2, h: 0.78, rot: 0, color: '#b45309' },
      { id: 'f_v_island', type: 'kitchen_island', name: 'Quartz Cooking Island', x: 2.9, z: -1.8, w: 2.4, d: 1.0, h: 0.92, rot: 0, color: '#0369a1' },
      { id: 'f_v_cooktop', type: 'kitchen_cooktop', name: 'Induction Cooktop & Hood', x: 2.9, z: -2.8, w: 1.2, d: 0.7, h: 2.4, rot: 0, color: '#0f172a' },
      { id: 'f_v_bed1', type: 'bed_king', name: 'Grand Master King Bed', x: -2.0, z: 0.8, w: 2.1, d: 2.0, h: 1.0, rot: 0, color: '#2a3547' },
      { id: 'f_v_bed2', type: 'bed_queen', name: 'Queen Guest Bed', x: 2.9, z: 2.6, w: 1.8, d: 2.1, h: 0.9, rot: 0, color: '#334155' },
      { id: 'f_v_tub', type: 'luxury_bathtub', name: 'Freestanding Bathtub', x: -3.2, z: 4.7, w: 1.7, d: 0.85, h: 0.65, rot: 0, color: '#f8fafc' },
      { id: 'f_v_lamp', type: 'floor_lamp', name: 'Brass Downlight Floor Lamp', x: -4.2, z: -4.2, w: 0.5, d: 0.5, h: 1.8, rot: 0, color: '#d4af37' }
    ]
  },
  {
    id: 'penthouse_3bhk',
    name: 'Executive 3BHK Penthouse Suite',
    badge: 'Luxury Penthouse',
    areaSqFt: 2450,
    areaSqM: 227.6,
    desc: 'Grand double-height foyer, floating glass staircase, 3 bedroom suites, executive study, elevator core & wraparound terrace',
    plotWidth: 14.0,
    plotDepth: 22.0,
    rooms: [
      { id: 'r_p_living', type: 'living', name: 'Palatial Living & Foyer', x: -6.0, z: -9.5, w: 7.2, d: 7.0, h: 3.4, wallThick: 0.23, floorMat: 'marble_calacatta', wallMat: 'wall_white_chalk', doorSide: 'open' },
      { id: 'r_p_stair', type: 'staircase', name: 'Architectural Staircase Core', x: 1.2, z: -9.5, w: 4.8, d: 4.0, h: 3.4, wallThick: 0.23, floorMat: 'terrazzo_venetian', wallMat: 'wall_slate_gray', doorSide: 'open' },
      { id: 'r_p_dining', type: 'dining', name: 'Dining Salon & Bar', x: 1.2, z: -5.5, w: 4.8, d: 4.0, h: 3.0, wallThick: 0.15, floorMat: 'marble_carrara', wallMat: 'wall_white_chalk', doorSide: 'west' },
      { id: 'r_p_kitchen', type: 'kitchen', name: 'Chef Island Kitchen', x: 1.2, z: -1.5, w: 4.8, d: 4.5, h: 3.0, wallThick: 0.23, floorMat: 'terrazzo_venetian', wallMat: 'wall_slate_gray', doorSide: 'west' },
      { id: 'r_p_master', type: 'master', name: 'Royal Master Suite', x: -6.0, z: -2.5, w: 7.2, d: 5.5, h: 3.2, wallThick: 0.23, floorMat: 'walnut_hardwood', wallMat: 'wall_white_chalk', doorSide: 'north' },
      { id: 'r_p_bed2', type: 'bedroom', name: 'Junior Suite 2', x: -6.0, z: 3.0, w: 4.5, d: 4.5, h: 3.0, wallThick: 0.15, floorMat: 'scandinavian_oak', wallMat: 'wall_white_chalk', doorSide: 'north' },
      { id: 'r_p_bed3', type: 'bedroom', name: 'Guest Bedroom 3', x: -1.5, z: 3.0, w: 4.2, d: 4.5, h: 3.0, wallThick: 0.15, floorMat: 'scandinavian_oak', wallMat: 'wall_white_chalk', doorSide: 'north' },
      { id: 'r_p_terrace', type: 'balcony', name: 'Wraparound Sunset Terrace', x: 2.7, z: 3.0, w: 3.3, d: 4.5, h: 1.1, wallThick: 0.15, floorMat: 'scandinavian_oak', wallMat: 'wall_slate_gray', doorSide: 'north' }
    ],
    furniture: [
      { id: 'f_p_stair', type: 'staircase', name: 'Glass Balustrade Staircase', x: 3.6, z: -7.5, w: 1.1, d: 3.4, h: 3.4, rot: 0, color: '#8c6d48' },
      { id: 'f_p_sofa', type: 'sofa_sectional', name: 'Grand Sectional Lounge', x: -2.8, z: -7.2, w: 3.2, d: 2.2, h: 0.85, rot: 0, color: '#1e3a5f' },
      { id: 'f_p_tv', type: 'media_wall_unit', name: 'OLED Media Wall Unit', x: -2.8, z: -3.8, w: 2.4, d: 0.45, h: 1.8, rot: 180, color: '#1a1410' },
      { id: 'f_p_dining', type: 'dining_set', name: '8-Seat Solid Teak Dining', x: 3.6, z: -3.5, w: 2.4, d: 1.2, h: 0.78, rot: 0, color: '#b45309' },
      { id: 'f_p_cooktop', type: 'kitchen_cooktop', name: 'Island Cooktop & Range Hood', x: 3.6, z: 0.8, w: 1.2, d: 0.7, h: 2.4, rot: 0, color: '#0f172a' },
      { id: 'f_p_bed1', type: 'bed_king', name: 'Master King Bed Suite', x: -2.4, z: 0.2, w: 2.1, d: 2.0, h: 1.0, rot: 0, color: '#2a3547' },
      { id: 'f_p_bed2', type: 'bed_queen', name: 'Queen Bed 2', x: -3.8, z: 5.2, w: 1.8, d: 2.1, h: 0.9, rot: 0, color: '#334155' },
      { id: 'f_p_bed3', type: 'bed_queen', name: 'Queen Bed 3', x: 0.6, z: 5.2, w: 1.8, d: 2.1, h: 0.9, rot: 0, color: '#334155' },
      { id: 'f_p_lounger', type: 'patio_lounger', name: 'Terrace Deck Sunbed', x: 4.2, z: 5.2, w: 0.8, d: 2.0, h: 0.45, rot: 90, color: '#5c3a21' }
    ]
  },
  {
    id: 'cowork_studio',
    name: 'Contemporary Creative Co-Work Studio',
    badge: 'Co-Working / Office',
    areaSqFt: 1550,
    areaSqM: 144.0,
    desc: 'Open-plan collaborative workstations, executive conference boardroom, breakout lounge & kitchen pantry',
    plotWidth: 12.0,
    plotDepth: 16.0,
    rooms: [
      { id: 'r_cw_open', type: 'living', name: 'Open Workstation Hall', x: -5.0, z: -7.0, w: 6.2, d: 7.5, h: 3.2, wallThick: 0.2, floorMat: 'polished_concrete', wallMat: 'wall_white_chalk', doorSide: 'open' },
      { id: 'r_cw_board', type: 'dining', name: 'Executive Conference Boardroom', x: 1.2, z: -7.0, w: 4.2, d: 4.5, h: 3.0, wallThick: 0.15, floorMat: 'walnut_hardwood', wallMat: 'wall_slate_gray', doorSide: 'west' },
      { id: 'r_cw_pantry', type: 'kitchen', name: 'Cafe & Pantry Breakout', x: 1.2, z: -2.5, w: 4.2, d: 3.0, h: 2.9, wallThick: 0.15, floorMat: 'terrazzo_venetian', wallMat: 'wall_white_chalk', doorSide: 'west' },
      { id: 'r_cw_lounge', type: 'balcony', name: 'Reception & Creative Lounge', x: -5.0, z: 0.5, w: 10.4, d: 4.0, h: 3.0, wallThick: 0.2, floorMat: 'polished_concrete', wallMat: 'wall_white_chalk', doorSide: 'open' }
    ],
    furniture: [
      { id: 'f_cw_desk1', type: 'desk', name: 'Workstation 1', x: -3.5, z: -5.5, w: 1.6, d: 0.8, h: 0.75, rot: 0, color: '#1e3a5f' },
      { id: 'f_cw_desk2', type: 'desk', name: 'Workstation 2', x: -1.5, z: -5.5, w: 1.6, d: 0.8, h: 0.75, rot: 0, color: '#1e3a5f' },
      { id: 'f_cw_desk3', type: 'desk', name: 'Workstation 3', x: -3.5, z: -3.5, w: 1.6, d: 0.8, h: 0.75, rot: 180, color: '#1e3a5f' },
      { id: 'f_cw_desk4', type: 'desk', name: 'Workstation 4', x: -1.5, z: -3.5, w: 1.6, d: 0.8, h: 0.75, rot: 180, color: '#1e3a5f' },
      { id: 'f_cw_conf', type: 'dining_set', name: 'Boardroom Conference Table', x: 3.3, z: -4.8, w: 2.4, d: 1.2, h: 0.78, rot: 90, color: '#1e293b' },
      { id: 'f_cw_island', type: 'kitchen_island', name: 'Cafe Coffee Counter', x: 3.3, z: -1.0, w: 2.2, d: 0.9, h: 0.92, rot: 0, color: '#0369a1' },
      { id: 'f_cw_sofa', type: 'sofa_sectional', name: 'Reception Lounge Sofa', x: -2.5, z: 2.5, w: 3.0, d: 2.0, h: 0.85, rot: 0, color: '#334155' },
      { id: 'f_cw_plant', type: 'indoor_plant', name: 'Monstera Biophilic Plant', x: 2.5, z: 2.5, w: 0.7, d: 0.7, h: 1.4, rot: 0, color: '#15803d' }
    ]
  },
  {
    id: 'blank_canvas',
    name: 'Blank Canvas (Draft from Scratch)',
    badge: 'Drafting Canvas',
    areaSqFt: 0,
    areaSqM: 0,
    desc: 'Clean architectural grid ready to draw custom vector walls and rooms using the Wall tool (W)',
    plotWidth: 10.0,
    plotDepth: 15.0,
    rooms: [],
    furniture: []
  }
];


// ─────────────────────────────────────────────────────────────────────────────
// COMPREHENSIVE ARCHITECTURAL BUILDINGS & MULTI-FLOOR DATASET
// ─────────────────────────────────────────────────────────────────────────────

export const BUILDINGS_CATALOG = {
  royal_estate_30x75: {
    id: 'royal_estate_30x75',
    name: "Royal Villa Estate 30' × 75' (Stilt + 3 Floors)",
    tag: 'Signature 4-Level Architectural Project',
    isMultiLevel: true,
    footprint: '29\'-11" × 75\'-2" (9.12m × 22.91m · ~9,000 sq.ft Built-Up)',
    plotWidth: 9.12,
    plotDepth: 22.91,
    defaultFloor: 'ground',
    floors: {
      stilt: {
        id: 'stilt',
        name: 'Stilt Floor',
        subtitle: '8-Car Covered Parking, Staff Quarters & Vertical Core',
        elevation: 0,
        blueprintImage: '/blueprints/stilt_floor_plan.png',
        rooms: [
          { id: 'st_drive', type: 'parking', name: 'Stilt Parking & Driveway', x: -4.4, z: -11.2, w: 8.8, d: 22.4, h: 2.8, wallThick: 0.23, floorMat: 'polished_concrete', wallMat: 'wall_slate_gray', isBoundary: true, desc: "29'-11\" × 75'-2\" 8-Car Capacity & Drive Aisle" },
          { id: 'st_servant1', type: 'bedroom', name: 'Servant-1 (Staff Suite)', x: 0.8, z: -10.8, w: 3.05, d: 2.24, h: 2.8, wallThick: 0.15, floorMat: 'terrazzo_venetian', wallMat: 'wall_white_chalk', doorSide: 'west', desc: "10'-0\" × 7'-4\" Staff Suite" },
          { id: 'st_servant2', type: 'bedroom', name: 'Servant-2 (Staff Suite)', x: 0.8, z: -8.4, w: 3.05, d: 2.24, h: 2.8, wallThick: 0.15, floorMat: 'terrazzo_venetian', wallMat: 'wall_white_chalk', doorSide: 'west', desc: "10'-0\" × 7'-4\" Staff Suite" },
          { id: 'st_wc', type: 'bath', name: 'Servant W.C.', x: 2.3, z: -11.1, w: 1.47, d: 1.36, h: 2.6, wallThick: 0.15, floorMat: 'terrazzo_venetian', wallMat: 'wall_slate_gray', doorSide: 'west', desc: "4'-10\" × 4'-5½\"" },
          { id: 'st_bath', type: 'bath', name: 'Servant Bath', x: 2.3, z: -9.6, w: 1.47, d: 1.36, h: 2.6, wallThick: 0.15, floorMat: 'terrazzo_venetian', wallMat: 'wall_slate_gray', doorSide: 'west', desc: "4'-10\" × 4'-5½\"" },
          { id: 'st_storage', type: 'store', name: 'Ground Storage', x: 0.8, z: -6.0, w: 1.22, d: 2.44, h: 2.8, wallThick: 0.15, floorMat: 'terrazzo_venetian', wallMat: 'wall_slate_gray', doorSide: 'west', desc: "4'-0\" × 8'-0\" Tools & Equipment" },
          { id: 'st_lift', type: 'lift', name: 'High-Speed Lift Core', x: 0.4, z: -2.8, w: 1.73, d: 1.73, h: 2.8, wallThick: 0.23, floorMat: 'marble_carrara', wallMat: 'wall_blueprint_cyan', doorSide: 'west', desc: "5'-8\" × 5'-8\" Passenger Elevator" },
          { id: 'st_stairs', type: 'staircase', name: 'Staircase Core (UP)', x: 0.0, z: -3.8, w: 3.65, d: 3.8, h: 2.8, wallThick: 0.15, floorMat: 'terrazzo_venetian', wallMat: 'wall_white_chalk', doorSide: 'open', desc: "3'-6\" Wide Dogleg Staircase" },
          { id: 'st_bikes', type: 'parking', name: 'Dedicated Bike Parking', x: -4.0, z: -6.8, w: 3.45, d: 3.43, h: 2.8, wallThick: 0.15, floorMat: 'polished_concrete', wallMat: 'wall_slate_gray', doorSide: 'east', desc: "11'-4\" × 11'-3\" 2-Wheeler Stalls" },
          { id: 'st_panel', type: 'utility', name: 'Main Electrical Panel Box', x: 0.8, z: 0.4, w: 1.4, d: 0.6, h: 2.2, wallThick: 0.1, floorMat: 'polished_concrete', wallMat: 'wall_charcoal_dark', doorSide: 'south', desc: "Main Distribution Board" }
        ],
        furniture: [
          { id: 'car1', type: 'car_sedan', name: 'Executive Sedan Bay 1', x: 2.6, z: 8.5, w: 1.9, d: 4.6, h: 1.5, rot: 0, clearance: 0.6, color: '#334155' },
          { id: 'car2', type: 'car_sedan', name: 'Executive Sedan Bay 2', x: 2.6, z: 3.5, w: 1.9, d: 4.6, h: 1.5, rot: 0, clearance: 0.6, color: '#1e293b' },
          { id: 'car3', type: 'car_suv', name: 'Luxury SUV Bay 3', x: 0.6, z: 8.5, w: 2.0, d: 4.8, h: 1.7, rot: 0, clearance: 0.6, color: '#0369a1' },
          { id: 'car4', type: 'car_sedan', name: 'Family Sedan Bay 4', x: 0.6, z: 3.5, w: 1.9, d: 4.6, h: 1.5, rot: 0, clearance: 0.6, color: '#475569' },
          { id: 'car5', type: 'car_suv', name: 'Grand SUV Bay 5', x: -3.0, z: 8.5, w: 2.0, d: 4.8, h: 1.7, rot: 0, clearance: 0.6, color: '#0f172a' },
          { id: 'car6', type: 'car_sedan', name: 'City Sedan Bay 6', x: -3.0, z: 3.5, w: 1.9, d: 4.6, h: 1.5, rot: 0, clearance: 0.6, color: '#3b82f6' },
          { id: 'car7', type: 'car_sedan', name: 'Guest Sedan Bay 7', x: -3.0, z: -2.0, w: 1.9, d: 4.6, h: 1.5, rot: 0, clearance: 0.6, color: '#64748b' },
          { id: 'car8', type: 'car_suv', name: 'Staff Vehicle Bay 8', x: -3.0, z: -7.0, w: 2.0, d: 4.8, h: 1.7, rot: 0, clearance: 0.6, color: '#1e3a5f' },
          { id: 'bike1', type: 'bike', name: 'Motorbike Stall 1', x: -2.8, z: -5.5, w: 0.8, d: 2.0, h: 1.1, rot: 0, clearance: 0.5, color: '#b91c1c' },
          { id: 'bike2', type: 'bike', name: 'Motorbike Stall 2', x: -3.8, z: -5.5, w: 0.8, d: 2.0, h: 1.1, rot: 0, clearance: 0.5, color: '#0284c7' }
        ]
      },
      ground: {
        id: 'ground',
        name: 'Ground Floor',
        subtitle: 'Grand Drawing/Dining, Island Kitchen & Master Suite 1',
        elevation: 3.3,
        blueprintImage: '/blueprints/ground_floor_plan.jpg',
        rooms: [
          { id: 'g_ms_jaal', type: 'balcony', name: 'Rear MS Jaal (Skylight)', x: -4.3, z: -11.4, w: 8.6, d: 1.5, h: 3.2, wallThick: 0.15, floorMat: 'blueprint_obsidian', wallMat: 'wall_blueprint_cyan', doorSide: 'open', desc: "Rear Open to Sky Jaal" },
          { id: 'g_utility', type: 'utility', name: 'Utility Area', x: -4.3, z: -9.8, w: 2.87, d: 1.83, h: 3.0, wallThick: 0.15, floorMat: 'terrazzo_venetian', wallMat: 'wall_slate_gray', doorSide: 'south', desc: "9'-5\" × 6'-0\"" },
          { id: 'g_washing', type: 'utility', name: 'Washing Area', x: -1.3, z: -9.8, w: 2.74, d: 1.83, h: 3.0, wallThick: 0.15, floorMat: 'terrazzo_venetian', wallMat: 'wall_slate_gray', doorSide: 'south', desc: "9'-0\" × 6'-0\" Laundry Station" },
          { id: 'g_potwash', type: 'utility', name: 'Potwash Area', x: 1.6, z: -9.8, w: 2.7, d: 1.83, h: 3.0, wallThick: 0.15, floorMat: 'terrazzo_venetian', wallMat: 'wall_slate_gray', doorSide: 'south', desc: "10'-0\" × 6'-0\" Scrub & Sink" },
          { id: 'g_mandir', type: 'puja', name: 'Ishaan Mandir (Puja)', x: -4.3, z: -7.8, w: 1.83, d: 0.61, h: 3.0, wallThick: 0.15, floorMat: 'marble_calacatta', wallMat: 'wall_champagne_gold', doorSide: 'east', desc: "6'-0\" × 2'-0\" Divine Niche" },
          { id: 'g_drawing_dining', type: 'living', name: 'Drawing & Dining Grand Salon', x: -4.3, z: -7.0, w: 4.76, d: 12.50, h: 3.4, wallThick: 0.23, floorMat: 'marble_calacatta', wallMat: 'wall_white_chalk', doorSide: 'open', desc: "15'-7½\" × 41'-0\" (640 sq.ft Grand Salon)" },
          { id: 'g_kitchen', type: 'kitchen', name: 'Agni Modular Kitchen + Island', x: 0.5, z: -7.0, w: 3.8, d: 4.11, h: 3.0, wallThick: 0.23, floorMat: 'terrazzo_venetian', wallMat: 'wall_slate_gray', doorSide: 'west', desc: "15'-0\" × 13'-6\" Island Modular Kitchen" },
          { id: 'g_lift', type: 'lift', name: 'Lift Core', x: 0.4, z: -2.8, w: 1.73, d: 1.73, h: 3.2, wallThick: 0.23, floorMat: 'marble_carrara', wallMat: 'wall_blueprint_cyan', doorSide: 'west', desc: "5'-8\" × 5'-8\" Elevator" },
          { id: 'g_stairs', type: 'staircase', name: 'Staircase Core (UP/DN)', x: 0.0, z: -3.8, w: 3.65, d: 3.8, h: 3.2, wallThick: 0.15, floorMat: 'terrazzo_venetian', wallMat: 'wall_white_chalk', doorSide: 'open', desc: "3'-6\" Wide" },
          { id: 'g_shaft', type: 'utility', name: 'MEP Services Shaft', x: 3.2, z: -2.8, w: 0.76, d: 4.17, h: 3.2, wallThick: 0.15, floorMat: 'blueprint_obsidian', wallMat: 'wall_charcoal_dark', doorSide: 'open', desc: "2'-6\" × 13'-8\" Piping Duct" },
          { id: 'g_pdr', type: 'bath', name: 'Powder Room (PDR)', x: 2.1, z: 0.6, w: 1.68, d: 2.01, h: 2.8, wallThick: 0.15, floorMat: 'marble_carrara', wallMat: 'wall_charcoal_dark', doorSide: 'north', desc: "5'-6\" × 6'-7\" Guest Vanity" },
          { id: 'g_bed1', type: 'master', name: 'Master Bedroom-1 Suite', x: 0.0, z: 2.8, w: 3.96, d: 6.10, h: 3.2, wallThick: 0.23, floorMat: 'walnut_hardwood', wallMat: 'wall_white_chalk', doorSide: 'north', desc: "13'-0\" × 20'-0\" Executive Suite" },
          { id: 'g_walkin', type: 'dresser', name: 'Walking Closet & Dresser', x: -4.3, z: 4.8, w: 2.59, d: 4.11, h: 3.0, wallThick: 0.15, floorMat: 'scandinavian_oak', wallMat: 'wall_champagne_gold', doorSide: 'east', desc: "8'-6\" × 13'-6\" Wardrobe Suite" },
          { id: 'g_toilet1', type: 'bath', name: 'Ensuite Luxury Toilet-1', x: -4.3, z: 2.8, w: 2.11, d: 4.11, h: 2.9, wallThick: 0.15, floorMat: 'marble_calacatta', wallMat: 'wall_charcoal_dark', doorSide: 'east', desc: "6'-11\" × 13'-6\" Glass Shower Cubicle" },
          { id: 'g_balcony', type: 'balcony', name: 'Front Landscaped Balcony', x: -4.3, z: 9.0, w: 8.6, d: 1.52, h: 1.1, wallThick: 0.15, floorMat: 'scandinavian_oak', wallMat: 'wall_slate_gray', doorSide: 'north', desc: "5'-0\" Wide Balcony & Hedge" }
        ],
        furniture: [
          { id: 'gf_dining', type: 'dining_set', name: '8-Seat Teak Dining Suite', x: -2.0, z: -4.2, w: 2.4, d: 1.2, h: 0.78, rot: 90, clearance: 1.0, color: '#b45309' },
          { id: 'gf_island', type: 'kitchen_island', name: 'Kitchen Cooking Island', x: 2.2, z: -4.8, w: 1.68, d: 0.76, h: 0.92, rot: 0, clearance: 0.9, color: '#0369a1' },
          { id: 'gf_sofa_main', type: 'sofa', name: '4-Seater Lounge Sofa', x: -2.2, z: 1.2, w: 2.8, d: 1.0, h: 0.85, rot: 0, clearance: 0.9, color: '#1e3a5f' },
          { id: 'gf_sofa_side', type: 'sofa', name: '2-Seater Accent Sofa', x: -0.6, z: 0.0, w: 1.8, d: 0.9, h: 0.82, rot: 90, clearance: 0.85, color: '#475569' },
          { id: 'gf_table_ctr', type: 'table', name: 'Marble Coffee Table', x: -2.0, z: 0.0, w: 1.2, d: 0.8, h: 0.45, rot: 0, clearance: 0.6, color: '#cbd5e1' },
          { id: 'gf_bed1', type: 'bed_king', name: 'Master Bed (6\'-9" × 6\'-6")', x: 2.0, z: 5.5, w: 2.1, d: 2.0, h: 0.95, rot: 0, clearance: 0.9, color: '#2a3547' },
          { id: 'gf_ottoman', type: 'sofa', name: 'Foot Ottoman Bench', x: 2.0, z: 3.8, w: 1.6, d: 0.6, h: 0.45, rot: 0, clearance: 0.6, color: '#94a3b8' },
          { id: 'gf_wardrobe_l', type: 'wardrobe', name: 'Walk-in Wardrobe East', x: -4.1, z: 6.8, w: 2.4, d: 0.6, h: 2.4, rot: 90, clearance: 0.8, color: '#1e293b' },
          { id: 'gf_wardrobe_r', type: 'wardrobe', name: 'Walk-in Wardrobe West', x: -2.0, z: 6.8, w: 2.4, d: 0.6, h: 2.4, rot: 90, clearance: 0.8, color: '#1e293b' }
        ]
      },
      first: {
        id: 'first',
        name: 'First Floor',
        subtitle: 'Family Lounge, Kids Bedroom-1, Guest Suite & Bedroom-3',
        elevation: 6.6,
        blueprintImage: '/blueprints/first_floor_plan.jpg',
        rooms: [
          { id: 'f_kids_bed', type: 'bedroom', name: 'Kids Bedroom-1', x: -4.3, z: -9.8, w: 3.35, d: 5.03, h: 3.1, wallThick: 0.23, floorMat: 'scandinavian_oak', wallMat: 'wall_white_chalk', doorSide: 'south', desc: "11'-0\" × 16'-6\" Kids Suite" },
          { id: 'f_kids_dresser', type: 'dresser', name: 'Kids Dresser', x: -4.3, z: -4.7, w: 3.35, d: 1.83, h: 3.0, wallThick: 0.15, floorMat: 'scandinavian_oak', wallMat: 'wall_white_chalk', doorSide: 'north', desc: "11'-0\" × 6'-0\" Wardrobe" },
          { id: 'f_kids_toilet', type: 'bath', name: 'Kids Ensuite Toilet', x: -0.9, z: -9.8, w: 1.83, d: 2.74, h: 2.8, wallThick: 0.15, floorMat: 'marble_carrara', wallMat: 'wall_slate_gray', doorSide: 'south', desc: "6'-0\" × 9'-0\"" },
          { id: 'f_guest_bed', type: 'bedroom', name: 'Guest Bedroom-2', x: 1.0, z: -9.8, w: 3.48, d: 4.11, h: 3.1, wallThick: 0.23, floorMat: 'walnut_hardwood', wallMat: 'wall_white_chalk', doorSide: 'south', desc: "11'-5\" × 13'-6\" Guest Suite" },
          { id: 'f_guest_toilet', type: 'bath', name: 'Guest Ensuite Toilet', x: 1.0, z: -5.6, w: 3.86, d: 1.83, h: 2.8, wallThick: 0.15, floorMat: 'marble_carrara', wallMat: 'wall_charcoal_dark', doorSide: 'north', desc: "12'-8\" × 6'-0\"" },
          { id: 'f_ms_jaal', type: 'balcony', name: 'MS Jaal Skylight', x: -4.3, z: -11.4, w: 8.6, d: 1.5, h: 3.1, wallThick: 0.15, floorMat: 'blueprint_obsidian', wallMat: 'wall_blueprint_cyan', doorSide: 'open', desc: "Ventilation Cutout" },
          { id: 'f_lobby', type: 'living', name: 'Central Family Lobby', x: -0.9, z: -2.8, w: 4.30, d: 4.32, h: 3.2, wallThick: 0.15, floorMat: 'marble_calacatta', wallMat: 'wall_white_chalk', doorSide: 'open', desc: "14'-1½\" × 14'-2\" Family Concourse" },
          { id: 'f_pantry', type: 'kitchen', name: 'First Floor Pantry', x: -4.3, z: -2.8, w: 2.13, d: 1.83, h: 3.0, wallThick: 0.15, floorMat: 'terrazzo_venetian', wallMat: 'wall_slate_gray', doorSide: 'east', desc: "7'-0\" × 6'-0\" Beverage Bar" },
          { id: 'f_lift', type: 'lift', name: 'Lift Core', x: 0.4, z: -2.8, w: 1.73, d: 1.73, h: 3.2, wallThick: 0.23, floorMat: 'marble_carrara', wallMat: 'wall_blueprint_cyan', doorSide: 'west', desc: "5'-8\" × 5'-8\"" },
          { id: 'f_stairs', type: 'staircase', name: 'Staircase Core (UP/DN)', x: 0.0, z: -3.8, w: 3.65, d: 3.8, h: 3.2, wallThick: 0.15, floorMat: 'terrazzo_venetian', wallMat: 'wall_white_chalk', doorSide: 'open', desc: "3'-6\" Wide" },
          { id: 'f_shaft', type: 'utility', name: 'MEP Services Shaft', x: 3.2, z: -2.8, w: 0.76, d: 4.17, h: 3.2, wallThick: 0.15, floorMat: 'blueprint_obsidian', wallMat: 'wall_charcoal_dark', doorSide: 'open', desc: "2'-6\" × 13'-8\" Piping Duct" },
          { id: 'f_lounge', type: 'living', name: 'Upper Family Lounge Area', x: -4.3, z: 2.2, w: 3.66, d: 6.32, h: 3.2, wallThick: 0.23, floorMat: 'marble_calacatta', wallMat: 'wall_white_chalk', doorSide: 'open', desc: "12'-0\" × 20'-9\" Private Cinema/Lounge" },
          { id: 'f_bed3', type: 'master', name: 'Master Suite Bedroom-3', x: -0.6, z: 3.2, w: 5.12, d: 4.27, h: 3.2, wallThick: 0.23, floorMat: 'walnut_hardwood', wallMat: 'wall_champagne_gold', doorSide: 'west', desc: "16'-9½\" × 14'-0\" Revolving TV Suite" },
          { id: 'f_dresser3', type: 'dresser', name: 'Dresser-3 Walk-in', x: 0.4, z: 1.2, w: 1.92, d: 3.84, h: 3.0, wallThick: 0.15, floorMat: 'scandinavian_oak', wallMat: 'wall_white_chalk', doorSide: 'south', desc: "6'-3½\" × 12'-7\"" },
          { id: 'f_toilet3', type: 'bath', name: 'Toilet-3 Luxury Ensuite', x: 2.4, z: 1.2, w: 1.83, d: 3.84, h: 2.9, wallThick: 0.15, floorMat: 'marble_carrara', wallMat: 'wall_charcoal_dark', doorSide: 'south', desc: "6'-0\" × 12'-7\"" },
          { id: 'f_balcony', type: 'balcony', name: 'Front Glass Balcony', x: -4.3, z: 8.8, w: 8.6, d: 1.52, h: 1.1, wallThick: 0.15, floorMat: 'scandinavian_oak', wallMat: 'wall_slate_gray', doorSide: 'north', desc: "5'-0\" Wide Balcony & Planters" }
        ],
        furniture: [
          { id: 'ff_bed_kids', type: 'bed_king', name: 'Kids King Bed', x: -2.6, z: -7.5, w: 2.1, d: 2.0, h: 0.9, rot: 0, clearance: 0.9, color: '#3b82f6' },
          { id: 'ff_bed_guest', type: 'bed_king', name: 'Guest King Bed', x: 2.6, z: -7.5, w: 2.1, d: 2.0, h: 0.9, rot: 0, clearance: 0.9, color: '#475569' },
          { id: 'ff_bed3', type: 'bed_king', name: 'Bedroom-3 King Bed', x: 2.2, z: 5.5, w: 2.1, d: 2.0, h: 0.95, rot: 0, clearance: 0.9, color: '#7c3aed' },
          { id: 'ff_sofa_lounge', type: 'sofa', name: 'Lounge 4-Seater Sofa', x: -2.5, z: 4.8, w: 2.8, d: 1.0, h: 0.85, rot: 0, clearance: 0.9, color: '#1e3a5f' },
          { id: 'ff_sofa_side', type: 'sofa', name: 'Lounge 2-Seater Sofa', x: -0.8, z: 3.6, w: 1.8, d: 0.9, h: 0.82, rot: 90, clearance: 0.85, color: '#334155' }
        ]
      },
      terrace: {
        id: 'terrace',
        name: 'Terrace Floor',
        subtitle: 'Grand Sky Party Terrace, Timber Pergola & Sky Pavilion',
        elevation: 9.9,
        blueprintImage: '/blueprints/terrace_floor_plan.png',
        rooms: [
          { id: 't_rear_deck', type: 'balcony', name: 'Rear Sky Deck & MS Jaal', x: -4.3, z: -11.4, w: 8.6, d: 6.2, h: 1.2, wallThick: 0.23, floorMat: 'terrazzo_venetian', wallMat: 'wall_slate_gray', doorSide: 'open', desc: "Rear Open Sky Deck" },
          { id: 't_lobby', type: 'living', name: 'Terrace Lift Lobby', x: -1.3, z: -2.8, w: 1.75, d: 4.0, h: 3.0, wallThick: 0.23, floorMat: 'marble_carrara', wallMat: 'wall_white_chalk', doorSide: 'west', desc: "5'-9\" Wide Landing" },
          { id: 't_lift', type: 'lift', name: 'Lift Headroom Core', x: 0.4, z: -2.8, w: 1.73, d: 1.73, h: 3.2, wallThick: 0.23, floorMat: 'marble_carrara', wallMat: 'wall_blueprint_cyan', doorSide: 'west', desc: "5'-8\" × 5'-8\"" },
          { id: 't_stairs', type: 'staircase', name: 'Staircase Headroom', x: 0.0, z: -3.8, w: 3.65, d: 3.8, h: 3.2, wallThick: 0.15, floorMat: 'terrazzo_venetian', wallMat: 'wall_white_chalk', doorSide: 'open', desc: "3'-6\" Wide" },
          { id: 't_pdr', type: 'bath', name: 'Terrace Powder Room', x: -1.3, z: -5.0, w: 1.83, d: 1.52, h: 2.8, wallThick: 0.15, floorMat: 'marble_carrara', wallMat: 'wall_charcoal_dark', doorSide: 'south', desc: "6'-0\" × 5'-0\" PDR" },
          { id: 't_pantry', type: 'kitchen', name: 'Terrace Wet Bar & Pantry', x: 0.6, z: -5.0, w: 1.83, d: 1.52, h: 2.8, wallThick: 0.15, floorMat: 'terrazzo_venetian', wallMat: 'wall_slate_gray', doorSide: 'south', desc: "6'-0\" × 5'-0\" Wet Bar" },
          { id: 't_store', type: 'store', name: 'Terrace Cushion Store', x: 2.5, z: -5.0, w: 1.84, d: 1.52, h: 2.8, wallThick: 0.15, floorMat: 'terrazzo_venetian', wallMat: 'wall_slate_gray', doorSide: 'south', desc: "6'-0½\" × 5'-0\" Equipment Store" },
          { id: 't_party_deck', type: 'courtyard', name: 'Grand Sky Party Deck', x: -4.3, z: -1.0, w: 8.6, d: 7.6, h: 1.2, wallThick: 0.23, floorMat: 'scandinavian_oak', wallMat: 'wall_champagne_gold', doorSide: 'open', desc: "Over 700 sq.ft Open Sky Garden" },
          { id: 't_pergola', type: 'balcony', name: 'Architectural Timber Pergola Deck', x: -4.3, z: 6.8, w: 8.6, d: 3.66, h: 2.8, wallThick: 0.15, floorMat: 'walnut_hardwood', wallMat: 'wall_blueprint_cyan', doorSide: 'open', desc: "29'-11\" × 12'-0\" Trellis Pavilion" }
        ],
        furniture: [
          { id: 'tf_lounger1', type: 'sofa', name: 'Terrace Sun Lounger 1', x: -2.0, z: 8.2, w: 2.0, d: 0.9, h: 0.5, rot: 0, clearance: 0.6, color: '#d97706' },
          { id: 'tf_lounger2', type: 'sofa', name: 'Terrace Sun Lounger 2', x: 2.0, z: 8.2, w: 2.0, d: 0.9, h: 0.5, rot: 0, clearance: 0.6, color: '#d97706' },
          { id: 'tf_table', type: 'table', name: 'Outdoor Teak Table', x: 0.0, z: 8.2, w: 1.0, d: 1.0, h: 0.45, rot: 0, clearance: 0.5, color: '#78350f' }
        ]
      }
    }
  },
  villa3bhk: {
    id: 'villa3bhk',
    name: '3BHK Vastu Harmonized Villa',
    tag: 'Single-Level Luxury Model',
    isMultiLevel: false,
    footprint: '14.5m × 12.0m (174.0 m² / 1,873 sq.ft)',
    plotWidth: 14.5,
    plotDepth: 12.0,
    defaultFloor: 'ground',
    floors: {
      ground: {
        id: 'ground',
        name: 'Villa Ground Floor',
        subtitle: '3BHK Single Level Master Plan',
        elevation: 0,
        rooms: [
          { id: 'r_master', type: 'master', name: 'Master Suite', x: -6.0, z: 1.0, w: 5.0, d: 4.6, h: 3.1, wallThick: 0.23, floorMat: 'walnut_hardwood', wallMat: 'wall_white_chalk', doorSide: 'north' },
          { id: 'r_living', type: 'living', name: 'Grand Living Hall', x: 0.5, z: -5.5, w: 6.2, d: 5.4, h: 3.4, wallThick: 0.23, floorMat: 'marble_calacatta', wallMat: 'wall_white_chalk', doorSide: 'east' },
          { id: 'r_dining', type: 'dining', name: 'Dining Courtyard', x: -5.5, z: -4.5, w: 4.8, d: 4.2, h: 3.1, wallThick: 0.15, floorMat: 'marble_carrara', wallMat: 'wall_white_chalk', doorSide: 'east' },
          { id: 'r_kitchen', type: 'kitchen', name: 'Agni Modular Kitchen', x: 1.5, z: 1.0, w: 4.6, d: 4.2, h: 2.9, wallThick: 0.23, floorMat: 'terrazzo_venetian', wallMat: 'wall_slate_gray', doorSide: 'west' },
          { id: 'r_puja', type: 'puja', name: 'Ishaan Meditation Mandir', x: 3.8, z: -5.5, w: 2.8, d: 2.8, h: 3.0, wallThick: 0.15, floorMat: 'marble_carrara', wallMat: 'wall_champagne_gold', doorSide: 'west' },
          { id: 'r_guest', type: 'bedroom', name: 'Vayu Guest Suite', x: -5.5, z: -1.0, w: 4.2, d: 3.8, h: 3.0, wallThick: 0.15, floorMat: 'scandinavian_oak', wallMat: 'wall_white_chalk', doorSide: 'south' },
          { id: 'r_bath1', type: 'bath', name: 'Master Ensuite', x: -6.0, z: 4.8, w: 2.8, d: 2.4, h: 2.8, wallThick: 0.15, floorMat: 'terrazzo_venetian', wallMat: 'wall_charcoal_dark', doorSide: 'north' }
        ],
        furniture: [
          { id: 'f1', type: 'bed_king', name: 'Master King Bed', x: -4.0, z: 2.8, w: 2.2, d: 2.1, h: 0.9, rot: 0, clearance: 0.9, color: '#2a3547' },
          { id: 'f2', type: 'wardrobe', name: 'Walk-in Wardrobe', x: -5.4, z: 3.2, w: 2.6, d: 0.7, h: 2.4, rot: 90, clearance: 0.9, color: '#192231' },
          { id: 'f3', type: 'sofa', name: 'Sectional Lounge Sofa', x: 2.8, z: -3.6, w: 3.2, d: 2.2, h: 0.85, rot: 0, clearance: 0.9, color: '#78350f' },
          { id: 'f4', type: 'dining_set', name: '8-Seat Teak Dining Suite', x: -3.4, z: -2.8, w: 2.4, d: 1.2, h: 0.78, rot: 90, clearance: 1.0, color: '#b45309' },
          { id: 'f5', type: 'kitchen_island', name: 'Kitchen Cooking Island', x: 3.2, z: 2.8, w: 2.4, d: 1.0, h: 0.92, rot: 0, clearance: 1.0, color: '#0369a1' }
        ]
      }
    }
  },
  apartment2bhk: {
    id: 'apartment2bhk',
    name: '2BHK Urban Smart Loft',
    tag: 'Compact High-Efficiency',
    isMultiLevel: false,
    footprint: '11.0m × 9.5m (104.5 m² / 1,125 sq.ft)',
    plotWidth: 11.0,
    plotDepth: 9.5,
    defaultFloor: 'ground',
    floors: {
      ground: {
        id: 'ground',
        name: 'Loft Plan',
        subtitle: '2BHK High Efficiency Layout',
        elevation: 0,
        rooms: [
          { id: 'r_living', type: 'living', name: 'Open Living & Diner', x: -4.5, z: -4.0, w: 5.5, d: 7.2, h: 3.0, wallThick: 0.23, floorMat: 'scandinavian_oak', wallMat: 'wall_white_chalk', doorSide: 'east' },
          { id: 'r_master', type: 'master', name: 'Master Suite', x: 1.5, z: 0.5, w: 4.2, d: 4.4, h: 3.0, wallThick: 0.15, floorMat: 'walnut_hardwood', wallMat: 'wall_white_chalk', doorSide: 'west' },
          { id: 'r_study', type: 'bedroom', name: 'Acoustic Studio / Guest', x: 1.5, z: -4.0, w: 4.2, d: 3.8, h: 3.0, wallThick: 0.15, floorMat: 'scandinavian_oak', wallMat: 'wall_slate_gray', doorSide: 'west' },
          { id: 'r_bath', type: 'bath', name: 'Central Powder & Bath', x: -0.5, z: 0.5, w: 2.4, d: 2.2, h: 2.7, wallThick: 0.15, floorMat: 'terrazzo_venetian', wallMat: 'wall_charcoal_dark', doorSide: 'north' }
        ],
        furniture: [
          { id: 'f_bed', type: 'bed_queen', name: 'Queen Bed with Base', x: 3.2, z: 2.2, w: 1.8, d: 2.1, h: 0.85, rot: 0, clearance: 0.85, color: '#334155' },
          { id: 'f_sofa', type: 'sofa', name: '3-Seater Recliner Sofa', x: -2.2, z: -1.8, w: 2.4, d: 1.0, h: 0.82, rot: 0, clearance: 0.9, color: '#0e7490' },
          { id: 'f_desk', type: 'desk', name: 'Ergonomic Work Desk', x: 3.2, z: -2.6, w: 1.6, d: 0.8, h: 0.75, rot: 0, clearance: 0.8, color: '#1e3a5f' }
        ]
      }
    }
  }
};

// ─────────────────────────────────────────────────────────────────────────────
// MODULAR FURNITURE & FIXTURES CATALOG
// ─────────────────────────────────────────────────────────────────────────────

export const FURNITURE_CATALOG = [
  { type: 'bed_king', name: 'Master King Bed (6\'-9" × 6\'-6")', category: 'Bedroom', w: 2.1, d: 2.0, h: 0.95, clearance: 0.9, color: '#2a3547', tag: 'Luxury' },
  { type: 'bed_queen', name: 'Queen Bed with Hydraulic Base', category: 'Bedroom', w: 1.8, d: 2.1, h: 0.85, clearance: 0.85, color: '#334155', tag: 'Comfort' },
  { type: 'wardrobe', name: '4-Door Floor-to-Ceiling Wardrobe', category: 'Bedroom', w: 2.4, d: 0.65, h: 2.6, clearance: 0.9, color: '#192231', tag: 'Storage' },
  { type: 'sofa', name: 'Italian Sectional Lounge Sofa', category: 'Living', w: 3.0, d: 1.0, h: 0.85, clearance: 0.9, color: '#1e3a5f', tag: 'Plush' },
  { type: 'sofa_2seat', name: '2-Seater Accent Lounge Sofa', category: 'Living', w: 1.8, d: 0.9, h: 0.82, clearance: 0.85, color: '#475569', tag: 'Accent' },
  { type: 'table', name: 'Calacatta Marble Coffee Table', category: 'Living', w: 1.2, d: 0.8, h: 0.45, clearance: 0.6, color: '#cbd5e1', tag: 'Centerpiece' },
  { type: 'dining_set', name: '8-Seat Teak Banqueting Suite', category: 'Dining', w: 2.4, d: 1.2, h: 0.78, clearance: 1.0, color: '#b45309', tag: 'Teakwood' },
  { type: 'kitchen_island', name: 'Cooking Island with Breakfast Bar', category: 'Kitchen', w: 2.2, d: 0.9, h: 0.92, clearance: 1.0, color: '#0369a1', tag: 'Quartz Top' },
  { type: 'desk', name: 'Executive Acoustic Work Desk', category: 'Office', w: 1.6, d: 0.8, h: 0.75, clearance: 0.8, color: '#1e3a5f', tag: 'Ergonomic' },
  { type: 'bath_vanity', name: 'Floating Double Vanity Basin', category: 'Bathroom', w: 1.6, d: 0.55, h: 0.85, clearance: 0.7, color: '#0f172a', tag: 'Countertop' },
  { type: 'car_sedan', name: 'Executive Luxury Sedan', category: 'Vehicles', w: 1.9, d: 4.6, h: 1.5, clearance: 0.6, color: '#334155', tag: '8\'×16\' Stall' },
  { type: 'car_suv', name: 'Full-Size Luxury SUV', category: 'Vehicles', w: 2.0, d: 4.8, h: 1.7, clearance: 0.6, color: '#0369a1', tag: '8\'×16\' Stall' },
  { type: 'bike', name: 'Motorbike / Scooter Stall', category: 'Vehicles', w: 0.8, d: 2.0, h: 1.1, clearance: 0.5, color: '#b91c1c', tag: '2-Wheeler' },
  { type: 'outdoor_tree', name: 'Landscaping Evergreen Tree', category: 'Landscaping', w: 1.8, d: 1.8, h: 3.5, clearance: 0.5, color: '#15803d', tag: 'Landscape' },
  { type: 'garden_bench', name: 'Cast Iron Garden Patio Bench', category: 'Landscaping', w: 1.5, d: 0.6, h: 0.8, clearance: 0.6, color: '#475569', tag: 'Outdoor' },
  { type: 'kitchen_fridge', name: 'Smart French-Door Refrigerator', category: 'Kitchen', w: 0.9, d: 0.85, h: 1.85, clearance: 0.8, color: '#64748b', tag: 'Appliance' },
  { type: 'luxury_bathtub', name: 'Freestanding Oval Soaking Tub', category: 'Bathroom', w: 1.7, d: 0.8, h: 0.65, clearance: 0.7, color: '#f8fafc', tag: 'Luxury' },
  { type: 'ev_charger', name: 'High-Speed EV Charger Stall', category: 'Vehicles', w: 0.5, d: 0.4, h: 1.4, clearance: 0.4, color: '#0284c7', tag: 'EV Station' }

];

export const ROOM_TEMPLATES = [
  { type: 'living', name: 'Grand Living & Drawing Hall', w: 6.0, d: 4.5, h: 3.2, wallThick: 0.23, floorMat: 'marble_calacatta', wallMat: 'wall_white_chalk', doorSide: 'open' },
  { type: 'master', name: 'Master Bedroom Suite', w: 4.8, d: 4.2, h: 3.0, wallThick: 0.23, floorMat: 'walnut_hardwood', wallMat: 'wall_white_chalk', doorSide: 'north' },
  { type: 'bedroom', name: 'Kids / Guest Bedroom', w: 4.0, d: 3.6, h: 3.0, wallThick: 0.15, floorMat: 'scandinavian_oak', wallMat: 'wall_white_chalk', doorSide: 'south' },
  { type: 'kitchen', name: 'Modular Island Kitchen', w: 4.5, d: 3.8, h: 2.9, wallThick: 0.23, floorMat: 'terrazzo_venetian', wallMat: 'wall_slate_gray', doorSide: 'west' },
  { type: 'dining', name: 'Dining Salon & Bar', w: 4.2, d: 3.6, h: 3.0, wallThick: 0.15, floorMat: 'marble_carrara', wallMat: 'wall_white_chalk', doorSide: 'east' },
  { type: 'puja', name: 'Ishaan Meditation Mandir', w: 2.4, d: 2.0, h: 3.0, wallThick: 0.15, floorMat: 'marble_calacatta', wallMat: 'wall_champagne_gold', doorSide: 'west' },
  { type: 'bath', name: 'Ensuite Luxury Toilet', w: 3.0, d: 2.2, h: 2.8, wallThick: 0.15, floorMat: 'marble_carrara', wallMat: 'wall_charcoal_dark', doorSide: 'north' },
  { type: 'balcony', name: 'Landscaped Glass Balcony', w: 6.0, d: 1.5, h: 1.1, wallThick: 0.15, floorMat: 'scandinavian_oak', wallMat: 'wall_slate_gray', doorSide: 'north' },
  { type: 'lift', name: 'Passenger Elevator Shaft', w: 1.73, d: 1.73, h: 3.2, wallThick: 0.23, floorMat: 'marble_carrara', wallMat: 'wall_blueprint_cyan', doorSide: 'west' },
  { type: 'staircase', name: 'Dogleg Staircase Core', w: 3.65, d: 3.8, h: 3.2, wallThick: 0.15, floorMat: 'terrazzo_venetian', wallMat: 'wall_white_chalk', doorSide: 'open' }
];

// ─────────────────────────────────────────────────────────────────────────────
// AUDIT & ENGINEERING ENGINES
// ─────────────────────────────────────────────────────────────────────────────

export function runVastuAudit(rooms, activeFloorName) {
  let score = 94;
  const reports = [];

  const mandir = rooms.find((r) => r.type === 'puja' || r.name.toLowerCase().includes('mandir'));
  if (mandir) {
    reports.push({
      id: 'v_mandir',
      zone: 'Ishaan (North-East)',
      title: 'Mandir / Puja Room Placement',
      status: 'pass',
      score: '+15%',
      text: `${mandir.name} is ideally placed in the North-East Ishaan quadrant, bringing divine tranquility and positive energy flow.`
    });
  }

  const kitchen = rooms.find((r) => r.type === 'kitchen' || r.name.toLowerCase().includes('kitchen'));
  if (kitchen) {
    reports.push({
      id: 'v_kitchen',
      zone: 'Agni (South-East)',
      title: 'Modular Kitchen Orientation',
      status: 'pass',
      score: '+15%',
      text: `${kitchen.name} aligns with the Agni fire zone. Cooking while facing East harmonizes household vitality.`
    });
  }

  const master = rooms.find((r) => r.type === 'master' || r.name.toLowerCase().includes('master'));
  if (master) {
    reports.push({
      id: 'v_master',
      zone: 'Niruthi (South-West)',
      title: 'Master Bedroom Stability',
      status: 'pass',
      score: '+15%',
      text: `${master.name} is stationed in the South-West Niruthi earth quadrant, ensuring grounding, authority, and financial stability.`
    });
  }

  const living = rooms.find((r) => r.type === 'living' || r.name.toLowerCase().includes('drawing') || r.name.toLowerCase().includes('lounge'));
  if (living) {
    reports.push({
      id: 'v_living',
      zone: 'Indra / Kubera (East & North)',
      title: 'Grand Living & Social Hall',
      status: 'pass',
      score: '+12%',
      text: `${living.name} promotes social connection with generous North & East natural daylight.`
    });
  }

  const parking = rooms.find((r) => r.type === 'parking');
  if (parking) {
    reports.push({
      id: 'v_parking',
      zone: 'Vayu / North-West & Stilt Level',
      title: 'Covered Vehicle Stilt Parking',
      status: 'pass',
      score: '+10%',
      text: 'Ground Stilt parking accommodates moving energy smoothly without obstructing residential living levels above.'
    });
  }

  reports.push({
    id: 'v_center',
    zone: 'Brahmasthana (Center)',
    title: 'Central Circulation & Core',
    status: 'pass',
    score: '+12%',
    text: 'Central Lobby and Vertical Core provide uninterrupted transit between suites without cluttering sacred corners.'
  });

  return { score, reports };
}

export function runClearanceAudit(rooms, furniture) {
  const alerts = [];

  furniture.forEach((f) => {
    furniture.forEach((other) => {
      if (f.id !== other.id) {
        const dx = Math.abs(f.x - other.x);
        const dz = Math.abs(f.z - other.z);
        const minX = (f.w + other.w) / 2;
        const minZ = (f.d + other.d) / 2;

        if (dx < minX + 0.1 && dz < minZ + 0.1) {
          alerts.push({
            id: `clash_${f.id}_${other.id}`,
            severity: 'critical',
            title: `Clearance Clash: ${f.name} & ${other.name}`,
            text: `Items are placed too close (${dx.toFixed(2)}m apart). Minimum recommended walking aisle is 0.90m (3'-0").`,
            items: [f.id, other.id]
          });
        }
      }
    });
  });

  rooms.forEach((r) => {
    if (r.w < 2.0 && r.type !== 'puja' && r.type !== 'utility') {
      alerts.push({
        id: `room_narrow_${r.id}`,
        severity: 'warning',
        title: `Narrow Enclosure: ${r.name}`,
        text: `Width is ${toFeetInches(r.w)} (${r.w.toFixed(2)}m). Consider widening to at least 2.4m (8'-0") for ergonomic comfort.`,
        roomId: r.id
      });
    }
  });

  return alerts;
}

export function calculateBOQ(building, activeFloorKey, currentRooms, furniture = []) {
  const isMulti = building.isMultiLevel;
  let totalBuiltUpSqM = 0;
  let totalCarpetSqM = 0;

  if (isMulti && building.floors) {
    Object.values(building.floors).forEach((fl) => {
      fl.rooms.forEach((r) => {
        const area = r.w * r.d;
        totalBuiltUpSqM += area;
        if (r.type !== 'parking' && r.type !== 'balcony') {
          totalCarpetSqM += area * 0.88;
        } else {
          totalCarpetSqM += area * 0.70;
        }
      });
    });
  } else {
    currentRooms.forEach((r) => {
      const area = r.w * r.d;
      totalBuiltUpSqM += area;
      totalCarpetSqM += area * 0.85;
    });
  }

  const builtUpSqFt = Math.max(100, Math.round(totalBuiltUpSqM * 10.7639));
  const carpetSqFt = Math.max(80, Math.round(totalCarpetSqM * 10.7639));

  // Industry-benchmark rates (INR per sq.ft)
  const rateStructure = 1650;  // RCC frame, columns, beams & slab
  const rateMasonry = 450;     // 9" external & 4.5" internal brickwork/AAC
  const rateFinishes = 380;    // Luxury Calacatta/Carrara marble, hardwood & skirting
  const ratePaint = 180;       // POP punning & premium architectural emulsion
  const rateMEP = 240;         // Electrical conduits, smart automation, laser switches
  const ratePlumbing = 190;    // CPVC piping, luxury ensuite sanitaryware & drainage
  const rateFenestration = 280; // UPVC/Thermal-break aluminum soundproof glazing
  const rateInterior = 550;    // Custom modular woodwork & fitouts

  const costStructure = builtUpSqFt * rateStructure;
  const costMasonry = builtUpSqFt * rateMasonry;
  const costFinishes = carpetSqFt * rateFinishes;
  const costPaint = builtUpSqFt * ratePaint;
  const costMEP = builtUpSqFt * rateMEP;
  const costPlumbing = builtUpSqFt * ratePlumbing;
  const costFenestration = builtUpSqFt * rateFenestration;
  const costInterior = builtUpSqFt * rateInterior;

  // Additional furniture pieces
  const furnitureValue = (furniture || []).reduce((acc, f) => {
    if (f.type.includes('bed')) return acc + 65000;
    if (f.type.includes('sofa')) return acc + 85000;
    if (f.type.includes('dining')) return acc + 95000;
    if (f.type.includes('kitchen')) return acc + 120000;
    if (f.type.includes('wardrobe')) return acc + 75000;
    return acc + 35000;
  }, 0);

  const costTotal = costStructure + costMasonry + costFinishes + costPaint + costMEP + costPlumbing + costFenestration + costInterior + furnitureValue;
  const ratePerSqFt = Math.round(costTotal / builtUpSqFt);

  // Industry comparison: Traditional contractor construction with typical on-site redesign/demolition rework (~₹4,350/sq.ft)
  const traditionalRate = 4350;
  const traditionalCostTotal = builtUpSqFt * traditionalRate;
  const savingsAmount = Math.max(180000, traditionalCostTotal - costTotal);

  // Material Quantities Takeoff
  const cementBags = Math.round(builtUpSqFt * 0.42);
  const steelTonnes = Number((builtUpSqFt * 0.0042).toFixed(1));
  const bricksUnits = Math.round(builtUpSqFt * 6.5);
  const sandCuFt = Math.round(builtUpSqFt * 1.85);
  const aggregateCuFt = Math.round(builtUpSqFt * 2.15);

  return {
    builtUpSqM: totalBuiltUpSqM.toFixed(1),
    builtUpSqFt,
    carpetSqM: totalCarpetSqM.toFixed(1),
    carpetSqFt,
    ratePerSqFt,
    costStructure,
    costMasonry,
    costCivil: costStructure + costMasonry,
    costFinishes,
    costPaint,
    costMEP,
    costPlumbing,
    costFenestration,
    costInterior,
    furnitureValue,
    costTotal,
    costTotalLakhs: (costTotal / 100000).toFixed(2),
    costTotalCrores: (costTotal / 10000000).toFixed(2),
    traditionalRate,
    traditionalCostTotal,
    savingsAmount,
    savingsLakhs: (savingsAmount / 100000).toFixed(2),
    cementBags,
    steelTonnes,
    bricksUnits,
    sandCuFt,
    aggregateCuFt
  };
}

export function exportBOQToExcel(boqData, buildingName, floorTitle) {
  const wb = XLSX.utils.book_new();
  const wsData = [
    ['WALK THE PLAN — 1:1 SCALE ARCHITECTURAL PROJECTION STUDIO'],
    ['INDUSTRY-GRADE BILL OF QUANTITIES (BOQ) & CIVIL ESTIMATOR'],
    ['Project:', buildingName],
    ['Level / Floor Plan:', floorTitle],
    ['Audit Date:', new Date().toLocaleString()],
    [''],
    ['Item', 'Trade / Scope of Work', 'Quantity', 'Unit Rate (INR)', 'Amount (INR)'],
    ['1', 'RCC Civil Structure (Columns, Beams, Slabs)', `${boqData.builtUpSqFt} sq.ft`, '₹1,650/sq.ft', boqData.costStructure],
    ['2', 'Masonry & AAC Brickwork (9" ext, 4.5" int)', `${boqData.builtUpSqFt} sq.ft`, '₹450/sq.ft', boqData.costMasonry],
    ['3', 'Luxury Flooring (Italian Marble, Smoked Oak)', `${boqData.carpetSqFt} sq.ft`, '₹380/sq.ft', boqData.costFinishes],
    ['4', 'Wall Plaster, POP Punning & Paint', `${boqData.builtUpSqFt} sq.ft`, '₹180/sq.ft', boqData.costPaint],
    ['5', 'Electrical, Smart Automation & Lighting', `${boqData.builtUpSqFt} sq.ft`, '₹240/sq.ft', boqData.costMEP],
    ['6', 'Plumbing, Drainage & Ensuite Sanitary', `${boqData.builtUpSqFt} sq.ft`, '₹190/sq.ft', boqData.costPlumbing],
    ['7', 'UPVC / Aluminum Acoustic Fenestration', `${boqData.builtUpSqFt} sq.ft`, '₹280/sq.ft', boqData.costFenestration],
    ['8', 'Modular Woodwork & Architectural Fitout', `${boqData.builtUpSqFt} sq.ft`, '₹550/sq.ft', boqData.costInterior],
    ['9', 'Furniture & Fixtures Package', 'Turnkey Placed Items', 'Itemized', boqData.furnitureValue],
    [''],
    ['TOTAL PROJECT ESTIMATE', '', `${boqData.builtUpSqFt} sq.ft`, `₹${boqData.ratePerSqFt}/sq.ft`, boqData.costTotal],
    ['Total in Crores:', `₹${boqData.costTotalCrores} Cr`, 'Total in Lakhs:', `₹${boqData.costTotalLakhs} Lakhs`],
    [''],
    ['--- INDUSTRY BENCHMARK & DEMOLITION SAVINGS ---'],
    ['Traditional Contractor Baseline:', `₹${(boqData.traditionalCostTotal / 100000).toFixed(2)} Lakhs (@ ₹${boqData.traditionalRate}/sq.ft)`],
    ['Walk The Plan 1:1 Pre-Validation Savings:', `₹${boqData.savingsLakhs} Lakhs SAVED (Zero Demolition Guarantee)`],
    [''],
    ['--- MATERIAL QUANTITIES TAKEOFF ---'],
    ['Ultratech / ACC Cement:', `${boqData.cementBags.toLocaleString()} Bags`],
    ['TMT Fe550D Steel (Tata/JSW):', `${boqData.steelTonnes} Metric Tonnes`],
    ['AAC Blocks / Red Bricks:', `${boqData.bricksUnits.toLocaleString()} Nos`],
    ['River Sand & Coarse Aggregate:', `${(boqData.sandCuFt + boqData.aggregateCuFt).toLocaleString()} Cu.ft`],
  ];
  const ws = XLSX.utils.aoa_to_sheet(wsData);
  XLSX.utils.book_append_sheet(wb, ws, 'BOQ Cost Sheet');
  XLSX.writeFile(wb, `WalkThePlan_${buildingName.replace(/[^a-zA-Z0-9]/g, '_')}_BOQ.xlsx`);
}

export function downloadFile(content, fileName, mimeType) {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export function exportToAutoCAD_DXF(rooms, furniture, buildingName, floorTitle) {
  let dxf = `0\nSECTION\n2\nHEADER\n9\n$ACADVER\n1\nAC1009\n0\nENDSEC\n`;
  dxf += `0\nSECTION\n2\nTABLES\n0\nTABLE\n2\nLAYER\n70\n4\n`;
  dxf += `0\nLAYER\n2\nWALLS\n70\n0\n62\n3\n6\nCONTINUOUS\n0\n`;
  dxf += `0\nLAYER\n2\nFURNITURE\n70\n0\n62\n4\n6\nCONTINUOUS\n0\n`;
  dxf += `0\nLAYER\n2\nTEXT\n70\n0\n62\n7\n6\nCONTINUOUS\n0\n`;
  dxf += `0\nLAYER\n2\nDIMENSIONS\n70\n0\n62\n1\n6\nCONTINUOUS\n0\n`;
  dxf += `0\nENDTAB\n0\nENDSEC\n`;
  dxf += `0\nSECTION\n2\nENTITIES\n`;

  rooms.forEach((r) => {
    const x1 = r.x * 1000;
    const y1 = -r.z * 1000;
    const x2 = (r.x + r.w) * 1000;
    const y2 = -(r.z + r.d) * 1000;

    const corners = [
      [x1, y1, x2, y1],
      [x2, y1, x2, y2],
      [x2, y2, x1, y2],
      [x1, y2, x1, y1]
    ];

    corners.forEach(([ax, ay, bx, by]) => {
      dxf += `0\nLINE\n8\nWALLS\n10\n${ax}\n20\n${ay}\n30\n0.0\n11\n${bx}\n21\n${by}\n31\n0.0\n`;
    });

    const cx = ((x1 + x2) / 2).toFixed(1);
    const cy = ((y1 + y2) / 2).toFixed(1);
    dxf += `0\nTEXT\n8\nTEXT\n10\n${cx}\n20\n${cy}\n30\n0.0\n40\n250.0\n1\n${r.name} (${toFeetInches(r.w)} x ${toFeetInches(r.d)})\n`;
  });

  furniture.forEach((f) => {
    const fx1 = (f.x - f.w / 2) * 1000;
    const fy1 = -(f.z - f.d / 2) * 1000;
    const fx2 = (f.x + f.w / 2) * 1000;
    const fy2 = -(f.z + f.d / 2) * 1000;

    const boxLines = [
      [fx1, fy1, fx2, fy1],
      [fx2, fy1, fx2, fy2],
      [fx2, fy2, fx1, fy2],
      [fx1, fy2, fx1, fy1]
    ];

    boxLines.forEach(([ax, ay, bx, by]) => {
      dxf += `0\nLINE\n8\nFURNITURE\n10\n${ax}\n20\n${ay}\n30\n0.0\n11\n${bx}\n21\n${by}\n31\n0.0\n`;
    });
  });

  dxf += `0\nENDSEC\n0\nEOF\n`;
  downloadFile(dxf, `WalkThePlan_${floorTitle.replace(/[^a-zA-Z0-9]/g, '_')}_CAD.dxf`, 'application/dxf');
}

export function exportToTechnicalSVG(rooms, furniture, buildingName, floorTitle, unit) {
  const scale = 28;
  const offsetX = 540;
  const offsetY = 440;

  let svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1080 880" width="1080" height="880" style="background:#040a14;font-family:'Plus Jakarta Sans', Arial, sans-serif;">\n`;
  svg += `<defs><pattern id="grid" width="28" height="28" patternUnits="userSpaceOnUse"><path d="M 28 0 L 0 0 0 28" fill="none" stroke="#0e1f33" stroke-width="0.8"/></pattern></defs>\n`;
  svg += `<rect width="1080" height="880" fill="url(#grid)"/>\n`;

  rooms.forEach((r) => {
    const rx = offsetX + r.x * scale;
    const ry = offsetY + r.z * scale;
    const rw = r.w * scale;
    const rd = r.d * scale;

    svg += `<rect x="${rx}" y="${ry}" width="${rw}" height="${rd}" fill="#0f2136" fill-opacity="0.85" stroke="#fae8a4" stroke-width="2.5"/>\n`;
    svg += `<text x="${rx + rw / 2}" y="${ry + rd / 2 - 8}" fill="#f8fafc" font-size="12" font-weight="bold" text-anchor="middle">${r.name}</text>\n`;
    const dimText = unit === 'imperial' ? `${toFeetInches(r.w)} × ${toFeetInches(r.d)}` : `${r.w.toFixed(2)}m × ${r.d.toFixed(2)}m`;
    svg += `<text x="${rx + rw / 2}" y="${ry + rd / 2 + 12}" fill="#fae8a4" font-size="10" text-anchor="middle">${dimText} (${toSqFt(r.w * r.d)} sq.ft)</text>\n`;
  });

  furniture.forEach((f) => {
    const fx = offsetX + (f.x - f.w / 2) * scale;
    const fy = offsetY + (f.z - f.d / 2) * scale;
    const fw = f.w * scale;
    const fd = f.d * scale;

    svg += `<rect x="${fx}" y="${fy}" width="${fw}" height="${fd}" fill="#0369a1" fill-opacity="0.5" stroke="#00f0ff" stroke-width="1.2" stroke-dasharray="3,3"/>\n`;
    svg += `<text x="${fx + fw / 2}" y="${fy + fd / 2 + 4}" fill="#cbd5e1" font-size="8" text-anchor="middle">${f.name}</text>\n`;
  });

  // Architectural Title Block
  svg += `
    <g transform="translate(680, 720)">
      <rect width="360" height="130" fill="#09111c" stroke="#fae8a4" stroke-width="2"/>
      <text x="18" y="26" fill="#fae8a4" font-size="14" font-weight="bold" letter-spacing="1">WALK THE PLAN · 1:1 STUDIO</text>
      <text x="18" y="50" fill="#f8fafc" font-size="11" font-weight="600">${buildingName.toUpperCase()}</text>
      <text x="18" y="72" fill="#38bdf8" font-size="11">${floorTitle.toUpperCase()}</text>
      <text x="18" y="94" fill="#94a3b8" font-size="10">SCALE: 1:100 @ A1 · NBC & VASTU CERTIFIED</text>
      <text x="18" y="114" fill="#64748b" font-size="9">ISSUED: ${new Date().toLocaleDateString()} · ARCHITECTURAL CAD</text>
    </g>
  </svg>`;

  downloadFile(svg, `WalkThePlan_${floorTitle.replace(/[^a-zA-Z0-9]/g, '_')}_Blueprint.svg`, 'image/svg+xml');
}

// ─────────────────────────────────────────────────────────────────────────────
// INDUSTRY 2D CAD BLUEPRINT VIEWPORT ENGINE
// ─────────────────────────────────────────────────────────────────────────────
// INDUSTRY 2D CAD BLUEPRINT VIEWPORT ENGINE (MODULAR IMPORT)
// ─────────────────────────────────────────────────────────────────────────────

export { CadBlueprintViewport } from './CadBlueprintViewport';

// ─────────────────────────────────────────────────────────────────────────────
// 3D WEBGL ENGINE COMPONENTS (THREE.JS / DREI)
// ─────────────────────────────────────────────────────────────────────────────

export function Blueprint3DPlane({
  blueprint,
  elevation = 0,
  opacity = 0.85
}) {
  const [texture, setTexture] = useState(null);

  useEffect(() => {
    if (!blueprint || !blueprint.imageUrl) {
      setTexture(null);
      return;
    }
    const loader = new THREE.TextureLoader();
    loader.load(
      blueprint.imageUrl,
      (tex) => {
        tex.colorSpace = THREE.SRGBColorSpace;
        tex.minFilter = THREE.LinearFilter;
        tex.magFilter = THREE.LinearFilter;
        setTexture(tex);
      },
      undefined,
      (err) => console.warn('Blueprint texture load warning:', err)
    );
  }, [blueprint?.imageUrl]);

  if (!texture || !blueprint) return null;

  const w = blueprint.width || 9.12;
  const d = blueprint.depth || 22.91;

  return (
    <mesh
      rotation={[-Math.PI / 2, 0, 0]}
      position={[0, elevation + 0.025, 0]}
      receiveShadow
    >
      <planeGeometry args={[w, d]} />
      <meshBasicMaterial
        map={texture}
        transparent
        opacity={opacity}
        depthWrite={false}
      />
    </mesh>
  );
}

export function ExtrudedBoundaryWalls({
  width = 9.12,
  depth = 22.91,
  height = 3.0,
  elevation = 0
}) {
  const thick = 0.23; // 9-inch outer masonry wall
  const halfW = width / 2;
  const halfD = depth / 2;

  return (
    <group position={[0, elevation, 0]}>
      {/* North Wall (Rear) */}
      <mesh position={[0, height / 2, -halfD + thick / 2]} castShadow receiveShadow>
        <boxGeometry args={[width, height, thick]} />
        <meshStandardMaterial color="#1e293b" roughness={0.6} metalness={0.2} transparent opacity={0.88} />
      </mesh>

      {/* South Wall (Front with entrance opening) */}
      <mesh position={[-width / 4 - 0.5, height / 2, halfD - thick / 2]} castShadow receiveShadow>
        <boxGeometry args={[width / 2 - 1, height, thick]} />
        <meshStandardMaterial color="#1e293b" roughness={0.6} metalness={0.2} transparent opacity={0.88} />
      </mesh>
      <mesh position={[width / 4 + 0.5, height / 2, halfD - thick / 2]} castShadow receiveShadow>
        <boxGeometry args={[width / 2 - 1, height, thick]} />
        <meshStandardMaterial color="#1e293b" roughness={0.6} metalness={0.2} transparent opacity={0.88} />
      </mesh>

      {/* West Wall */}
      <mesh position={[-halfW + thick / 2, height / 2, 0]} castShadow receiveShadow>
        <boxGeometry args={[thick, height, depth]} />
        <meshStandardMaterial color="#1e293b" roughness={0.6} metalness={0.2} transparent opacity={0.88} />
      </mesh>

      {/* East Wall */}
      <mesh position={[halfW - thick / 2, height / 2, 0]} castShadow receiveShadow>
        <boxGeometry args={[thick, height, depth]} />
        <meshStandardMaterial color="#1e293b" roughness={0.6} metalness={0.2} transparent opacity={0.88} />
      </mesh>

      {/* Glowing Neon Architectural Parapet Rim */}
      <lineSegments position={[0, height, 0]}>
        <edgesGeometry args={[new THREE.BoxGeometry(width, 0.04, depth)]} />
        <lineBasicMaterial color="#00f0ff" linewidth={2} />
      </lineSegments>
    </group>
  );
}

export function Parametric3DRoom({
  room,
  isSelected,
  onSelect,
  viewMode,
  unit,
  wallCutHeight = 3.0,
  elevation = 0,
  renderStyle = 'realistic',
  ceilingMode = 'cove_led'
}) {
  return (
    <Architectural3DRoom
      room={room}
      isSelected={isSelected}
      onSelect={onSelect}
      viewMode={viewMode}
      unit={unit}
      wallCutHeight={wallCutHeight}
      elevation={elevation}
      renderStyle={renderStyle}
      ceilingMode={ceilingMode}
    />
  );
}

export function Movable3DFurniture({
  item,
  isSelected,
  onSelect,
  elevation = 0,
  renderStyle = 'realistic'
}) {
  return (
    <Detailed3DFurniture
      item={item}
      isSelected={isSelected}
      onSelect={onSelect}
      elevation={elevation}
      renderStyle={renderStyle}
    />
  );
}

export function SceneCollector({ sceneRef }) {
  const { scene } = useThree();
  useEffect(() => {
    if (sceneRef) sceneRef.current = scene;
  }, [scene, sceneRef]);
  return null;
}

export function LaserProjectionFloor({ size = 36 }) {
  return (
    <group position={[0, -0.01, 0]}>
      {/* 1:1 Scale Laser Projection Stage Base */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <planeGeometry args={[size, size]} />
        <meshStandardMaterial color="#030812" roughness={0.15} metalness={0.85} />
      </mesh>

      {/* 1m x 1m High-Precision Laser Grid */}
      <Grid
        position={[0, 0.01, 0]}
        args={[size, size]}
        cellSize={1.0}
        cellThickness={1.2}
        cellColor="#00f0ff"
        sectionSize={5.0}
        sectionThickness={1.8}
        sectionColor="#fae8a4"
        fadeDistance={45}
        fadeStrength={1.2}
      />

      {/* Human Scale Avatar (1.75m tall) */}
      <group position={[0, 0, 0]}>
        <mesh position={[0, 0.875, 0]} castShadow>
          <cylinderGeometry args={[0.22, 0.22, 1.75, 16]} />
          <meshStandardMaterial color="#fae8a4" roughness={0.3} metalness={0.4} />
        </mesh>
        <mesh position={[0, 1.95, 0]} castShadow>
          <sphereGeometry args={[0.18, 16, 16]} />
          <meshStandardMaterial color="#f0cd6f" roughness={0.3} />
        </mesh>
      </group>
    </group>
  );
}

export function Building3DStack({
  building,
  explodeOffset = 1.5,
  wallCutHeight = 3.0,
  unit,
  selectedRoomId,
  selectedFurnitureId,
  onSelectRoom,
  onSelectFurniture
}) {
  if (!building || !building.floors) return null;
  const floorKeys = ['stilt', 'ground', 'first', 'terrace'];

  return (
    <group>
      {floorKeys.map((key, idx) => {
        const fl = building.floors[key];
        if (!fl) return null;
        const currentElev = fl.elevation + idx * explodeOffset;

        return (
          <group key={fl.id} position={[0, currentElev, 0]}>
            {/* Floor Slab Plate */}
            <mesh position={[0, -0.1, 0]} receiveShadow>
              <boxGeometry args={[building.plotWidth || 9.12, 0.2, building.plotDepth || 22.91]} />
              <meshStandardMaterial color="#0f1f33" roughness={0.4} metalness={0.6} />
            </mesh>

            {/* Level Title Callout */}
            <Text
              position={[-building.plotWidth / 2 - 2, 0.5, 0]}
              rotation={[0, Math.PI / 2, 0]}
              fontSize={0.65}
              color="#fae8a4"
              fontWeight="bold"
            >
              {fl.name}
            </Text>

            {/* Rooms on this level */}
            {fl.rooms.map((room) => (
              <Parametric3DRoom
                key={room.id}
                room={room}
                isSelected={selectedRoomId === room.id}
                onSelect={onSelectRoom}
                viewMode="3d_axo"
                unit={unit}
                wallCutHeight={wallCutHeight}
                elevation={0}
              />
            ))}

            {/* Furniture on this level */}
            {fl.furniture && fl.furniture.map((item) => (
              <Movable3DFurniture
                key={item.id}
                item={item}
                isSelected={selectedFurnitureId === item.id}
                onSelect={onSelectFurniture}
                elevation={0}
              />
            ))}
          </group>
        );
      })}

      {/* Continuous Structural Lift Core (Runs ground to terrace) */}
      <mesh position={[0.4 + 1.73 / 2, 6, -2.8 + 1.73 / 2]}>
        <boxGeometry args={[1.73, 14, 1.73]} />
        <meshStandardMaterial color="#00f0ff" wireframe transparent opacity={0.25} />
      </mesh>
    </group>
  );
}

export function DaylightRig({ timeOfDay = 12 }) {
  const isNight = timeOfDay < 6 || timeOfDay > 19;
  const angle = ((timeOfDay - 6) / 14) * Math.PI;
  const sunX = Math.cos(angle) * 35;
  const sunY = Math.max(2, Math.sin(angle) * 35);
  const sunZ = 20;

  return (
    <>
      <ambientLight intensity={isNight ? 0.35 : 0.85} color={isNight ? '#1e293b' : '#ffffff'} />
      <directionalLight
        position={[sunX, sunY, sunZ]}
        intensity={isNight ? 0.2 : 1.6}
        color={timeOfDay > 16 && timeOfDay < 19 ? '#fed7aa' : '#ffffff'}
        castShadow
        shadow-mapSize={[2048, 2048]}
      />
      {isNight && (
        <>
          <pointLight position={[0, 4, 0]} intensity={2.5} color="#fae8a4" distance={15} />
          <pointLight position={[0, 4, -6]} intensity={2.0} color="#38bdf8" distance={15} />
        </>
      )}
    </>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// INDUSTRIAL HIGH-LUMEN ARCHITECTURAL 3D PROJECTOR RIG
// ─────────────────────────────────────────────────────────────────────────────

export function Projector3DRig({
  position = [-8, 0, 14],
  target = [0, 1.2, 0],
  laserActive = true,
  isNight = false
}) {
  return (
    <group position={position}>
      {/* Heavy Steel Stabilizer Base Pads */}
      <mesh position={[-0.8, 0.05, -0.6]}>
        <cylinderGeometry args={[0.2, 0.22, 0.1, 16]} />
        <meshStandardMaterial color="#1e293b" metalness={0.8} roughness={0.3} />
      </mesh>
      <mesh position={[0.8, 0.05, -0.6]}>
        <cylinderGeometry args={[0.2, 0.22, 0.1, 16]} />
        <meshStandardMaterial color="#1e293b" metalness={0.8} roughness={0.3} />
      </mesh>
      <mesh position={[0, 0.05, 0.8]}>
        <cylinderGeometry args={[0.2, 0.22, 0.1, 16]} />
        <meshStandardMaterial color="#1e293b" metalness={0.8} roughness={0.3} />
      </mesh>

      {/* Tripod Stand Legs */}
      <mesh position={[-0.4, 1.8, -0.3]} rotation={[0.15, 0, -0.2]}>
        <cylinderGeometry args={[0.04, 0.05, 3.8, 12]} />
        <meshStandardMaterial color="#334155" metalness={0.7} roughness={0.3} />
      </mesh>
      <mesh position={[0.4, 1.8, -0.3]} rotation={[0.15, 0, 0.2]}>
        <cylinderGeometry args={[0.04, 0.05, 3.8, 12]} />
        <meshStandardMaterial color="#334155" metalness={0.7} roughness={0.3} />
      </mesh>
      <mesh position={[0, 1.8, 0.4]} rotation={[-0.22, 0, 0]}>
        <cylinderGeometry args={[0.04, 0.05, 3.8, 12]} />
        <meshStandardMaterial color="#334155" metalness={0.7} roughness={0.3} />
      </mesh>

      {/* Telescopic Central Aluminium Mast */}
      <mesh position={[0, 2.7, 0]}>
        <cylinderGeometry args={[0.08, 0.1, 5.4, 16]} />
        <meshStandardMaterial color="#64748b" metalness={0.8} roughness={0.2} />
      </mesh>

      {/* Pan-Tilt Head Assembly */}
      <group position={[0, 5.3, 0]} rotation={[-0.45, 0.4, 0]}>
        {/* Projector Chassis */}
        <mesh castShadow position={[0, 0, 0]}>
          <boxGeometry args={[0.75, 0.4, 0.95]} />
          <meshStandardMaterial color="#0b1320" metalness={0.85} roughness={0.25} />
        </mesh>

        {/* Warning Accent Trim */}
        <mesh position={[0, 0.205, 0]}>
          <boxGeometry args={[0.72, 0.02, 0.9]} />
          <meshStandardMaterial color="#f59e0b" metalness={0.5} roughness={0.3} />
        </mesh>

        {/* Dual High-Throw Laser Lenses */}
        <mesh position={[-0.18, 0, 0.48]} rotation={[Math.PI / 2, 0, 0]}>
          <cylinderGeometry args={[0.13, 0.13, 0.06, 24]} />
          <meshStandardMaterial color="#00f0ff" emissive="#00f0ff" emissiveIntensity={isNight ? 4 : 1.5} roughness={0.1} />
        </mesh>
        <mesh position={[0.18, 0, 0.48]} rotation={[Math.PI / 2, 0, 0]}>
          <cylinderGeometry args={[0.13, 0.13, 0.06, 24]} />
          <meshStandardMaterial color="#fae8a4" emissive="#fae8a4" emissiveIntensity={isNight ? 3 : 1.2} roughness={0.1} />
        </mesh>

        {/* Status Screen */}
        <mesh position={[0.38, 0, 0]} rotation={[0, Math.PI / 2, 0]}>
          <planeGeometry args={[0.4, 0.2]} />
          <meshBasicMaterial color="#0284c7" />
        </mesh>

        {/* Volumetric Laser Projector Beam Cone */}
        {laserActive && (
          <group position={[0, 0, 0.6]}>
            <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 7]}>
              <coneGeometry args={[8.5, 14, 32, 1, true]} />
              <meshBasicMaterial
                color={isNight ? '#00f0ff' : '#fae8a4'}
                transparent
                opacity={isNight ? 0.28 : 0.14}
                depthWrite={false}
                blending={THREE.AdditiveBlending}
                side={THREE.DoubleSide}
              />
            </mesh>

            {/* Core Spotlight Beam */}
            <spotLight
              position={[0, 0, 0]}
              target-position={target}
              angle={0.65}
              penumbra={0.7}
              intensity={isNight ? 260 : 90}
              color="#00f0ff"
              distance={40}
              castShadow
            />
          </group>
        )}
      </group>
    </group>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// 3D REAL LAND PLOT & OUTDOOR LASER PROJECTION ENGINE
// ─────────────────────────────────────────────────────────────────────────────

export function LandPlot3DProjectorScene({
  rooms,
  furniture,
  selectedRoomId,
  selectedFurnitureId,
  onSelectRoom,
  onSelectFurniture,
  plotConfig,
  building,
  unit,
  wallCutHeight = 3.0,
  uploadedBlueprint,
  showBlueprintUnderlay = true,
  blueprintOpacity = 0.85,
  showFurniture = true,
  laserActive = true,
  isNightProjector = false,
  showSetbacks = true
}) {
  const plotW = plotConfig?.width || 12.19;
  const plotD = plotConfig?.depth || 18.29;
  const frontSetback = plotConfig?.frontSetback || 4.5;
  const rearSetback = plotConfig?.rearSetback || 3.0;
  const sideSetback = plotConfig?.sideSetback || 1.5;

  return (
    <group position={[0, 0, 0]}>
      {/* 1. Surrounding Land Ground Environment */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.05, 0]} receiveShadow>
        <planeGeometry args={[85, 85]} />
        <meshStandardMaterial
          color={isNightProjector ? '#050b12' : '#1b2e18'}
          roughness={0.9}
          metalness={0.1}
        />
      </mesh>

      {/* 2. Frontage Access Road with Asphalt & Curbs */}
      <group position={[0, 0, plotD / 2 + 5]}>
        {/* Road Surface */}
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.035, 0]} receiveShadow>
          <planeGeometry args={[plotW + 30, 8.5]} />
          <meshStandardMaterial color="#111827" roughness={0.7} metalness={0.2} />
        </mesh>
        {/* White Center Dashed Road Divider */}
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.032, 0]}>
          <planeGeometry args={[plotW + 30, 0.18]} />
          <meshBasicMaterial color="#f8fafc" transparent opacity={0.65} />
        </mesh>
        {/* Walkway Curbstone */}
        <mesh position={[0, 0.05, -4.5]} castShadow receiveShadow>
          <boxGeometry args={[plotW + 24, 0.16, 0.6]} />
          <meshStandardMaterial color="#475569" roughness={0.7} />
        </mesh>
      </group>

      {/* 3. The Client's Actual Demarcated Land Plot (Lawn / Soil) */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.015, 0]} receiveShadow>
        <planeGeometry args={[plotW, plotD]} />
        <meshStandardMaterial
          color={isNightProjector ? '#0a1a0f' : '#284620'}
          roughness={0.65}
          metalness={0.1}
        />
      </mesh>

      {/* Glowing Gold Plot Boundary Ring */}
      <lineSegments position={[0, 0.02, 0]}>
        <edgesGeometry args={[new THREE.BoxGeometry(plotW, 0.04, plotD)]} />
        <lineBasicMaterial color="#fae8a4" linewidth={3} />
      </lineSegments>

      {/* 4. Four Corner Boundary Survey Stones with Vastu Directions */}
      {[
        { x: -plotW / 2, z: -plotD / 2, label: 'NW · Vayu (Air)' },
        { x: plotW / 2, z: -plotD / 2, label: 'NE · Ishaan (Divine/Water)' },
        { x: -plotW / 2, z: plotD / 2, label: 'SW · Niruthi (Earth/Stability)' },
        { x: plotW / 2, z: plotD / 2, label: 'SE · Agni (Fire/Energy)' },
      ].map((pt, i) => (
        <group key={i} position={[pt.x, 0, pt.z]}>
          <mesh position={[0, 0.45, 0]} castShadow>
            <boxGeometry args={[0.32, 0.9, 0.32]} />
            <meshStandardMaterial color="#e2e8f0" roughness={0.4} />
          </mesh>
          <mesh position={[0, 0.92, 0]}>
            <cylinderGeometry args={[0.07, 0.07, 0.04, 16]} />
            <meshStandardMaterial color="#fae8a4" metalness={0.8} roughness={0.2} />
          </mesh>
          <Text
            position={[0, 1.25, 0]}
            fontSize={0.28}
            color="#fae8a4"
            anchorX="center"
            anchorY="bottom"
          >
            {pt.label}
          </Text>
        </group>
      ))}

      {/* 5. Compound Perimeter Wall on 3 Sides */}
      {/* Rear Wall */}
      <mesh position={[0, 0.8, -plotD / 2]} castShadow receiveShadow>
        <boxGeometry args={[plotW, 1.6, 0.22]} />
        <meshStandardMaterial color="#334155" roughness={0.7} />
      </mesh>
      {/* West Wall */}
      <mesh position={[-plotW / 2, 0.8, 0]} castShadow receiveShadow>
        <boxGeometry args={[0.22, 1.6, plotD]} />
        <meshStandardMaterial color="#334155" roughness={0.7} />
      </mesh>
      {/* East Wall */}
      <mesh position={[plotW / 2, 0.8, 0]} castShadow receiveShadow>
        <boxGeometry args={[0.22, 1.6, plotD]} />
        <meshStandardMaterial color="#334155" roughness={0.7} />
      </mesh>

      {/* Front Boundary Sections with Driveway Opening */}
      <mesh position={[-plotW / 4 - 1.2, 0.8, plotD / 2]} castShadow receiveShadow>
        <boxGeometry args={[Math.max(1, plotW / 2 - 2.4), 1.6, 0.22]} />
        <meshStandardMaterial color="#334155" roughness={0.7} />
      </mesh>
      <mesh position={[plotW / 4 + 1.2, 0.8, plotD / 2]} castShadow receiveShadow>
        <boxGeometry args={[Math.max(1, plotW / 2 - 2.4), 1.6, 0.22]} />
        <meshStandardMaterial color="#334155" roughness={0.7} />
      </mesh>

      {/* Front Entrance Gate Pillars */}
      <mesh position={[-1.2, 1.0, plotD / 2]} castShadow>
        <boxGeometry args={[0.45, 2.0, 0.45]} />
        <meshStandardMaterial color="#1e293b" roughness={0.5} />
      </mesh>
      <mesh position={[1.2, 1.0, plotD / 2]} castShadow>
        <boxGeometry args={[0.45, 2.0, 0.45]} />
        <meshStandardMaterial color="#1e293b" roughness={0.5} />
      </mesh>

      {/* 6. Landscape Trees along Setbacks */}
      <group>
        <mesh position={[-plotW / 2 + 1.2, 1.8, -plotD / 2 + 1.6]} castShadow>
          <sphereGeometry args={[1.1, 16, 16]} />
          <meshStandardMaterial color={isNightProjector ? '#0f3818' : '#15803d'} roughness={0.7} />
        </mesh>
        <mesh position={[-plotW / 2 + 1.2, 0.6, -plotD / 2 + 1.6]} castShadow>
          <cylinderGeometry args={[0.12, 0.16, 1.2, 8]} />
          <meshStandardMaterial color="#5a3d28" roughness={0.9} />
        </mesh>

        <mesh position={[plotW / 2 - 1.2, 1.8, -plotD / 2 + 1.6]} castShadow>
          <sphereGeometry args={[1.2, 16, 16]} />
          <meshStandardMaterial color={isNightProjector ? '#0f3818' : '#166534'} roughness={0.7} />
        </mesh>
        <mesh position={[plotW / 2 - 1.2, 0.6, -plotD / 2 + 1.6]} castShadow>
          <cylinderGeometry args={[0.12, 0.16, 1.2, 8]} />
          <meshStandardMaterial color="#5a3d28" roughness={0.9} />
        </mesh>
      </group>

      {/* 7. Legal Setback Visualizer Guidelines */}
      {showSetbacks && (
        <group position={[0, 0.025, 0]}>
          {/* Front Setback Line */}
          <mesh position={[0, 0, plotD / 2 - frontSetback]}>
            <planeGeometry args={[plotW - 0.2, 0.04]} />
            <meshBasicMaterial color="#38bdf8" />
          </mesh>
          <Text
            position={[0, 0.05, plotD / 2 - frontSetback + 0.35]}
            rotation={[-Math.PI / 2, 0, 0]}
            fontSize={0.32}
            color="#38bdf8"
            anchorX="center"
          >
            {`Front Setback: ${formatDim(frontSetback, unit)}`}
          </Text>

          {/* Rear Setback Line */}
          <mesh position={[0, 0, -plotD / 2 + rearSetback]}>
            <planeGeometry args={[plotW - 0.2, 0.04]} />
            <meshBasicMaterial color="#38bdf8" />
          </mesh>
          <Text
            position={[0, 0.05, -plotD / 2 + rearSetback - 0.35]}
            rotation={[-Math.PI / 2, 0, 0]}
            fontSize={0.32}
            color="#38bdf8"
            anchorX="center"
          >
            {`Rear Setback: ${formatDim(rearSetback, unit)}`}
          </Text>
        </group>
      )}

      {/* 8. The Industrial 3D Laser Projector Rig */}
      <Projector3DRig
        position={[-plotW / 2 - 2.0, 0, plotD / 2 + 3.0]}
        target={[0, 1.2, 0]}
        laserActive={laserActive}
        isNight={isNightProjector}
      />

      {/* 9. Projected Blueprint Floor Texture on Land */}
      {uploadedBlueprint && showBlueprintUnderlay && (
        <Blueprint3DPlane
          blueprint={uploadedBlueprint}
          elevation={0.015}
          opacity={isNightProjector ? 0.95 : blueprintOpacity}
        />
      )}

      {/* 10. The 3D Extruded Building Rising on the Land */}
      <group position={[0, 0.02, 0]}>
        {rooms.map((room) => (
          <Parametric3DRoom
            key={room.id}
            room={room}
            isSelected={selectedRoomId === room.id}
            onSelect={onSelectRoom}
            viewMode="3d_axo"
            unit={unit}
            wallCutHeight={wallCutHeight}
            elevation={0}
          />
        ))}

        {showFurniture && furniture.map((item) => (
          <Movable3DFurniture
            key={item.id}
            item={item}
            isSelected={selectedFurnitureId === item.id}
            onSelect={onSelectFurniture}
            elevation={0}
          />
        ))}
      </group>
    </group>
  );
}

export function CameraController({ viewMode, controlsRef, cameraTargetPos }) {
  const { camera } = useThree();

  useEffect(() => {
    if (!controlsRef.current) return;

    if (viewMode === '3d_land_projection') {
      camera.position.set(24, 20, 26);
      controlsRef.current.target.set(0, 1.5, 0);
      controlsRef.current.enableRotate = true;
      controlsRef.current.maxPolarAngle = Math.PI / 2 - 0.04;
      controlsRef.current.update();
    } else if (viewMode === '3d_axo' || viewMode === 'all_floors') {
      camera.position.set(22, 20, 22);
      controlsRef.current.target.set(0, 4, 0);
      controlsRef.current.enableRotate = true;
      controlsRef.current.maxPolarAngle = Math.PI / 2 - 0.05;
      controlsRef.current.update();
    } else if (viewMode === 'projection_1to1') {
      camera.position.set(0, 18, 0.001);
      controlsRef.current.target.set(0, 0, 0);
      controlsRef.current.enableRotate = true;
      controlsRef.current.update();
    } else if (viewMode === 'fps_walk') {
      camera.position.set(0, 1.65, 8);
      controlsRef.current.target.set(0, 1.65, 0);
      controlsRef.current.enableRotate = true;
      controlsRef.current.update();
    }
  }, [viewMode, camera, controlsRef]);

  useFrame(() => {
    if (viewMode === 'fps_walk' && cameraTargetPos) {
      camera.position.x = THREE.MathUtils.lerp(camera.position.x, cameraTargetPos.x, 0.1);
      camera.position.z = THREE.MathUtils.lerp(camera.position.z, cameraTargetPos.z, 0.1);
      camera.position.y = 1.65;
    }
  });

  return (
    <OrbitControls
      ref={controlsRef}
      makeDefault
      enableDamping
      dampingFactor={0.05}
      minDistance={2}
      maxDistance={80}
    />
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// ─────────────────────────────────────────────────────────────────────────────
// SAFE ERROR BOUNDARIES
// ─────────────────────────────────────────────────────────────────────────────

class CanvasErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }
  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }
  componentDidCatch(error, errorInfo) {
    console.warn('[ProjectionStudio] Canvas 3D warning:', error, errorInfo);
  }
  render() {
    if (this.state.hasError) {
      return (
        <div className="ps-webgl-fallback">
          <AlertTriangle size={36} color="#f59e0b" />
          <h3 style={{ margin: '8px 0 4px', fontSize: '1.05rem', fontWeight: 600 }}>3D Graphics Notice</h3>
          <p style={{ margin: '0 0 12px', fontSize: '0.85rem', color: '#94a3b8', maxWidth: '380px' }}>
            3D rendering encountered an issue or WebGL is disabled. You can switch to 2D CAD Blueprint mode or retry.
          </p>
          <button
            type="button"
            className="ps-btn-gold"
            onClick={() => this.setState({ hasError: false })}
          >
            Retry 3D Engine
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// INTERACTIVE ONBOARDING GUIDE STEPS
// ─────────────────────────────────────────────────────────────────────────────

export const STUDIO_GUIDE_STEPS = [
  {
    num: 1,
    title: 'Instant 3D Presets & Blueprint Upload',
    desc: 'Click "Templates" to load luxury 1BHK, Villa, or Penthouse instantly, or click "Upload New" to convert your CAD/PDF/JPG plan into interactive 3D.',
  },
  {
    num: 2,
    title: 'Precision 2D CAD Drafting',
    desc: 'In 2D CAD view, use "Draw Wall" (auto-snaps at 90° & auto-closes room loops), "+ Door", and "+ Window" or drag architectural furniture freely.',
  },
  {
    num: 3,
    title: '1:1 Life-Size Scale & VR Experience',
    desc: 'Switch to "1:1 Stage" for warehouse laser projection, or "1:1 Walk" & "VR Walk" to physically experience proportions at 1.65m human eye level.',
  },
  {
    num: 4,
    title: 'Civil BOQ Takeoff & Vastu Compliance',
    desc: 'Real-time structural clearance audits, turnkey material cost estimation (BOQ), and 9-zone Vastu Purusha orientation scoring.',
  }
];

// MAIN PROJECTION STUDIO COMPONENT
// ─────────────────────────────────────────────────────────────────────────────

export default function ProjectionStudio() {
  const [selectedBuildingKey, setSelectedBuildingKey] = useState('royal_estate_30x75');
  const building = BUILDINGS_CATALOG[selectedBuildingKey] || BUILDINGS_CATALOG.royal_estate_30x75;

  const [activeFloorKey, setActiveFloorKey] = useState(building.defaultFloor || 'ground');
  const isAllFloors = activeFloorKey === 'all_floors';

  // Current Floor Data
  const initialFloor = building.floors[activeFloorKey] || building.floors.ground || Object.values(building.floors)[0];
  const [rooms, setRooms] = useState(initialFloor.rooms);
  const [furniture, setFurniture] = useState(initialFloor.furniture || []);

  // Uploaded Blueprint State
  const [uploadedBlueprint, setUploadedBlueprint] = useState({
    imageUrl: initialFloor.blueprintImage || '/blueprints/ground_floor_plan.jpg',
    name: `${initialFloor.name} (${building.name})`,
    width: building.plotWidth || 9.12,
    depth: building.plotDepth || 22.91
  });
  const [showBlueprintUnderlay, setShowBlueprintUnderlay] = useState(true);
  const [blueprintOpacity, setBlueprintOpacity] = useState(0.85);
  const [extrudeBlueprintWalls, setExtrudeBlueprintWalls] = useState(true);
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [uploadWidth, setUploadWidth] = useState(9.12);
  const [uploadDepth, setUploadDepth] = useState(22.91);
  const [isWelcomeModalOpen, setIsWelcomeModalOpen] = useState(() => !localStorage.getItem('wtp_seen_guide_v3'));
  const [isPresetsModalOpen, setIsPresetsModalOpen] = useState(false);

  // View & Tool States ('2d_blueprint' | '3d_axo' | 'projection_1to1' | 'fps_walk' | '3d_land_projection')
  const [viewMode, setViewMode] = useState('2d_blueprint');
  const [unit, setUnit] = useState('imperial');
  const [activeTool, setActiveTool] = useState('select');
  const [measurePoints, setMeasurePoints] = useState({ p1: null, p2: null });

  // 3D Real Land Plot Projector Configuration
  const [selectedPlotConfig, setSelectedPlotConfig] = useState(LAND_PLOT_PRESETS[1]); // 30'x60'
  const [isNightProjector, setIsNightProjector] = useState(false);
  const [showSetbacks, setShowSetbacks] = useState(true);
  const [isLandLaserActive, setIsLandLaserActive] = useState(true);

  // 3D Visual Customizations
  const [wallCutMode, setWallCutMode] = useState('full');
  const [explodeOffset, setExplodeOffset] = useState(1.8);
  const [timeOfDay, setTimeOfDay] = useState(13);

  // Selections
  const [selectedRoomId, setSelectedRoomId] = useState(null);
  const [selectedFurnitureId, setSelectedFurnitureId] = useState(null);
  const [selectedWallId, setSelectedWallId] = useState(null);

  // Layers Visibility
  const [showDimensions, setShowDimensions] = useState(true);
  const [showFurniture, setShowFurniture] = useState(true);
  const [showGrid, setShowGrid] = useState(true);

  // Modals & Drawers
  const [isGuideOpen, setIsGuideOpen] = useState(true);
  const [guideStep, setGuideStep] = useState(0);
  const [isVastuModalOpen, setIsVastuModalOpen] = useState(false);
  const [isClearanceModalOpen, setIsClearanceModalOpen] = useState(false);
  const [isBoqModalOpen, setIsBoqModalOpen] = useState(false);
  const [isHelpOpen, setIsHelpOpen] = useState(false);
  const [isLeftDrawerOpen, setIsLeftDrawerOpen] = useState(false);
  const [isRightDrawerOpen, setIsRightDrawerOpen] = useState(false);
  const [isExportMenuOpen, setIsExportMenuOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState(null);

  // FPS Walkthrough Position
  const [walkPos, setWalkPos] = useState({ x: 0, z: 8 });

  // Architectural 3D Modeling & CAD Elements (FloorPlan-3D Engine)
  const [columns, setColumns] = useState([]);
  const [customWalls, setCustomWalls] = useState([]);
  const [renderStyle, setRenderStyle] = useState('realistic'); // 'realistic' | 'cyan_laser' | 'clay' | 'wireframe'
  const [ceilingMode, setCeilingMode] = useState('cove_led'); // 'cove_led' | 'flat' | 'none'
  const [doorStyle, setDoorStyle] = useState('single');
  const [windowStyle, setWindowStyle] = useState('casement');
  const [columnShape, setColumnShape] = useState('square');
  const [selectedOpeningId, setSelectedOpeningId] = useState(null);
  const [selectedColumnId, setSelectedColumnId] = useState(null);
  const [furnitureCategory, setFurnitureCategory] = useState('All');
  const [furnitureSearch, setFurnitureSearch] = useState('');
  const sceneRef = useRef(null);

  // Undo / Redo Stack
  const [history, setHistory] = useState([{ rooms: initialFloor.rooms, furniture: initialFloor.furniture || [] }]);
  const [historyIndex, setHistoryIndex] = useState(0);

  const controlsRef = useRef();
  const fileInputRef = useRef();

  const showToast = (msg, icon = '✦') => {
    setToastMessage({ msg, icon });
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Sync rooms and furniture when floor changes
  const handleFloorChange = (floorKey) => {
    setActiveFloorKey(floorKey);
    setSelectedRoomId(null);
    setSelectedFurnitureId(null);
    setSelectedColumnId(null);
    setSelectedOpeningId(null);
    setColumns([]);
    setCustomWalls([]);
    setMeasurePoints({ p1: null, p2: null });

    if (floorKey === 'all_floors') {
      setViewMode('3d_axo');
      showToast('Switched to 3D Multi-Level Building Stack', '🏢');
    } else {
      const fl = building.floors[floorKey];
      if (fl) {
        setRooms(fl.rooms);
        setFurniture(fl.furniture || []);
        setHistory([{ rooms: fl.rooms, furniture: fl.furniture || [] }]);
        setHistoryIndex(0);

        if (fl.blueprintImage) {
          setUploadedBlueprint({
            imageUrl: fl.blueprintImage,
            name: `${fl.name} (${building.name})`,
            width: building.plotWidth || 9.12,
            depth: building.plotDepth || 22.91
          });
        }

        showToast(`Loaded ${fl.name} (${fl.subtitle})`, '📐');
      }
    }
  };

  // Sync building preset change
  const handleBuildingChange = (bKey) => {
    setSelectedBuildingKey(bKey);
    const b = BUILDINGS_CATALOG[bKey];
    if (b) {
      const defKey = b.defaultFloor || Object.keys(b.floors)[0];
      setActiveFloorKey(defKey);
      const fl = b.floors[defKey];
      setRooms(fl.rooms);
      setFurniture(fl.furniture || []);
      setHistory([{ rooms: fl.rooms, furniture: fl.furniture || [] }]);
      setHistoryIndex(0);
      setSelectedRoomId(null);
      setSelectedFurnitureId(null);

      if (fl.blueprintImage) {
        setUploadedBlueprint({
          imageUrl: fl.blueprintImage,
          name: `${fl.name} (${b.name})`,
          width: b.plotWidth || 9.12,
          depth: b.plotDepth || 22.91
        });
      }

      showToast(`Loaded ${b.name}`, '🏛️');
    }
  };

  const selectedWall = useMemo(() => {
    return customWalls.find((w) => w.id === selectedWallId) || null;
  }, [customWalls, selectedWallId]);

  const handleLoadPreset = (preset) => {
    setRooms(preset.rooms.map((r, i) => ({ ...r, id: `r_${Date.now()}_${i}` })));
    setFurniture(preset.furniture.map((f, i) => ({ ...f, id: `f_${Date.now()}_${i}` })));
    setCustomWalls([]);
    setColumns([]);
    setSelectedRoomId(null);
    setSelectedFurnitureId(null);
    setSelectedWallId(null);
    setSelectedOpeningId(null);
    setSelectedColumnId(null);
    setIsPresetsModalOpen(false);
    setIsWelcomeModalOpen(false);
    pushHistory(preset.rooms, preset.furniture);
    showToast(`Loaded ${preset.name} (${preset.areaSqFt ? preset.areaSqFt + ' sq.ft' : 'Canvas'})`, '🏛️');
  };

  // Handle uploaded file (Apple RoomPlan LiDAR JSON, OpenPlan3D JSON, DXF, or Image)
  const processUploadedFile = (file, customWidth = uploadWidth, customDepth = uploadDepth, autoLaunchVR = false) => {
    if (!file) return;

    if (file.name.endsWith('.json')) {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const imported = parseUniversalFloorPlanJSON(e.target.result);
          if (imported.rooms && imported.rooms.length > 0) setRooms(imported.rooms);
          if (imported.customWalls && imported.customWalls.length > 0) setCustomWalls(imported.customWalls);
          if (imported.furniture && imported.furniture.length > 0) setFurniture(imported.furniture);
          if (imported.columns && imported.columns.length > 0) setColumns(imported.columns);
          pushHistory(imported.rooms || rooms, imported.furniture || furniture);
          showToast(`Successfully imported spatial layout from ${file.name}`, '🚀');
          setIsUploadModalOpen(false);
          setViewMode('3d_axo');
        } catch (err) {
          showToast('Failed to parse spatial JSON: ' + err.message, '⚠️');
        }
      };
      reader.readAsText(file);
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const dataUrl = e.target.result;
      setUploadedBlueprint({
        imageUrl: dataUrl,
        name: file.name.replace(/\.[^/.]+$/, ''),
        width: Number(customWidth) || 9.12,
        depth: Number(customDepth) || 22.91
      });
      setShowBlueprintUnderlay(true);
      setExtrudeBlueprintWalls(true);
      setIsUploadModalOpen(false);
      setViewMode(autoLaunchVR ? 'vr_walk' : '3d_axo');
      showToast(autoLaunchVR ? `🎉 Blueprint "${file.name}" loaded in 1:1 VR!` : `🎉 Blueprint "${file.name}" uploaded! Extruded into 3D projection.`, '🚀');
    };
    reader.readAsDataURL(file);
  };

  // Push history
  const pushHistory = useCallback((newRooms, newFurniture) => {
    setHistory((prev) => {
      const sliced = prev.slice(0, historyIndex + 1);
      return [...sliced, { rooms: newRooms, furniture: newFurniture }].slice(-25);
    });
    setHistoryIndex((i) => Math.min(i + 1, 24));
  }, [historyIndex]);

  const handleUndo = () => {
    if (historyIndex > 0) {
      const prev = history[historyIndex - 1];
      setRooms(prev.rooms);
      setFurniture(prev.furniture);
      setHistoryIndex((i) => i - 1);
      showToast('Undo previous action', '↺');
    }
  };

  const handleRedo = () => {
    if (historyIndex < history.length - 1) {
      const next = history[historyIndex + 1];
      setRooms(next.rooms);
      setFurniture(next.furniture);
      setHistoryIndex((i) => i + 1);
      showToast('Redo action', '↻');
    }
  };

  // Interactive Moving, Rotating, Duplicating and Deletion Handlers
  const handleNudgeSelected = (dx, dz) => {
    if (selectedFurnitureId) {
      const updated = furniture.map((f) =>
        f.id === selectedFurnitureId
          ? { ...f, x: Math.round((f.x + dx) * 100) / 100, z: Math.round((f.z + dz) * 100) / 100 }
          : f
      );
      setFurniture(updated);
      pushHistory(rooms, updated);
      showToast('Moved furniture item', '↔️');
    } else if (selectedRoomId) {
      const updated = rooms.map((r) =>
        r.id === selectedRoomId
          ? { ...r, x: Math.round((r.x + dx) * 100) / 100, z: Math.round((r.z + dz) * 100) / 100 }
          : r
      );
      setRooms(updated);
      pushHistory(updated, furniture);
      showToast('Moved room walls', '🧱');
    }
  };

  const handleRotateSelected = (deltaAngle = 45) => {
    if (selectedFurnitureId) {
      const updated = furniture.map((f) =>
        f.id === selectedFurnitureId ? { ...f, rot: ((f.rot || 0) + deltaAngle) % 360 } : f
      );
      setFurniture(updated);
      pushHistory(rooms, updated);
      showToast('Rotated furniture item', '↻');
    }
  };

  const handleDuplicateSelected = () => {
    if (selectedFurnitureId) {
      const target = furniture.find((f) => f.id === selectedFurnitureId);
      if (target) {
        const cloned = { ...target, id: `f_${Date.now()}`, x: target.x + 0.5, z: target.z + 0.5 };
        const updated = [...furniture, cloned];
        setFurniture(updated);
        setSelectedFurnitureId(cloned.id);
        pushHistory(rooms, updated);
        showToast(`Duplicated ${target.name}`, '📋');
      }
    } else if (selectedRoomId) {
      const target = rooms.find((r) => r.id === selectedRoomId);
      if (target) {
        const cloned = { ...target, id: `r_${Date.now()}`, name: `${target.name} (Copy)`, x: target.x + 1.0, z: target.z + 1.0 };
        const updated = [...rooms, cloned];
        setRooms(updated);
        setSelectedRoomId(cloned.id);
        pushHistory(updated, furniture);
        showToast(`Duplicated ${target.name}`, '📋');
      }
    }
  };

  const handleDeleteSelected = () => {
    if (selectedFurnitureId) {
      const updated = furniture.filter((f) => f.id !== selectedFurnitureId);
      setFurniture(updated);
      setSelectedFurnitureId(null);
      pushHistory(rooms, updated);
      showToast('Deleted furniture item', '🗑️');
    } else if (selectedRoomId) {
      const updated = rooms.filter((r) => r.id !== selectedRoomId);
      setRooms(updated);
      setSelectedRoomId(null);
      pushHistory(updated, furniture);
      showToast('Deleted room wall', '🗑️');
    } else if (selectedWallId) {
      const updated = customWalls.filter((w) => w.id !== selectedWallId);
      setCustomWalls(updated);
      setSelectedWallId(null);
      showToast('Deleted custom wall segment', '🗑️');
    }
  };

  // Keyboard Shortcuts for Moving, Rotating, Deleting, Undo/Redo & Tool Switches
  useEffect(() => {
    const handleKeyDown = (e) => {
      // Don't intercept when typing in text fields
      if (['INPUT', 'SELECT', 'TEXTAREA'].includes(e.target.tagName)) return;

      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') {
        e.preventDefault();
        if (e.shiftKey) handleRedo();
        else handleUndo();
        return;
      }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'y') {
        e.preventDefault();
        handleRedo();
        return;
      }

      const keyLower = e.key.toLowerCase();

      // Quick Tool Hotkeys (openPlan3D standards)
      if (keyLower === 'v') {
        setActiveTool('select');
        showToast('Select & Transform tool active (V)', '👆');
        return;
      }
      if (keyLower === 'w') {
        setActiveTool('draw_wall');
        showToast('Draw Wall active (W): click corners, close loop', '🧱');
        return;
      }
      if (keyLower === 'd') {
        setActiveTool('add_door');
        showToast('Add Door active (D): click wall edge', '🚪');
        return;
      }
      if (e.code === 'Space') {
        e.preventDefault();
        setViewMode((m) => (m === '2d_blueprint' ? '3d_axo' : '2d_blueprint'));
        showToast('Toggled 2D / 3D View (Space)', '🔄');
        return;
      }
      if (e.key === '1') {
        setViewMode('2d_blueprint');
        return;
      }
      if (e.key === '2') {
        setViewMode('3d_axo');
        return;
      }
      if (e.key === '3') {
        setViewMode('split_view');
        return;
      }
      if (e.key === '4') {
        setViewMode('fps_walk');
        return;
      }

      const nudgeStep = e.shiftKey ? 0.5 : 0.1;
      if (e.key === 'ArrowLeft') {
        e.preventDefault();
        handleNudgeSelected(-nudgeStep, 0);
      } else if (e.key === 'ArrowRight') {
        e.preventDefault();
        handleNudgeSelected(nudgeStep, 0);
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        handleNudgeSelected(0, -nudgeStep);
      } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        handleNudgeSelected(0, nudgeStep);
      } else if (keyLower === 'r') {
        e.preventDefault();
        handleRotateSelected(45);
      } else if (e.key === 'Delete' || e.key === 'Backspace') {
        e.preventDefault();
        handleDeleteSelected();
      } else if (e.key === 'Escape') {
        setSelectedRoomId(null);
        setSelectedFurnitureId(null);
        setSelectedWallId(null);
        setSelectedColumnId(null);
        setActiveTool('select');
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedFurnitureId, selectedRoomId, selectedWallId, furniture, rooms, customWalls, historyIndex, history]);

  // Measurement tape clicks
  const handleMeasureClick = (pt) => {
    if (!measurePoints.p1) {
      setMeasurePoints({ p1: pt, p2: null });
      showToast('Point 1 marked. Click Point 2 to measure distance.', '📏');
    } else if (!measurePoints.p2) {
      setMeasurePoints((prev) => ({ ...prev, p2: pt }));
      const dist = Math.hypot(pt.x - measurePoints.p1.x, pt.z - measurePoints.p1.z);
      showToast(`Distance measured: ${unit === 'imperial' ? toFeetInches(dist) : dist.toFixed(2) + 'm'}`, '📐');
    } else {
      setMeasurePoints({ p1: pt, p2: null });
    }
  };

  // Selected item references
  const selectedRoom = rooms.find((r) => r.id === selectedRoomId);
  const selectedFurniture = furniture.find((f) => f.id === selectedFurnitureId);

  // Audits & BOQ
  const vastuResult = useMemo(() => runVastuAudit(rooms, initialFloor.name), [rooms, initialFloor.name]);
  const clearanceAlerts = useMemo(() => runClearanceAudit(rooms, furniture), [rooms, furniture]);
  const boqData = useMemo(() => calculateBOQ(building, activeFloorKey, rooms, furniture), [building, activeFloorKey, rooms, furniture]);

  return (
    <div className="ps-root">
      {/* ── TOP LUXURY HEADER ────────────────────────────────────────── */}
      <header className="ps-header">
        <div className="ps-header-left">
          <Link to="/" className="ps-exit-btn" title="Exit Studio to Website">
            <ArrowLeft size={16} />
            <span>Walk The Plan</span>
          </Link>
          <div className="ps-brand-badge">
            <span className="ps-brand-title">1:1 PROJECTION STUDIO</span>
            <span className="ps-brand-sub">CAD & Life-Size Holographic Visualizer</span>
          </div>
        </div>

        {/* Center: Floor Switcher Segmented Tabs (Desktop) + Dropdown (Compact/Mobile) */}
        <div className="ps-header-center">
          {building.isMultiLevel && (
            <>
              {/* Full tabs for large desktops */}
              <div className="ps-floor-tabs desktop-only">
                <button
                  type="button"
                  className={`ps-floor-tab ${activeFloorKey === 'stilt' ? 'active' : ''}`}
                  onClick={() => handleFloorChange('stilt')}
                >
                  <Car size={13} />
                  <span>Stilt</span>
                </button>
                <button
                  type="button"
                  className={`ps-floor-tab ${activeFloorKey === 'ground' ? 'active' : ''}`}
                  onClick={() => handleFloorChange('ground')}
                >
                  <Building size={13} />
                  <span>Ground</span>
                </button>
                <button
                  type="button"
                  className={`ps-floor-tab ${activeFloorKey === 'first' ? 'active' : ''}`}
                  onClick={() => handleFloorChange('first')}
                >
                  <Layers2 size={13} />
                  <span>First</span>
                </button>
                <button
                  type="button"
                  className={`ps-floor-tab ${activeFloorKey === 'terrace' ? 'active' : ''}`}
                  onClick={() => handleFloorChange('terrace')}
                >
                  <Sun size={13} />
                  <span>Terrace</span>
                </button>
                <button
                  type="button"
                  className={`ps-floor-tab gold ${activeFloorKey === 'all_floors' ? 'active' : ''}`}
                  onClick={() => handleFloorChange('all_floors')}
                  title="3D Exploded Multi-Floor Stack"
                >
                  <BoxIcon size={13} />
                  <span>All Floors (3D)</span>
                </button>
              </div>

              {/* Compact dropdown for laptops & tablets (< 1200px) */}
              <div className="ps-floor-select-wrap mobile-only">
                <Building size={13} color="#fae8a4" />
                <select
                  value={activeFloorKey}
                  onChange={(e) => handleFloorChange(e.target.value)}
                  className="ps-floor-dropdown"
                  title="Select Active Floor Level"
                >
                  <option value="stilt">🚗 Stilt Floor</option>
                  <option value="ground">🏢 Ground Floor</option>
                  <option value="first">📑 First Floor</option>
                  <option value="terrace">☀️ Terrace Deck</option>
                  <option value="all_floors">🏛️ All Floors (3D)</option>
                </select>
              </div>
            </>
          )}
        </div>

        {/* Right: Audits, BOQ, Undo/Redo & Quick Actions */}
        <div className="ps-header-right">
          {/* Architectural 1-Click Presets Pill */}
          <button
            type="button"
            onClick={() => setIsPresetsModalOpen(true)}
            className="ps-audit-pill presets"
            title="Load Curated 1-Click Architectural 3D Presets"
          >
            <Sparkles size={13} color="#fae8a4" />
            <span>Templates</span>
          </button>

          {/* Unit Switcher */}
          <button
            type="button"
            onClick={() => setUnit((u) => (u === 'imperial' ? 'metric' : 'imperial'))}
            className="ps-unit-pill"
            title="Toggle Feet-Inches vs Meters"
          >
            <span>{unit === 'imperial' ? "FT-IN" : "M"}</span>
          </button>

          {/* Vastu Audit Pill (Large screens) */}
          <button
            type="button"
            onClick={() => setIsVastuModalOpen(true)}
            className="ps-audit-pill vastu desktop-insights-pill"
            title="Open Vastu Purusha Harmony Audit"
          >
            <Sparkle size={13} />
            <span>{vastuResult.score}% Vastu</span>
          </button>

          {/* Clearance Audit Pill (Large screens) */}
          <button
            type="button"
            onClick={() => setIsClearanceModalOpen(true)}
            className={`ps-audit-pill clearance desktop-insights-pill ${clearanceAlerts.length > 0 ? 'warn' : ''}`}
            title="Open Clearance & Ergonomics Audit"
          >
            <ShieldCheck size={13} />
            <span>{clearanceAlerts.length === 0 ? '✓ Clear' : `${clearanceAlerts.length} Alerts`}</span>
          </button>

          {/* BOQ Estimator Pill (Large screens) */}
          <button
            type="button"
            onClick={() => setIsBoqModalOpen(true)}
            className="ps-audit-pill boq desktop-insights-pill"
            title="Open Bill of Quantities & Civil Cost Estimator"
          >
            <FileSpreadsheet size={13} />
            <span>BOQ ₹{boqData.costTotalCrores} Cr</span>
          </button>

          {/* Consolidated Insights Badge (Compact / Laptop / Tablet screens) */}
          <button
            type="button"
            onClick={() => setIsBoqModalOpen(true)}
            className="ps-audit-pill boq compact-insights-pill"
            title="Open Civil BOQ Estimator & Audits"
          >
            <FileSpreadsheet size={13} />
            <span>₹{boqData.costTotalCrores} Cr</span>
            <span className="ps-sub-badge">{vastuResult.score}% V</span>
          </button>

          {/* Undo / Redo */}
          <div className="ps-history-group">
            <button
              type="button"
              onClick={handleUndo}
              disabled={historyIndex <= 0}
              className="ps-icon-btn"
              title="Undo (Ctrl+Z)"
              style={{ opacity: historyIndex <= 0 ? 0.35 : 1 }}
            >
              <Undo size={14} />
            </button>
            <button
              type="button"
              onClick={handleRedo}
              disabled={historyIndex >= history.length - 1}
              className="ps-icon-btn"
              title="Redo (Ctrl+Y)"
              style={{ opacity: historyIndex >= history.length - 1 ? 0.35 : 1 }}
            >
              <Redo size={14} />
            </button>
          </div>

          {/* Help & First-Time User Guide */}
          <button
            type="button"
            onClick={() => setIsWelcomeModalOpen(true)}
            className="ps-icon-btn"
            title="Quick Start & Hotkey Guide (?)"
          >
            <HelpCircle size={15} color="#00f0ff" />
          </button>
        </div>
      </header>

      {/* ── SECONDARY TOOLBAR & VIEW MODE SELECTOR ───────────────────── */}
      <div className="ps-subbar">
        {/* Left / Center: Primary View Mode Switcher */}
        <div className="ps-view-pills">
          <button
            type="button"
            onClick={() => {
              setViewMode('2d_blueprint');
              showToast('Switched to 2D CAD Blueprint View (Interactive Move & Resize)', '📐');
            }}
            className={`ps-view-pill ${viewMode === '2d_blueprint' ? 'active' : ''}`}
            title="2D CAD Architectural Blueprint"
          >
            <PenTool size={13} />
            <span>2D CAD</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setViewMode('3d_axo');
              showToast('Switched to 3D Axonometric View', '🏛️');
            }}
            className={`ps-view-pill ${viewMode === '3d_axo' ? 'active' : ''}`}
            title="3D Axonometric Model View"
          >
            <BoxIcon size={13} />
            <span>3D Model</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setViewMode('split_view');
              showToast('Switched to Dual Synchronized View (2D Blueprint + 3D Model)', '🔲');
            }}
            className={`ps-view-pill ${viewMode === 'split_view' ? 'active' : ''}`}
            title="Synchronized Split View (2D CAD + 3D Model)"
          >
            <Layers2 size={13} />
            <span>Split 2D+3D</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setViewMode('projection_1to1');
              showToast('Switched to 1:1 Scale Warehouse Laser Projection Stage', '🔦');
            }}
            className={`ps-view-pill ${viewMode === 'projection_1to1' ? 'active' : ''}`}
            title="1:1 Scale Warehouse Laser Projection"
          >
            <Sparkles size={13} />
            <span>1:1 Stage</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setViewMode('fps_walk');
              showToast('Switched to 1:1 Scale Walkthrough (1.65m Eye Level)', '🚶');
            }}
            className={`ps-view-pill ${viewMode === 'fps_walk' ? 'active' : ''}`}
            title="1:1 Scale Walkthrough at 1.65m Eye Level"
          >
            <Eye size={13} />
            <span>1:1 Walk</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setViewMode('vr_walk');
              showToast('Entering 1:1 Scale Immersive VR Walkthrough', '🥽');
            }}
            className={`ps-view-pill ps-vr-pill ${viewMode === 'vr_walk' ? 'active' : ''}`}
            title="Enter 1:1 Scale VR Walkthrough"
          >
            <Eye size={13} color="#00f0ff" />
            <span>🥽 VR Walk</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setViewMode('3d_land_projection');
              showToast('Switched to 3D Real Land Plot Projector View', '🌳');
            }}
            className={`ps-view-pill ps-land-pill ${viewMode === '3d_land_projection' ? 'active' : ''}`}
            title="Outdoor Real Land Plot Laser Projector"
          >
            <Trees size={13} />
            <span>Land Plot</span>
          </button>
        </div>

        {/* Right: Global Actions (Measure, Snapshot, Export, Elements) */}
        <div className="ps-subbar-right">
          {/* Tape Measure Tool */}
          <button
            type="button"
            onClick={() => {
              if (activeTool === 'measure') {
                setActiveTool('select');
                setMeasurePoints({ p1: null, p2: null });
                showToast('Measurement tape disabled', '✦');
              } else {
                setActiveTool('measure');
                setMeasurePoints({ p1: null, p2: null });
                showToast('Measurement tape active: click 2 points to measure', '📏');
              }
            }}
            className={`ps-pill-btn ${activeTool === 'measure' ? 'active-select' : ''}`}
            title="Interactive Tape Measure Tool"
          >
            <Ruler size={13} />
            <span className="ps-btn-label">Measure</span>
          </button>

          {/* Snapshot (in 3D modes) */}
          {viewMode !== '2d_blueprint' && (
            <button
              type="button"
              onClick={() => {
                const canvas = document.querySelector('.ps-canvas-container canvas');
                if (canvas) {
                  captureCanvasSnapshot(canvas, `${building.name}_${initialFloor.name}`);
                  showToast('Captured high-resolution 3D architectural render!', '📸');
                } else {
                  showToast('No 3D viewport canvas found', '⚠️');
                }
              }}
              className="ps-pill-btn"
              title="Capture High-Res 3D Render Snapshot (PNG)"
            >
              <Camera size={13} color="#00f0ff" />
              <span className="ps-btn-label">Snapshot</span>
            </button>
          )}

          {/* Export CAD Dropdown */}
          <div style={{ position: 'relative' }}>
            <button
              type="button"
              onClick={() => setIsExportMenuOpen((o) => !o)}
              className="ps-pill-btn gold"
              title="Export Professional Architectural Formats"
            >
              <Download size={13} />
              <span className="ps-btn-label">Export CAD</span>
            </button>

            {isExportMenuOpen && (
              <div className="ps-export-dropdown">
                <button
                  type="button"
                  onClick={() => {
                    if (sceneRef.current) {
                      exportSceneToOBJ(sceneRef.current, building.name, initialFloor.name);
                      setIsExportMenuOpen(false);
                      showToast('Exported 3D Model (.OBJ) for AutoCAD / Blender / Revit', '🏛️');
                    } else {
                      showToast('Switch to 3D mode first to export 3D geometry', '⚠️');
                    }
                  }}
                >
                  <BoxIcon size={13} />
                  <span>3D Wavefront Model (.obj)</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    if (sceneRef.current) {
                      exportSceneToGLTF(sceneRef.current, building.name, initialFloor.name);
                      setIsExportMenuOpen(false);
                      showToast('Exported 3D Model (.GLTF) for Web / AR', '🌐');
                    } else {
                      showToast('Switch to 3D mode first to export 3D geometry', '⚠️');
                    }
                  }}
                >
                  <Sparkles size={13} />
                  <span>3D GLTF / GLB Scene (.gltf)</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    exportProjectJSON({
                      buildingName: building.name,
                      plotWidth: uploadedBlueprint?.width || building.plotWidth,
                      plotDepth: uploadedBlueprint?.depth || building.plotDepth,
                      unit,
                      activeFloorKey,
                      rooms,
                      walls: customWalls,
                      columns,
                      furniture,
                      timeOfDay,
                      renderStyle,
                      ceilingMode,
                      wallCutMode
                    }, building.name);
                    setIsExportMenuOpen(false);
                    showToast('Project JSON Saved (FloorPlan-3D Compatible)', '💾');
                  }}
                >
                  <Save size={13} />
                  <span>Full Project Data (.json)</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const canvas = document.querySelector('.ps-canvas-container canvas');
                    if (canvas) {
                      captureCanvasSnapshot(canvas, `${building.name}_${initialFloor.name}`);
                      setIsExportMenuOpen(false);
                      showToast('Downloaded High-Res Render Snapshot', '📸');
                    } else {
                      showToast('3D Canvas not currently loaded', '⚠️');
                    }
                  }}
                >
                  <Camera size={13} />
                  <span>3D Render Snapshot (.png)</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    exportToAutoCAD_DXF(rooms, furniture, building.name, initialFloor.name);
                    setIsExportMenuOpen(false);
                    showToast('Exported Layered AutoCAD DXF', '💾');
                  }}
                >
                  <Download size={13} />
                  <span>AutoCAD DXF (.dxf)</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    exportToTechnicalSVG(rooms, furniture, building.name, initialFloor.name, unit);
                    setIsExportMenuOpen(false);
                    showToast('Exported Architectural Vector Blueprint', '📐');
                  }}
                >
                  <FileDown size={13} />
                  <span>Blueprint Sheet (.svg)</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    downloadFile(
                      JSON.stringify({ building, activeFloor: activeFloorKey, rooms, furniture }, null, 2),
                      `WalkThePlan_${initialFloor.name}_Project.json`,
                      'application/json'
                    );
                    setIsExportMenuOpen(false);
                    showToast('Project JSON Saved', '💾');
                  }}
                >
                  <Save size={13} />
                  <span>Project JSON (.json)</span>
                </button>
              </div>
            )}
          </div>

          {/* Toggle Left Catalog Drawer */}
          <button
            type="button"
            onClick={() => setIsLeftDrawerOpen((o) => !o)}
            className="ps-icon-btn catalog-toggle"
            title="Open Catalog & Layers"
          >
            <Menu size={15} />
            <span className="ps-btn-label">Catalog</span>
          </button>
        </div>
      </div>

      {/* ── ROW 3: CONTEXTUAL ACTIVE TOOLBAR ───────────────────────── */}
      <div className="ps-context-bar">
        {/* If in 2D Plan or Split View: Architectural Drafting & Blueprint Tools */}
        {(viewMode === '2d_blueprint' || viewMode === 'split_view') && (
          <div className="ps-context-group">
            <span className="ps-context-label">📐 CAD Tools:</span>
            <div className="ps-tools-cluster">
              <button
                type="button"
                onClick={() => {
                  setActiveTool('select');
                  showToast('Select & Transform tool active', '👆');
                }}
                className={`ps-pill-btn ${activeTool === 'select' ? 'active-select' : ''}`}
                title="Select & Transform"
              >
                <MousePointer size={13} />
                <span>Select</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setActiveTool('draw_wall');
                  showToast('Draw Wall active: click to place corners, click start to close room', '🧱');
                }}
                className={`ps-pill-btn ${activeTool === 'draw_wall' ? 'active-select' : ''}`}
                title="Interactive Wall Drafting (0°/45°/90° Snap)"
              >
                <PenTool size={13} />
                <span>Draw Wall</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setActiveTool('add_door');
                  showToast('Add Door active: click along any wall edge to place door', '🚪');
                }}
                className={`ps-pill-btn ${activeTool === 'add_door' ? 'active-select' : ''}`}
                title="Place Architectural Door"
              >
                <DoorOpen size={13} />
                <span>+ Door</span>
              </button>

              {activeTool === 'add_door' && (
                <select
                  value={doorStyle}
                  onChange={(e) => setDoorStyle(e.target.value)}
                  className="ps-tool-dropdown"
                  title="Door Style"
                >
                  <option value="single">Single Flush (3'0")</option>
                  <option value="french_glass">French Glass (6'0")</option>
                  <option value="sliding">Sliding Cavity</option>
                  <option value="archway">Open Archway</option>
                </select>
              )}

              <button
                type="button"
                onClick={() => {
                  setActiveTool('add_window');
                  showToast('Add Window active: click along any wall edge to place window', '🪟');
                }}
                className={`ps-pill-btn ${activeTool === 'add_window' ? 'active-select' : ''}`}
                title="Place Architectural Window"
              >
                <Square size={13} />
                <span>+ Window</span>
              </button>

              {activeTool === 'add_window' && (
                <select
                  value={windowStyle}
                  onChange={(e) => setWindowStyle(e.target.value)}
                  className="ps-tool-dropdown"
                  title="Window Style"
                >
                  <option value="casement">Casement (4'7")</option>
                  <option value="picture">Picture Curtain Wall</option>
                  <option value="slider">Sliding Window</option>
                  <option value="ventilator">High Ventilator</option>
                </select>
              )}

              <button
                type="button"
                onClick={() => {
                  setActiveTool('add_column');
                  showToast('Add Column active: click to place structural pillar', '🏛️');
                }}
                className={`ps-pill-btn ${activeTool === 'add_column' ? 'active-select' : ''}`}
                title="Place Structural RCC Column"
              >
                <Columns size={13} />
                <span>+ Column</span>
              </button>
            </div>

            <div className="ps-context-divider" />

            {/* Blueprint Underlay Controls */}
            {uploadedBlueprint ? (
              <div className="ps-blueprint-subbar-pill">
                <button
                  type="button"
                  onClick={() => {
                    setShowBlueprintUnderlay((v) => !v);
                    showToast(`Blueprint Underlay ${!showBlueprintUnderlay ? 'Enabled' : 'Hidden'}`, '🖼️');
                  }}
                  className={`ps-sub-pill ${showBlueprintUnderlay ? 'active' : ''}`}
                  title="Toggle Blueprint Texture Underlay"
                >
                  <ImageIcon size={12} />
                  <span>Blueprint: {showBlueprintUnderlay ? 'ON' : 'OFF'}</span>
                </button>

                {showBlueprintUnderlay && (
                  <div className="ps-opacity-control">
                    <span style={{ fontSize: '10.5px', color: '#fae8a4' }}>Opacity:</span>
                    <input
                      type="range"
                      min="0.1"
                      max="1.0"
                      step="0.05"
                      value={blueprintOpacity}
                      onChange={(e) => setBlueprintOpacity(parseFloat(e.target.value))}
                      style={{ width: '55px' }}
                    />
                    <span style={{ fontSize: '10.5px', fontFamily: 'monospace' }}>{Math.round(blueprintOpacity * 100)}%</span>
                  </div>
                )}

                <button
                  type="button"
                  onClick={() => {
                    setExtrudeBlueprintWalls((v) => !v);
                    showToast(`3D Extruded Boundary Walls ${!extrudeBlueprintWalls ? 'Enabled' : 'Hidden'}`, '🧱');
                  }}
                  className={`ps-sub-pill ${extrudeBlueprintWalls ? 'active' : ''}`}
                  title="Toggle 3D Boundary Wall Extrusion"
                >
                  <BoxIcon size={12} />
                  <span>3D Walls</span>
                </button>

                <button
                  type="button"
                  onClick={() => setIsUploadModalOpen(true)}
                  className="ps-sub-pill gold"
                  title="Upload New Floor Plan"
                >
                  <FileUp size={12} />
                  <span>Upload New</span>
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => setIsUploadModalOpen(true)}
                className="ps-pill-btn upload-blueprint-btn"
                title="Upload JPG, PNG, PDF, or CAD to project and trace in 3D"
              >
                <FileUp size={13} color="#fae8a4" />
                <span>Upload Floor Plan (JPG / PNG / CAD)</span>
              </button>
            )}
          </div>
        )}

        {/* If in 3D View: Materials, Lighting, Ceiling & Cutaway Controls */}
        {(viewMode === '3d_axo' || viewMode === 'all_floors') && (
          <div className="ps-context-group">
            <span className="ps-context-label">🏛️ 3D Controls:</span>
            <div className="ps-tools-cluster">
              {/* 3D Visual Shader / Render Style */}
              <select
                value={renderStyle}
                onChange={(e) => {
                  setRenderStyle(e.target.value);
                  showToast(`Render style: ${e.target.value}`, '🎨');
                }}
                className="ps-tool-dropdown"
                title="Architectural Visual Shader / Render Style"
              >
                <option value="realistic">✨ Photorealistic PBR</option>
                <option value="cyan_laser">⚡ Holographic Cyan Laser</option>
                <option value="clay">🏛️ Clay Model</option>
                <option value="wireframe">📐 Technical Wireframe</option>
              </select>

              {/* Ceiling Mode Selector */}
              {!isAllFloors && (
                <select
                  value={ceilingMode}
                  onChange={(e) => {
                    setCeilingMode(e.target.value);
                    showToast(`Ceiling: ${e.target.value}`, '💡');
                  }}
                  className="ps-tool-dropdown"
                  title="Ceiling & False Ceiling Cove Lighting"
                >
                  <option value="cove_led">💡 False Ceiling + LED Cove</option>
                  <option value="flat">🏠 Flat Gypsum Slab</option>
                  <option value="none">🔍 Open Cutaway (No Ceiling)</option>
                </select>
              )}

              {/* Wall Cut Mode in 3D */}
              {!isAllFloors && (
                <button
                  type="button"
                  onClick={() => {
                    setWallCutMode((m) => (m === 'waist' ? 'full' : 'waist'));
                    showToast(`Switched walls to ${wallCutMode === 'waist' ? 'Full 3.0m Height' : '1.2m Section Cut'}`, '📐');
                  }}
                  className="ps-pill-btn"
                  title="Toggle Wall Height Cut"
                >
                  <SplitSquareVertical size={13} />
                  <span>{wallCutMode === 'waist' ? 'Waist Cut (1.2m)' : 'Full Walls (3.0m)'}</span>
                </button>
              )}

              {/* Explode Slabs Slider in 3D Multi-Floor */}
              {isAllFloors && (
                <div className="ps-explode-control">
                  <span style={{ fontSize: '11px', color: '#fae8a4', fontWeight: 600 }}>Explode Slabs:</span>
                  <input
                    type="range"
                    min="0"
                    max="5.0"
                    step="0.2"
                    value={explodeOffset}
                    onChange={(e) => setExplodeOffset(parseFloat(e.target.value))}
                    style={{ width: '80px' }}
                  />
                  <span style={{ fontSize: '11px', fontFamily: 'monospace', color: '#38bdf8' }}>{explodeOffset.toFixed(1)}m</span>
                </div>
              )}

              {/* Sun / Time of Day in 3D */}
              <div className="ps-time-control">
                <Sun size={13} color="#fae8a4" />
                <span style={{ fontSize: '11px', color: '#fae8a4' }}>Sun:</span>
                <input
                  type="range"
                  min="8"
                  max="22"
                  step="1"
                  value={timeOfDay}
                  onChange={(e) => setTimeOfDay(parseInt(e.target.value, 10))}
                  style={{ width: '65px' }}
                  title="Time of Day Sun Lighting"
                />
                <span style={{ fontSize: '11px', fontFamily: 'monospace' }}>{timeOfDay}:00</span>
              </div>
            </div>
          </div>
        )}

        {/* If in 1:1 Projection Studio Mode */}
        {viewMode === 'projection_1to1' && (
          <div className="ps-context-group">
            <span className="ps-context-label">🔦 1:1 Life-Size Stage:</span>
            <div className="ps-stage-badges">
              <span className="ps-status-chip cyan">Laser Rig: 4K 10,000 Lumens</span>
              <span className="ps-status-chip gold">Scale: 1:1 Real-World True Scale (1m = 1m)</span>
              <span className="ps-status-chip">Physical Walking Area: 20m × 30m</span>
            </div>
          </div>
        )}

        {/* If in FPS Walk or VR Walk Mode */}
        {(viewMode === 'fps_walk' || viewMode === 'vr_walk') && (
          <div className="ps-context-group">
            <span className="ps-context-label">🚶 Walkthrough:</span>
            <div className="ps-stage-badges">
              <span className="ps-status-chip cyan">Eye Level: 1.65m (Human Height)</span>
              <span className="ps-status-chip">Navigation: WASD / Arrow Keys or Virtual Joystick</span>
              <span className="ps-status-chip gold">True Architectural Proportions</span>
            </div>
          </div>
        )}

        {/* If in 3D Land Plot Projector Mode */}
        {viewMode === '3d_land_projection' && (
          <div className="ps-context-group">
            <span className="ps-context-label">🌳 Outdoor Plot Projector:</span>
            <div className="ps-stage-badges">
              <span className="ps-status-chip green">Telescopic Mast: 12m Elevation</span>
              <span className="ps-status-chip gold">Outdoor Laser Projection System</span>
              <span className="ps-status-chip">Building Setback Compliance Active</span>
            </div>
          </div>
        )}
      </div>

      {/* ── QUICK-START GUIDED TOUR BANNER ───────────────────────────── */}
      {isGuideOpen && (
        <div className="ps-guide-banner">
          <div className="ps-guide-carousel-wrap">
            <div className="ps-guide-badge">
              <Sparkles size={13} color="#fae8a4" />
              <span>Tip {guideStep + 1} of {STUDIO_GUIDE_STEPS.length}</span>
            </div>
            <div className="ps-guide-content">
              <strong>{STUDIO_GUIDE_STEPS[guideStep].title}:</strong>{' '}
              <span>{STUDIO_GUIDE_STEPS[guideStep].desc}</span>
            </div>
          </div>

          <div className="ps-guide-nav">
            <button
              type="button"
              onClick={() => setGuideStep((s) => (s > 0 ? s - 1 : STUDIO_GUIDE_STEPS.length - 1))}
              className="ps-guide-arrow"
              title="Previous Tip"
            >
              <ChevronLeft size={14} />
            </button>
            <button
              type="button"
              onClick={() => setGuideStep((s) => (s < STUDIO_GUIDE_STEPS.length - 1 ? s + 1 : 0))}
              className="ps-guide-arrow"
              title="Next Tip"
            >
              <ChevronRight size={14} />
            </button>
            <button
              type="button"
              onClick={() => setIsWelcomeModalOpen(true)}
              className="ps-guide-full-btn"
              title="Open Complete User Guide & Shortcuts"
            >
              Full Guide (?)
            </button>
            <button
              type="button"
              onClick={() => setIsGuideOpen(false)}
              className="ps-guide-close"
              title="Dismiss Guide Strip"
            >
              <X size={13} />
            </button>
          </div>
        </div>
      )}

      {/* ── MAIN VIEWPORT WORKSPACE ──────────────────────────────────── */}
      <div className="ps-workspace">
        {/* Left Drawer: Rooms, Furniture & Layers */}
        <aside className={`ps-drawer-left ${isLeftDrawerOpen ? 'open' : ''}`}>
          <div className="ps-drawer-header">
            <div className="ps-drawer-title">
              <Layers size={15} color="#fae8a4" />
              <span>Architectural Elements</span>
            </div>
            <button type="button" onClick={() => setIsLeftDrawerOpen(false)} className="ps-drawer-close">
              <X size={15} />
            </button>
          </div>

          <div className="ps-drawer-content">
            {/* Quick Upload Action in Sidebar */}
            <button
              type="button"
              onClick={() => setIsUploadModalOpen(true)}
              className="ps-upload-card-btn"
            >
              <UploadCloud size={20} color="#fae8a4" />
              <div>
                <span className="ps-uc-title">Upload Architectural Plan</span>
                <span className="ps-uc-sub">Convert Image/CAD to 3D Projection</span>
              </div>
            </button>

            {/* Active Floor Summary */}
            <div className="ps-floor-summary-card">
              <span className="ps-summary-title">{building.name}</span>
              <span className="ps-summary-floor">{initialFloor.name}</span>
              <span className="ps-summary-sub">{initialFloor.subtitle}</span>
              <span className="ps-summary-footprint">{building.footprint}</span>
            </div>

            {/* Furniture Catalog */}
            <div>
              <div className="ps-section-header">
                <span className="ps-section-title">Modular Furniture & Landscaping ({FURNITURE_CATALOG.length})</span>
              </div>
              <div className="ps-category-pills">
                {['All', 'Living', 'Bedroom', 'Dining', 'Kitchen', 'Bathroom', 'Office', 'Vehicles'].map((cat) => (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setFurnitureCategory(cat)}
                    className={`ps-category-pill ${furnitureCategory === cat ? 'active' : ''}`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
              <div className="ps-furniture-grid">
                {EXTENDED_FURNITURE_CATALOG.filter(f => furnitureCategory === 'All' || f.category === furnitureCategory).map((f) => (
                  <button
                    key={f.type}
                    type="button"
                    onClick={() => {
                      const newItem = {
                        id: `f_${Date.now()}`,
                        type: f.type,
                        name: f.name,
                        x: 0,
                        z: 0,
                        w: f.w,
                        d: f.d,
                        h: f.h,
                        rot: 0,
                        clearance: f.clearance,
                        color: f.color
                      };
                      const updated = [...furniture, newItem];
                      setFurniture(updated);
                      pushHistory(rooms, updated);
                      setSelectedFurnitureId(newItem.id);
                      showToast(`Added ${f.name} to plan`, '🛋️');
                    }}
                    className="ps-furniture-btn"
                  >
                    <span style={{ fontWeight: 600 }}>{f.name}</span>
                    <span style={{ fontSize: '10px', color: '#fae8a4' }}>
                      {unit === 'imperial' ? `${toFeetInches(f.w)} × ${toFeetInches(f.d)}` : `${f.w}m × ${f.d}m`}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Room List on Active Floor */}
            <div>
              <div className="ps-section-header">
                <span className="ps-section-title">Rooms on This Floor ({rooms.length})</span>
              </div>
              <div className="ps-room-list">
                {rooms.map((r) => (
                  <button
                    key={r.id}
                    type="button"
                    onClick={() => {
                      setSelectedRoomId(r.id);
                      setSelectedFurnitureId(null);
                      setIsRightDrawerOpen(true);
                      showToast(`Inspecting ${r.name}`, '📐');
                    }}
                    className={`ps-room-item ${selectedRoomId === r.id ? 'active' : ''}`}
                  >
                    <span style={{ fontWeight: 600 }}>{r.name}</span>
                    <span style={{ fontFamily: 'monospace', color: '#94a3b8' }}>
                      {formatArea(r.w * r.d, unit)}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </aside>

        {/* Viewport Center: 2D CAD vs 3D WebGL Canvas */}
        <div className="ps-canvas-container">
          {viewMode === 'split_view' ? (
            <div className="ps-split-container">
              {/* Left Pane: 2D CAD Blueprint Drafting */}
              <div className="ps-split-pane ps-split-2d">
                <div className="ps-split-pane-header">
                  <div className="ps-split-title">
                    <PenTool size={13} color="#00f0ff" />
                    <span>2D CAD Blueprint Plan</span>
                  </div>
                  <div className="ps-split-badge">LIVE SYNC</div>
                </div>
                <CadBlueprintViewport
                  rooms={rooms}
                  furniture={furniture}
                  columns={columns}
                  customWalls={customWalls}
                  selectedRoomId={selectedRoomId}
                  selectedFurnitureId={selectedFurnitureId}
                  selectedOpeningId={selectedOpeningId}
                  selectedColumnId={selectedColumnId}
                  selectedWallId={selectedWallId}
                  onSelectRoom={(r) => {
                    setSelectedRoomId(r.id);
                    setSelectedFurnitureId(null);
                    setSelectedColumnId(null);
                    setSelectedWallId(null);
                    setIsRightDrawerOpen(true);
                  }}
                  onSelectFurniture={(f) => {
                    setSelectedFurnitureId(f.id);
                    setSelectedRoomId(null);
                    setSelectedColumnId(null);
                    setSelectedWallId(null);
                    setIsRightDrawerOpen(true);
                  }}
                  onSelectColumn={(col) => {
                    setSelectedColumnId(col.id);
                    setSelectedRoomId(null);
                    setSelectedFurnitureId(null);
                    setSelectedWallId(null);
                    setIsRightDrawerOpen(true);
                  }}
                  onSelectWall={(w) => {
                    setSelectedWallId(w.id);
                    setSelectedRoomId(null);
                    setSelectedFurnitureId(null);
                    setSelectedColumnId(null);
                    setIsRightDrawerOpen(true);
                  }}
                  onUpdateFurniture={setFurniture}
                  onUpdateRooms={setRooms}
                  onUpdateColumns={setColumns}
                  onUpdateCustomWalls={setCustomWalls}
                  onCommitHistory={pushHistory}
                  unit={unit}
                  activeTool={activeTool}
                  doorStyle={doorStyle}
                  windowStyle={windowStyle}
                  columnShape={columnShape}
                  buildingName={building.name}
                  floorTitle={initialFloor.name}
                  plotWidth={uploadedBlueprint?.width || building.plotWidth || 9.12}
                  plotDepth={uploadedBlueprint?.depth || building.plotDepth || 22.91}
                  showDimensions={showDimensions}
                  showFurniture={showFurniture}
                  showGrid={showGrid}
                  measurePoints={measurePoints}
                  onMeasureClick={handleMeasureClick}
                  uploadedBlueprint={uploadedBlueprint}
                  showUnderlay={showBlueprintUnderlay}
                  blueprintOpacity={blueprintOpacity}
                />
              </div>

              {/* Right Pane: Live 3D Architectural WebGL Model */}
              <div className="ps-split-pane ps-split-3d">
                <div className="ps-split-pane-header">
                  <div className="ps-split-title">
                    <BoxIcon size={13} color="#fae8a4" />
                    <span>3D Architectural BIM Model</span>
                  </div>
                  <div className="ps-split-badge gold">WEBGL SHADOWS</div>
                </div>
                <CanvasErrorBoundary>
                  <Canvas
                    shadows
                    gl={{ antialias: true, powerPreference: 'high-performance', preserveDrawingBuffer: true }}
                    camera={{ fov: 42, near: 0.1, far: 180, position: [24, 20, 24] }}
                    style={{ width: '100%', height: '100%' }}
                  >
                    <SceneCollector sceneRef={sceneRef} />
                    <DaylightRig timeOfDay={timeOfDay} />
                    <Suspense fallback={null}>
                      <CameraController
                        viewMode="3d_axo"
                        controlsRef={controlsRef}
                      />
                      <mesh position={[0, -0.05, 0]} receiveShadow>
                        <boxGeometry args={[uploadedBlueprint?.width || building.plotWidth || 9.12, 0.1, uploadedBlueprint?.depth || building.plotDepth || 22.91]} />
                        <meshStandardMaterial color="#0b1728" roughness={0.5} metalness={0.4} />
                      </mesh>
                      {columns.map((col) => (
                        <Column3D
                          key={col.id}
                          column={col}
                          wallHeight={wallCutMode === 'waist' ? 1.2 : 3.0}
                          renderStyle={renderStyle}
                          isSelected={selectedColumnId === col.id}
                          onSelect={(c) => {
                            setSelectedColumnId(c.id);
                            setSelectedRoomId(null);
                            setSelectedFurnitureId(null);
                            setIsRightDrawerOpen(true);
                          }}
                        />
                      ))}
                      {/* Architectural Exterior Landscape Plinth */}
                      <ArchitecturalLandscape
                        plotWidth={uploadedBlueprint?.width || building.plotWidth || 9.12}
                        plotDepth={uploadedBlueprint?.depth || building.plotDepth || 22.91}
                      />

                      {/* Custom Drawn Walls (OpenPlan3D Vector Wall Engine) */}
                      {customWalls.map((wall) => (
                        <CustomWall3D
                          key={wall.id}
                          wall={wall}
                          wallHeight={wallCutMode === 'waist' ? 1.2 : 3.0}
                          wallThick={wall.thick || 0.23}
                          renderStyle={renderStyle}
                          isSelected={selectedWallId === wall.id}
                          onSelect={(w) => {
                            setSelectedWallId(w.id);
                            setSelectedRoomId(null);
                            setSelectedFurnitureId(null);
                            setSelectedColumnId(null);
                            setIsRightDrawerOpen(true);
                          }}
                        />
                      ))}
                      {rooms.map((room) => (
                        <Parametric3DRoom
                          key={room.id}
                          room={room}
                          isSelected={selectedRoomId === room.id}
                          onSelect={(r) => {
                            setSelectedRoomId(r.id);
                            setSelectedFurnitureId(null);
                            setSelectedColumnId(null);
                            setIsRightDrawerOpen(true);
                          }}
                          viewMode={viewMode}
                          unit={unit}
                          wallCutHeight={wallCutMode === 'waist' ? 1.2 : 3.0}
                          elevation={0}
                          renderStyle={renderStyle}
                          ceilingMode={ceilingMode}
                        />
                      ))}
                      {showFurniture && furniture.map((item) => (
                        <Movable3DFurniture
                          key={item.id}
                          item={item}
                          isSelected={selectedFurnitureId === item.id}
                          onSelect={(f) => {
                            setSelectedFurnitureId(f.id);
                            setSelectedRoomId(null);
                            setSelectedColumnId(null);
                            setIsRightDrawerOpen(true);
                          }}
                          elevation={0}
                          renderStyle={renderStyle}
                        />
                      ))}
                      <RoomInteriorDownlights
                        rooms={rooms}
                        timeOfDay={timeOfDay}
                        elevation={0}
                        wallHeight={wallCutMode === 'waist' ? 1.2 : 3.0}
                      />
                      <GizmoHelper alignment="bottom-right" margin={[80, 80]}>
                        <GizmoViewport axisColors={['#ef4444', '#10b981', '#3b82f6']} labelColor="#ffffff" />
                      </GizmoHelper>
                    </Suspense>
                  </Canvas>
                </CanvasErrorBoundary>
              </div>
            </div>
          ) : viewMode === '2d_blueprint' ? (
            <CadBlueprintViewport
              rooms={rooms}
              furniture={furniture}
              columns={columns}
              customWalls={customWalls}
              selectedRoomId={selectedRoomId}
              selectedFurnitureId={selectedFurnitureId}
              selectedOpeningId={selectedOpeningId}
              selectedColumnId={selectedColumnId}
              selectedWallId={selectedWallId}
              onSelectRoom={(r) => {
                setSelectedRoomId(r.id);
                setSelectedFurnitureId(null);
                setSelectedColumnId(null);
                setSelectedWallId(null);
                setIsRightDrawerOpen(true);
              }}
              onSelectFurniture={(f) => {
                setSelectedFurnitureId(f.id);
                setSelectedRoomId(null);
                setSelectedColumnId(null);
                setSelectedWallId(null);
                setIsRightDrawerOpen(true);
              }}
              onSelectColumn={(col) => {
                setSelectedColumnId(col.id);
                setSelectedRoomId(null);
                setSelectedFurnitureId(null);
                setSelectedWallId(null);
                setIsRightDrawerOpen(true);
              }}
              onSelectWall={(w) => {
                setSelectedWallId(w.id);
                setSelectedRoomId(null);
                setSelectedFurnitureId(null);
                setSelectedColumnId(null);
                setIsRightDrawerOpen(true);
              }}
              onUpdateFurniture={setFurniture}
              onUpdateRooms={setRooms}
              onUpdateColumns={setColumns}
              onUpdateCustomWalls={setCustomWalls}
              onCommitHistory={pushHistory}
              unit={unit}
              activeTool={activeTool}
              doorStyle={doorStyle}
              windowStyle={windowStyle}
              columnShape={columnShape}
              buildingName={building.name}
              floorTitle={initialFloor.name}
              plotWidth={uploadedBlueprint?.width || building.plotWidth || 9.12}
              plotDepth={uploadedBlueprint?.depth || building.plotDepth || 22.91}
              showDimensions={showDimensions}
              showFurniture={showFurniture}
              showGrid={showGrid}
              measurePoints={measurePoints}
              onMeasureClick={handleMeasureClick}
              uploadedBlueprint={uploadedBlueprint}
              showUnderlay={showBlueprintUnderlay}
              blueprintOpacity={blueprintOpacity}
            />
          ) : (
            <CanvasErrorBoundary>
              <Canvas
                shadows
                gl={{ antialias: true, powerPreference: 'high-performance', preserveDrawingBuffer: true }}
                camera={{ fov: 42, near: 0.1, far: 180, position: [24, 20, 24] }}
                style={{ width: '100%', height: '100%' }}
              >
                <SceneCollector sceneRef={sceneRef} />
                <DaylightRig timeOfDay={timeOfDay} />

                <Suspense fallback={null}>
                  <CameraController
                    viewMode={isAllFloors ? 'all_floors' : viewMode}
                    controlsRef={controlsRef}
                    cameraTargetPos={viewMode === 'fps_walk' ? walkPos : null}
                  />

                  {/* 3D Real Land Plot Projector Scene */}
                  {viewMode === '3d_land_projection' ? (
                    <LandPlot3DProjectorScene
                      rooms={rooms}
                      furniture={furniture}
                      selectedRoomId={selectedRoomId}
                      selectedFurnitureId={selectedFurnitureId}
                      onSelectRoom={(r) => {
                        setSelectedRoomId(r.id);
                        setSelectedFurnitureId(null);
                        setSelectedColumnId(null);
                        setIsRightDrawerOpen(true);
                      }}
                      onSelectFurniture={(f) => {
                        setSelectedFurnitureId(f.id);
                        setSelectedRoomId(null);
                        setSelectedColumnId(null);
                        setIsRightDrawerOpen(true);
                      }}
                      plotConfig={selectedPlotConfig}
                      building={building}
                      unit={unit}
                      wallCutHeight={wallCutMode === 'waist' ? 1.2 : 3.0}
                      uploadedBlueprint={uploadedBlueprint}
                      showBlueprintUnderlay={showBlueprintUnderlay}
                      blueprintOpacity={blueprintOpacity}
                      showFurniture={showFurniture}
                      laserActive={isLandLaserActive}
                      isNightProjector={isNightProjector}
                      showSetbacks={showSetbacks}
                    />
                  ) : (
                    <>
                      {/* 1:1 Scale Warehouse Floor Grid if in projection mode */}
                      {viewMode === 'projection_1to1' && <LaserProjectionFloor size={40} />}

                      {/* Uploaded Blueprint Image Projected onto 3D Floor */}
                      {uploadedBlueprint && showBlueprintUnderlay && !isAllFloors && (
                        <Blueprint3DPlane
                          blueprint={uploadedBlueprint}
                          elevation={0}
                          opacity={blueprintOpacity}
                        />
                      )}

                      {/* Extruded Boundary 3D Walls for Uploaded Blueprint */}
                      {extrudeBlueprintWalls && !isAllFloors && (
                        <ExtrudedBoundaryWalls
                          width={uploadedBlueprint?.width || building.plotWidth || 9.12}
                          depth={uploadedBlueprint?.depth || building.plotDepth || 22.91}
                          height={wallCutMode === 'waist' ? 1.2 : 3.0}
                          elevation={0}
                        />
                      )}

                      {/* Multi-Floor Stack vs Single Floor */}
                      {isAllFloors ? (
                        <Building3DStack
                          building={building}
                          explodeOffset={explodeOffset}
                          wallCutHeight={wallCutMode === 'waist' ? 1.2 : 3.0}
                          unit={unit}
                          selectedRoomId={selectedRoomId}
                          selectedFurnitureId={selectedFurnitureId}
                          onSelectRoom={(r) => {
                            setSelectedRoomId(r.id);
                            setSelectedFurnitureId(null);
                            setSelectedColumnId(null);
                            setIsRightDrawerOpen(true);
                          }}
                          onSelectFurniture={(f) => {
                            setSelectedFurnitureId(f.id);
                            setSelectedRoomId(null);
                            setSelectedColumnId(null);
                            setIsRightDrawerOpen(true);
                          }}
                        />
                      ) : (
                        <>
                          {/* Architectural Exterior Landscape Plinth */}
                          <ArchitecturalLandscape
                            plotWidth={uploadedBlueprint?.width || building.plotWidth || 9.12}
                            plotDepth={uploadedBlueprint?.depth || building.plotDepth || 22.91}
                          />

                          {/* Floor Base Slab Plate */}
                          <mesh position={[0, -0.05, 0]} receiveShadow>
                            <boxGeometry args={[uploadedBlueprint?.width || building.plotWidth || 9.12, 0.1, uploadedBlueprint?.depth || building.plotDepth || 22.91]} />
                            <meshStandardMaterial color="#0b1728" roughness={0.5} metalness={0.4} />
                          </mesh>

                          {/* Structural Columns */}
                          {columns.map((col) => (
                            <Column3D
                              key={col.id}
                              column={col}
                              wallHeight={wallCutMode === 'waist' ? 1.2 : 3.0}
                              renderStyle={renderStyle}
                              isSelected={selectedColumnId === col.id}
                              onSelect={(c) => {
                                setSelectedColumnId(c.id);
                                setSelectedRoomId(null);
                                setSelectedFurnitureId(null);
                                setSelectedWallId(null);
                                setIsRightDrawerOpen(true);
                              }}
                            />
                          ))}

                          {/* Custom Drawn Walls (OpenPlan3D Vector Wall Engine) */}
                          {customWalls.map((wall) => (
                            <CustomWall3D
                              key={wall.id}
                              wall={wall}
                              wallHeight={wallCutMode === 'waist' ? 1.2 : 3.0}
                              wallThick={wall.thick || 0.23}
                              renderStyle={renderStyle}
                              isSelected={selectedWallId === wall.id}
                              onSelect={(w) => {
                                setSelectedWallId(w.id);
                                setSelectedRoomId(null);
                                setSelectedFurnitureId(null);
                                setSelectedColumnId(null);
                                setIsRightDrawerOpen(true);
                              }}
                            />
                          ))}

                          {rooms.map((room) => (
                            <Parametric3DRoom
                              key={room.id}
                              room={room}
                              isSelected={selectedRoomId === room.id}
                              onSelect={(r) => {
                                setSelectedRoomId(r.id);
                                setSelectedFurnitureId(null);
                                setSelectedColumnId(null);
                                setIsRightDrawerOpen(true);
                              }}
                              viewMode={viewMode}
                              unit={unit}
                              wallCutHeight={wallCutMode === 'waist' ? 1.2 : 3.0}
                              elevation={0}
                              renderStyle={renderStyle}
                              ceilingMode={ceilingMode}
                            />
                          ))}

                          {showFurniture && furniture.map((item) => (
                            <Movable3DFurniture
                              key={item.id}
                              item={item}
                              isSelected={selectedFurnitureId === item.id}
                              onSelect={(f) => {
                                setSelectedFurnitureId(f.id);
                                setSelectedRoomId(null);
                                setSelectedColumnId(null);
                                setIsRightDrawerOpen(true);
                              }}
                              elevation={0}
                              renderStyle={renderStyle}
                            />
                          ))}

                          {/* Room Interior Downlights */}
                          <RoomInteriorDownlights
                            rooms={rooms}
                            timeOfDay={timeOfDay}
                            elevation={0}
                            wallHeight={wallCutMode === 'waist' ? 1.2 : 3.0}
                          />
                        </>
                      )}
                    </>
                  )}

                  <GizmoHelper alignment="bottom-right" margin={[80, 80]}>
                    <GizmoViewport axisColors={['#ef4444', '#10b981', '#3b82f6']} labelColor="#ffffff" />
                  </GizmoHelper>
                </Suspense>
              </Canvas>
            </CanvasErrorBoundary>
          )}

          {/* Floating 3D Direct Manipulation Quick-Action HUD for Selected Item */}
          {selectedFurniture && (viewMode === '3d_axo' || viewMode === 'split_view') && (
            <div className="ps-3d-floating-hud">
              <div className="ps-3d-hud-header">
                <span className="ps-3d-hud-title">{selectedFurniture.name}</span>
                <span className="ps-3d-hud-coords">
                  X: {selectedFurniture.x}m · Z: {selectedFurniture.z}m ({selectedFurniture.rot || 0}°)
                </span>
              </div>
              <div className="ps-3d-hud-buttons">
                <button type="button" onClick={() => handleRotateSelected(-45)} title="Rotate Left 45°">↺ -45°</button>
                <button type="button" onClick={() => handleRotateSelected(45)} title="Rotate Right 45°">↻ +45°</button>
                <button type="button" onClick={() => handleNudgeSelected(-0.25, 0)} title="Move West">← W</button>
                <button type="button" onClick={() => handleNudgeSelected(0.25, 0)} title="Move East">E →</button>
                <button type="button" onClick={() => handleNudgeSelected(0, -0.25)} title="Move North">↑ N</button>
                <button type="button" onClick={() => handleNudgeSelected(0, 0.25)} title="Move South">S ↓</button>
                <button type="button" onClick={handleDuplicateSelected} title="Duplicate">📋 Clone</button>
                <button type="button" className="danger" onClick={handleDeleteSelected} title="Delete">🗑️ Del</button>
              </div>
            </div>
          )}

          {/* 3D Real Land Plot Projector HUD Controls */}
          {viewMode === '3d_land_projection' && (
            <div className="ps-land-hud">
              <div className="ps-land-badge">
                <Trees size={15} color="#34d399" />
                <span>3D Land Plot Projector</span>
              </div>
              <div className="ps-land-controls">
                <select
                  value={selectedPlotConfig?.id || ''}
                  onChange={(e) => {
                    const p = LAND_PLOT_PRESETS.find((x) => x.id === e.target.value) || LAND_PLOT_PRESETS[0];
                    setSelectedPlotConfig(p);
                    showToast(`Land Plot set to ${p.name}`, '📐');
                  }}
                  className="ps-land-select"
                >
                  {LAND_PLOT_PRESETS.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} ({p.facing} Facing)
                    </option>
                  ))}
                </select>

                <button
                  type="button"
                  onClick={() => setIsNightProjector((n) => !n)}
                  className={`ps-land-btn ${isNightProjector ? 'active' : ''}`}
                  title="Toggle Night Holographic Mode"
                >
                  {isNightProjector ? '🌙 Night Projection' : '☀️ Day Lighting'}
                </button>

                <button
                  type="button"
                  onClick={() => setIsLandLaserActive((l) => !l)}
                  className={`ps-land-btn ${isLandLaserActive ? 'active' : ''}`}
                  title="Toggle Projector Beam"
                >
                  <Sparkles size={12} />
                  <span>{isLandLaserActive ? 'Laser Beam: ON' : 'Laser Beam: OFF'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setShowSetbacks((s) => !s)}
                  className={`ps-land-btn ${showSetbacks ? 'active' : ''}`}
                  title="Toggle Municipal Setbacks"
                >
                  <span>Setbacks: {showSetbacks ? 'ON' : 'OFF'}</span>
                </button>
              </div>
            </div>
          )}

          {/* Floating Transform Bar when Room, Furniture, or Wall is Selected */}
          {(selectedFurniture || selectedRoom || selectedWall) && (
            <div className="ps-floating-transform-bar">
              <span className="ps-transform-title">
                {selectedFurniture
                  ? `Selected: ${selectedFurniture.name}`
                  : selectedRoom
                  ? `Selected: ${selectedRoom.name}`
                  : `Wall: ${formatDim(Math.hypot((selectedWall.x2 || 0) - (selectedWall.x1 || 0), (selectedWall.z2 || 0) - (selectedWall.z1 || 0)), unit)}`}
              </span>

              {selectedWall && (
                <div className="ps-transform-group" style={{ display: 'flex', gap: '6px', alignItems: 'center' }}>
                  <select
                    value={selectedWall.thick || 0.23}
                    onChange={(e) => {
                      const val = parseFloat(e.target.value);
                      setCustomWalls((prev) => prev.map((w) => w.id === selectedWall.id ? { ...w, thick: val } : w));
                    }}
                    className="ps-tool-dropdown"
                    title="Wall Thickness"
                  >
                    <option value="0.15">6" (0.15m)</option>
                    <option value="0.23">9" (0.23m)</option>
                    <option value="0.35">14" (0.35m)</option>
                  </select>

                  <select
                    value={selectedWall.height || 3.0}
                    onChange={(e) => {
                      const val = parseFloat(e.target.value);
                      setCustomWalls((prev) => prev.map((w) => w.id === selectedWall.id ? { ...w, height: val } : w));
                    }}
                    className="ps-tool-dropdown"
                    title="Wall Height"
                  >
                    <option value="1.2">1.2m Cut</option>
                    <option value="2.8">2.8m</option>
                    <option value="3.0">3.0m Std</option>
                    <option value="3.4">3.4m High</option>
                  </select>

                  <button
                    type="button"
                    onClick={() => {
                      const mx = (selectedWall.x1 + selectedWall.x2) / 2;
                      const mz = (selectedWall.z1 + selectedWall.z2) / 2;
                      const w1 = { ...selectedWall, id: `w_${Date.now()}_1`, x2: mx, z2: mz };
                      const w2 = { ...selectedWall, id: `w_${Date.now()}_2`, x1: mx, z1: mz };
                      setCustomWalls((prev) => prev.flatMap((w) => w.id === selectedWall.id ? [w1, w2] : [w]));
                      setSelectedWallId(w1.id);
                      showToast('Split wall into two equal segments', '✂️');
                    }}
                    className="ps-transform-btn"
                    title="Split Wall into Two Segments"
                  >
                    <Scissors size={12} />
                    <span>Split</span>
                  </button>
                </div>
              )}

              {(selectedFurniture || selectedRoom) && (
                <div className="ps-transform-group">
                  <button type="button" onClick={() => handleNudgeSelected(-0.2, 0)} title="Move Left (←)">←</button>
                  <button type="button" onClick={() => handleNudgeSelected(0.2, 0)} title="Move Right (→)">→</button>
                  <button type="button" onClick={() => handleNudgeSelected(0, -0.2)} title="Move Up (↑)">↑</button>
                  <button type="button" onClick={() => handleNudgeSelected(0, 0.2)} title="Move Down (↓)">↓</button>
                </div>
              )}

              {selectedFurniture && (
                <button type="button" onClick={() => handleRotateSelected(45)} className="ps-transform-btn" title="Rotate 45° (R)">
                  <RotateCw size={12} />
                  <span>Rotate 45°</span>
                </button>
              )}

              {(selectedFurniture || selectedRoom) && (
                <button type="button" onClick={handleDuplicateSelected} className="ps-transform-btn" title="Duplicate">
                  <Copy size={12} />
                  <span>Duplicate</span>
                </button>
              )}

              <button type="button" onClick={handleDeleteSelected} className="ps-transform-btn danger" title="Delete (Del)">
                <Trash2 size={12} />
                <span>Delete</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setSelectedRoomId(null);
                  setSelectedFurnitureId(null);
                  setSelectedWallId(null);
                }}
                className="ps-transform-btn"
                title="Deselect (Esc)"
              >
                <X size={12} />
              </button>
            </div>
          )}

          {/* FPS Walk Controls HUD */}
          {viewMode === 'fps_walk' && (
            <div className="ps-walk-hud">
              <span className="ps-walk-badge">🚶 1:1 First Person Walkthrough (Eye Level 1.65m)</span>
              <div className="ps-walk-keys">
                <button type="button" onClick={() => setWalkPos((p) => ({ ...p, z: p.z - 0.5 }))} title="Forward">↑</button>
                <div style={{ display: 'flex', gap: '4px' }}>
                  <button type="button" onClick={() => setWalkPos((p) => ({ ...p, x: p.x - 0.5 }))} title="Left">←</button>
                  <button type="button" onClick={() => setWalkPos((p) => ({ ...p, z: p.z + 0.5 }))} title="Backward">↓</button>
                  <button type="button" onClick={() => setWalkPos((p) => ({ ...p, x: p.x + 0.5 }))} title="Right">→</button>
                </div>
              </div>
            </div>
          )}

          {/* Measurement Tape Info Box */}
          {activeTool === 'measure' && (
            <div className="ps-measure-pill">
              <Ruler size={14} color="#facc15" />
              <span>
                {!measurePoints.p1
                  ? 'Click Point 1 on Blueprint to begin'
                  : !measurePoints.p2
                  ? 'Click Point 2 to measure distance'
                  : `Distance: ${unit === 'imperial'
                      ? toFeetInches(Math.hypot(measurePoints.p2.x - measurePoints.p1.x, measurePoints.p2.z - measurePoints.p1.z))
                      : Math.hypot(measurePoints.p2.x - measurePoints.p1.x, measurePoints.p2.z - measurePoints.p1.z).toFixed(2) + 'm'}`}
              </span>
              {measurePoints.p1 && (
                <button type="button" onClick={() => setMeasurePoints({ p1: null, p2: null })}>Reset</button>
              )}
            </div>
          )}
        </div>

        {/* Right Drawer: Properties Inspector */}
        <aside className={`ps-drawer-right ${isRightDrawerOpen ? 'open' : ''}`}>
          <div className="ps-drawer-header">
            <div className="ps-drawer-title">
              <Sliders size={15} color="#fae8a4" />
              <span>{selectedRoom ? 'Room Inspector' : selectedFurniture ? 'Furniture Inspector' : selectedWall ? 'Wall Inspector' : 'Inspector'}</span>
            </div>
            <button type="button" onClick={() => setIsRightDrawerOpen(false)} className="ps-drawer-close">
              <X size={15} />
            </button>
          </div>

          <div className="ps-drawer-content">
            {selectedWall ? (
              <>
                <div className="ps-form-group">
                  <label className="ps-label">Wall Identifier</label>
                  <input type="text" value={selectedWall.id} disabled className="ps-input" style={{ opacity: 0.7 }} />
                </div>

                <div className="ps-dimension-box">
                  <span className="ps-dim-label">Wall Span Length:</span>
                  <span className="ps-dim-val">
                    {formatDim(Math.hypot((selectedWall.x2 || 0) - (selectedWall.x1 || 0), (selectedWall.z2 || 0) - (selectedWall.z1 || 0)), unit)}
                  </span>
                  <span className="ps-dim-area">
                    Coordinates: ({selectedWall.x1?.toFixed(2)}m, {selectedWall.z1?.toFixed(2)}m) → ({selectedWall.x2?.toFixed(2)}m, {selectedWall.z2?.toFixed(2)}m)
                  </span>
                </div>

                <div className="ps-form-group">
                  <label className="ps-label">Wall Thickness</label>
                  <select
                    value={selectedWall.thick || 0.23}
                    onChange={(e) => {
                      const val = parseFloat(e.target.value);
                      setCustomWalls((prev) => prev.map((w) => w.id === selectedWall.id ? { ...w, thick: val } : w));
                    }}
                    className="ps-select"
                  >
                    <option value="0.15">150mm (6" Interior Partition)</option>
                    <option value="0.23">230mm (9" Standard Brickwork)</option>
                    <option value="0.35">350mm (14" Heavy Structural Wall)</option>
                  </select>
                </div>

                <div className="ps-form-group">
                  <label className="ps-label">Wall Height</label>
                  <select
                    value={selectedWall.height || 3.0}
                    onChange={(e) => {
                      const val = parseFloat(e.target.value);
                      setCustomWalls((prev) => prev.map((w) => w.id === selectedWall.id ? { ...w, height: val } : w));
                    }}
                    className="ps-select"
                  >
                    <option value="1.2">1.2m (4' Waist Cut Dollhouse)</option>
                    <option value="2.8">2.8m (9'2" Standard Ceiling)</option>
                    <option value="3.0">3.0m (10'0" High Ceiling)</option>
                    <option value="3.4">3.4m (11'2" Double Height)</option>
                  </select>
                </div>

                <div className="ps-form-group">
                  <label className="ps-label">Wall Finish Material</label>
                  <select
                    value={selectedWall.wallMat || 'wall_white_chalk'}
                    onChange={(e) => {
                      setCustomWalls((prev) => prev.map((w) => w.id === selectedWall.id ? { ...w, wallMat: e.target.value } : w));
                    }}
                    className="ps-select"
                  >
                    {WALL_MATERIALS.map((m) => (
                      <option key={m.id} value={m.id}>{m.name}</option>
                    ))}
                  </select>
                </div>

                <div style={{ display: 'flex', gap: '8px', marginTop: '16px' }}>
                  <button
                    type="button"
                    onClick={() => {
                      const mx = ((selectedWall.x1 || 0) + (selectedWall.x2 || 0)) / 2;
                      const mz = ((selectedWall.z1 || 0) + (selectedWall.z2 || 0)) / 2;
                      const w1 = { ...selectedWall, id: `w_${Date.now()}_1`, x2: mx, z2: mz };
                      const w2 = { ...selectedWall, id: `w_${Date.now()}_2`, x1: mx, z1: mz };
                      setCustomWalls((prev) => prev.flatMap((w) => w.id === selectedWall.id ? [w1, w2] : [w]));
                      setSelectedWallId(w1.id);
                      showToast('Split wall into two equal segments', '✂️');
                    }}
                    className="ps-pill-btn"
                    style={{ flex: 1, justifyContent: 'center' }}
                  >
                    <Scissors size={13} />
                    <span>Split Wall</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setCustomWalls((prev) => prev.filter((w) => w.id !== selectedWall.id));
                      setSelectedWallId(null);
                      showToast('Deleted wall segment', '🗑️');
                    }}
                    className="ps-pill-btn danger"
                    style={{ flex: 1, justifyContent: 'center' }}
                  >
                    <Trash2 size={13} />
                    <span>Delete</span>
                  </button>
                </div>
              </>
            ) : selectedRoom ? (
              <>
                <div className="ps-form-group">
                  <label className="ps-label">Room Name</label>
                  <input
                    type="text"
                    value={selectedRoom.name}
                    onChange={(e) => {
                      const updated = rooms.map((r) => (r.id === selectedRoom.id ? { ...r, name: e.target.value } : r));
                      setRooms(updated);
                    }}
                    className="ps-input"
                  />
                </div>

                <div className="ps-dimension-box">
                  <span className="ps-dim-label">Dimensions:</span>
                  <span className="ps-dim-val">
                    {unit === 'imperial'
                      ? `${toFeetInches(selectedRoom.w)} × ${toFeetInches(selectedRoom.d)}`
                      : `${selectedRoom.w.toFixed(2)}m × ${selectedRoom.d.toFixed(2)}m`}
                  </span>
                  <span className="ps-dim-area">
                    Carpet Area: {formatArea(selectedRoom.w * selectedRoom.d, unit)}
                  </span>
                </div>

                <div className="ps-form-group">
                  <label className="ps-label">Vastu Room Type</label>
                  <select
                    value={selectedRoom.type}
                    onChange={(e) => {
                      const updated = rooms.map((r) => (r.id === selectedRoom.id ? { ...r, type: e.target.value } : r));
                      setRooms(updated);
                    }}
                    className="ps-select"
                  >
                    <option value="living">Living & Drawing Hall (Indra/Kubera)</option>
                    <option value="master">Master Bedroom Suite (Niruthi SW)</option>
                    <option value="bedroom">Guest / Kids Bedroom (Vayu NW)</option>
                    <option value="kitchen">Modular Chef Kitchen (Agni SE)</option>
                    <option value="dining">Dining Courtyard (Varuna W)</option>
                    <option value="puja">Ishaan Meditation Mandir (NE)</option>
                    <option value="bath">Ensuite Luxury Toilet</option>
                    <option value="parking">Stilt Vehicle Parking</option>
                    <option value="balcony">Open Glass Balcony</option>
                  </select>
                </div>

                <div className="ps-form-group">
                  <label className="ps-label">Floor Finish Material</label>
                  <select
                    value={selectedRoom.floorMat || 'marble_calacatta'}
                    onChange={(e) => {
                      const updated = rooms.map((r) => (r.id === selectedRoom.id ? { ...r, floorMat: e.target.value } : r));
                      setRooms(updated);
                    }}
                    className="ps-select"
                  >
                    {FLOOR_MATERIALS.map((m) => (
                      <option key={m.id} value={m.id}>{m.name} ({m.category})</option>
                    ))}
                  </select>
                </div>

                <div className="ps-form-group">
                  <label className="ps-label">Wall Paint & Plaster</label>
                  <select
                    value={selectedRoom.wallMat || 'wall_white_chalk'}
                    onChange={(e) => {
                      const updated = rooms.map((r) => (r.id === selectedRoom.id ? { ...r, wallMat: e.target.value } : r));
                      setRooms(updated);
                    }}
                    className="ps-select"
                  >
                    {WALL_MATERIALS.map((m) => (
                      <option key={m.id} value={m.id}>{m.name}</option>
                    ))}
                  </select>
                </div>
              </>
            ) : selectedFurniture ? (
              <>
                <div className="ps-form-group">
                  <label className="ps-label">Furniture Name</label>
                  <input
                    type="text"
                    value={selectedFurniture.name}
                    onChange={(e) => {
                      const updated = furniture.map((f) => (f.id === selectedFurniture.id ? { ...f, name: e.target.value } : f));
                      setFurniture(updated);
                    }}
                    className="ps-input"
                  />
                </div>

                <div className="ps-dimension-box">
                  <span className="ps-dim-label">Dimensions:</span>
                  <span className="ps-dim-val">
                    {unit === 'imperial'
                      ? `${toFeetInches(selectedFurniture.w)} × ${toFeetInches(selectedFurniture.d)}`
                      : `${selectedFurniture.w.toFixed(2)}m × ${selectedFurniture.d.toFixed(2)}m`}
                  </span>
                </div>

                <div style={{ display: 'flex', gap: '8px', marginTop: '12px' }}>
                  <button
                    type="button"
                    onClick={() => {
                      const updated = furniture.map((f) => (f.id === selectedFurniture.id ? { ...f, rot: ((f.rot || 0) + 45) % 360 } : f));
                      setFurniture(updated);
                      pushHistory(rooms, updated);
                      showToast(`Rotated ${selectedFurniture.name}`, '↻');
                    }}
                    className="ps-pill-btn"
                  >
                    <RotateCw size={13} />
                    <span>Rotate 45°</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      const updated = furniture.filter((f) => f.id !== selectedFurniture.id);
                      setFurniture(updated);
                      pushHistory(rooms, updated);
                      setSelectedFurnitureId(null);
                      setIsRightDrawerOpen(false);
                      showToast('Item deleted', '🗑️');
                    }}
                    className="ps-pill-btn danger"
                  >
                    <Trash2 size={13} />
                    <span>Delete</span>
                  </button>
                </div>
              </>
            ) : (
              <div style={{ textAlign: 'center', padding: '30px 10px', color: '#64748b' }}>
                <MousePointer size={28} style={{ margin: '0 auto 10px', opacity: 0.5 }} />
                <p>Click any room or furniture item on the plan to inspect dimensions, finishes, and Vastu alignment.</p>
              </div>
            )}
          </div>
        </aside>
      </div>

      {/* ── 0. ARCHITECTURAL BLUEPRINT UPLOAD & 3D CONVERTER MODAL ────── */}
      {isUploadModalOpen && (
        <div className="ps-modal-backdrop" onClick={() => setIsUploadModalOpen(false)}>
          <div className="ps-modal-card ps-upload-modal" onClick={(e) => e.stopPropagation()}>
            <div className="ps-modal-header">
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <UploadCloud size={20} color="#fae8a4" />
                <span className="ps-modal-title">Upload Architectural Blueprint & Render 3D</span>
              </div>
              <button type="button" onClick={() => setIsUploadModalOpen(false)} className="ps-modal-close">
                <X size={18} />
              </button>
            </div>

            <div className="ps-modal-body">
              {/* Drag & Drop File Zone */}
              <div
                className="ps-dropzone"
                onClick={() => fileInputRef.current && fileInputRef.current.click()}
                onDragOver={(e) => e.preventDefault()}
                onDrop={(e) => {
                  e.preventDefault();
                  if (e.dataTransfer.files && e.dataTransfer.files[0]) {
                    processUploadedFile(e.dataTransfer.files[0]);
                  }
                }}
              >
                <input
                  type="file"
                  ref={fileInputRef}
                  style={{ display: 'none' }}
                  accept="image/png,image/jpeg,image/webp,image/svg+xml,.dxf,.json"
                  onChange={(e) => {
                    if (e.target.files && e.target.files[0]) {
                      processUploadedFile(e.target.files[0]);
                    }
                  }}
                />
                <FileUp size={44} color="#fae8a4" style={{ marginBottom: '8px' }} />
                <span className="ps-drop-title">Click to Browse or Drag & Drop Blueprint File</span>
                <span className="ps-drop-sub">Supports Architectural Images (JPG, PNG, WEBP), CAD DXF, and Project JSON</span>
                <span className="ps-drop-badge">Auto 3D Extrusion & 1:1 Scale Stage Conversion</span>
              </div>

              {/* Customer Plan Scale Calibration Inputs & Presets */}
              <div style={{ marginTop: '16px', background: '#050c18', border: '1px solid rgba(250, 232, 164, 0.25)', borderRadius: '10px', padding: '14px' }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '8px' }}>
                  <span style={{ fontSize: '12px', fontWeight: 700, color: '#fae8a4' }}>📐 Real-World Plot Dimensions & Scale</span>
                  <span style={{ fontSize: '10.5px', color: '#94a3b8' }}>Calibrates 1:1 physical size for 3D & VR</span>
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px', marginBottom: '10px' }}>
                  <div>
                    <label style={{ fontSize: '10.5px', color: '#94a3b8', display: 'block', marginBottom: '3px' }}>Plot Width (Meters):</label>
                    <input
                      type="number"
                      step="0.1"
                      value={uploadWidth}
                      onChange={(e) => setUploadWidth(parseFloat(e.target.value) || 9.12)}
                      style={{ width: '100%', background: '#0b1626', border: '1px solid rgba(255,255,255,0.15)', color: '#ffffff', padding: '6px 10px', borderRadius: '6px', fontSize: '12px' }}
                    />
                    <span style={{ fontSize: '9.5px', color: '#00f0ff', fontFamily: 'monospace' }}>≈ {toFeetInches(uploadWidth)}</span>
                  </div>
                  <div>
                    <label style={{ fontSize: '10.5px', color: '#94a3b8', display: 'block', marginBottom: '3px' }}>Plot Depth (Meters):</label>
                    <input
                      type="number"
                      step="0.1"
                      value={uploadDepth}
                      onChange={(e) => setUploadDepth(parseFloat(e.target.value) || 22.91)}
                      style={{ width: '100%', background: '#0b1626', border: '1px solid rgba(255,255,255,0.15)', color: '#ffffff', padding: '6px 10px', borderRadius: '6px', fontSize: '12px' }}
                    />
                    <span style={{ fontSize: '9.5px', color: '#00f0ff', fontFamily: 'monospace' }}>≈ {toFeetInches(uploadDepth)}</span>
                  </div>
                </div>
                {/* Standard Indian & Global Architectural Plot Presets */}
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px', flexWrap: 'wrap' }}>
                  <span style={{ fontSize: '10px', color: '#94a3b8' }}>Quick Presets:</span>
                  {[
                    { label: "30' × 60'", w: 9.14, d: 18.29 },
                    { label: "30' × 75'", w: 9.12, d: 22.91 },
                    { label: "40' × 60'", w: 12.19, d: 18.29 },
                    { label: "20' × 50'", w: 6.10, d: 15.24 },
                    { label: "50' × 80'", w: 15.24, d: 24.38 }
                  ].map((preset) => (
                    <button
                      key={preset.label}
                      type="button"
                      onClick={() => { setUploadWidth(preset.w); setUploadDepth(preset.d); }}
                      style={{ background: '#0c1b2f', border: '1px solid rgba(0, 240, 255, 0.3)', color: '#00f0ff', fontSize: '10px', padding: '3px 8px', borderRadius: '4px', cursor: 'pointer' }}
                    >
                      {preset.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Sample Blueprints Quick-Try (Ground, First, Stilt, Terrace) */}
              <div style={{ marginTop: '20px' }}>
                <div className="ps-section-header">
                  <span className="ps-section-title">Or Try Sample Architectural Blueprints (1-Click 3D)</span>
                </div>
                <div className="ps-sample-blueprints-grid">
                  <button
                    type="button"
                    className="ps-sample-card"
                    onClick={() => {
                      setUploadedBlueprint({
                        imageUrl: '/blueprints/ground_floor_plan.jpg',
                        name: 'Ground Floor Plan (29ft-11in × 75ft-2in)',
                        width: 9.12,
                        depth: 22.91
                      });
                      handleFloorChange('ground');
                      setViewMode('3d_axo');
                      setIsUploadModalOpen(false);
                      showToast('Loaded Ground Floor Blueprint in 3D!', '🚀');
                    }}
                  >
                    <img src="/blueprints/ground_floor_plan.jpg" alt="Ground Floor" className="ps-sample-thumb" />
                    <span className="ps-sample-name">Ground Floor Plan</span>
                    <span className="ps-sample-dims">29'-11" × 75'-2" (Drawing, Kitchen, Master)</span>
                  </button>

                  <button
                    type="button"
                    className="ps-sample-card"
                    onClick={() => {
                      setUploadedBlueprint({
                        imageUrl: '/blueprints/first_floor_plan.jpg',
                        name: 'First Floor Plan (29ft-11in × 75ft-2in)',
                        width: 9.12,
                        depth: 22.91
                      });
                      handleFloorChange('first');
                      setViewMode('3d_axo');
                      setIsUploadModalOpen(false);
                      showToast('Loaded First Floor Blueprint in 3D!', '🚀');
                    }}
                  >
                    <img src="/blueprints/first_floor_plan.jpg" alt="First Floor" className="ps-sample-thumb" />
                    <span className="ps-sample-name">First Floor Plan</span>
                    <span className="ps-sample-dims">29'-11" × 75'-2" (Family Lounge, Suites)</span>
                  </button>

                  <button
                    type="button"
                    className="ps-sample-card"
                    onClick={() => {
                      setUploadedBlueprint({
                        imageUrl: '/blueprints/stilt_floor_plan.png',
                        name: 'Stilt Floor Plan (29ft-11in × 75ft-2in)',
                        width: 9.12,
                        depth: 22.91
                      });
                      handleFloorChange('stilt');
                      setViewMode('3d_axo');
                      setIsUploadModalOpen(false);
                      showToast('Loaded Stilt Floor Blueprint in 3D!', '🚀');
                    }}
                  >
                    <img src="/blueprints/stilt_floor_plan.png" alt="Stilt Floor" className="ps-sample-thumb" />
                    <span className="ps-sample-name">Stilt Floor Plan</span>
                    <span className="ps-sample-dims">8-Car Covered Parking & Staff</span>
                  </button>

                  <button
                    type="button"
                    className="ps-sample-card"
                    onClick={() => {
                      setUploadedBlueprint({
                        imageUrl: '/blueprints/terrace_floor_plan.png',
                        name: 'Terrace Floor Plan (29ft-11in × 75ft-2in)',
                        width: 9.12,
                        depth: 22.91
                      });
                      handleFloorChange('terrace');
                      setViewMode('3d_axo');
                      setIsUploadModalOpen(false);
                      showToast('Loaded Terrace Pergola Blueprint in 3D!', '🚀');
                    }}
                  >
                    <img src="/blueprints/terrace_floor_plan.png" alt="Terrace Floor" className="ps-sample-thumb" />
                    <span className="ps-sample-name">Terrace Floor Plan</span>
                    <span className="ps-sample-dims">Timber Pergola & Open Party Deck</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ── IMMERSIVE 1:1 VR WALKTHROUGH MODE (SHOWS UPLOADED PLAN IN VR) ── */}
      {viewMode === 'vr_walk' && (
        <VRWalkthroughStudio
          rooms={rooms}
          furniture={furniture}
          columns={columns}
          customWalls={customWalls}
          uploadedBlueprint={uploadedBlueprint}
          buildingName={building.name}
          plotWidth={uploadedBlueprint?.width || building.plotWidth || 9.12}
          plotDepth={uploadedBlueprint?.depth || building.plotDepth || 22.91}
          timeOfDay={timeOfDay}
          ceilingMode={ceilingMode}
          renderStyle={renderStyle}
          onExitVR={() => setViewMode('3d_axo')}
        />
      )}

      {/* ── MOBILE RESPONSIVE BOTTOM NAVIGATION BAR ───────────────────── */}
      <div className="ps-mobile-nav">
        <button
          type="button"
          onClick={() => setViewMode('2d_blueprint')}
          className={`ps-mobile-nav-item ${viewMode === '2d_blueprint' ? 'active' : ''}`}
        >
          <PenTool size={15} />
          <span>2D Plan</span>
        </button>
        <button
          type="button"
          onClick={() => setViewMode('3d_axo')}
          className={`ps-mobile-nav-item ${viewMode === '3d_axo' ? 'active' : ''}`}
        >
          <BoxIcon size={15} />
          <span>3D Model</span>
        </button>
        <button
          type="button"
          onClick={() => setViewMode('split_view')}
          className={`ps-mobile-nav-item ${viewMode === 'split_view' ? 'active' : ''}`}
        >
          <Layers2 size={15} />
          <span>Split</span>
        </button>
        <button
          type="button"
          onClick={() => setViewMode('vr_walk')}
          className={`ps-mobile-nav-item gold ${viewMode === 'vr_walk' ? 'active' : ''}`}
        >
          <Eye size={15} />
          <span>VR Walk</span>
        </button>
        <button
          type="button"
          onClick={() => setIsLeftDrawerOpen(true)}
          className="ps-mobile-nav-item"
        >
          <Plus size={15} />
          <span>Catalog</span>
        </button>
        <button
          type="button"
          onClick={() => setIsPresetsModalOpen(true)}
          className="ps-mobile-nav-item"
        >
          <Building size={15} />
          <span>Presets</span>
        </button>
        <button
          type="button"
          onClick={() => setIsUploadModalOpen(true)}
          className="ps-mobile-nav-item"
        >
          <UploadCloud size={15} />
          <span>Import</span>
        </button>
      </div>

      {/* ── 1-CLICK ARCHITECTURAL PRESETS MODAL (OPENPLAN3D DESIGN ENGINE) ── */}
      {isPresetsModalOpen && (
        <div className="ps-modal-backdrop" onClick={() => setIsPresetsModalOpen(false)}>
          <div className="ps-modal-card" onClick={(e) => e.stopPropagation()} style={{ maxWidth: '820px' }}>
            <div className="ps-modal-header">
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <Building size={20} color="#fae8a4" />
                <div>
                  <span className="ps-modal-title">Curated Architectural 3D Presets</span>
                  <span style={{ display: 'block', fontSize: '11px', color: '#94a3b8' }}>Load industry-grade 2D & 3D floor plans with 1 click</span>
                </div>
              </div>
              <button type="button" onClick={() => setIsPresetsModalOpen(false)} className="ps-modal-close"><X size={18} /></button>
            </div>

            <div className="ps-modal-body" style={{ display: 'flex', flexDirection: 'column', gap: '14px', maxHeight: '72vh', overflowY: 'auto' }}>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '14px' }}>
                {ARCHITECTURAL_PRESETS.map((preset) => (
                  <div
                    key={preset.id}
                    className="ps-preset-card"
                    style={{
                      background: '#091322',
                      border: '1px solid rgba(250, 232, 164, 0.22)',
                      borderRadius: '12px',
                      padding: '16px',
                      display: 'flex',
                      flexDirection: 'column',
                      justifyContent: 'space-between',
                      transition: 'all 0.2s ease'
                    }}
                  >
                    <div>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '8px' }}>
                        <span style={{ fontSize: '10px', background: 'rgba(0, 240, 255, 0.12)', color: '#00f0ff', padding: '2px 8px', borderRadius: '4px', fontWeight: 700 }}>
                          {preset.badge}
                        </span>
                        {preset.areaSqFt > 0 && (
                          <span style={{ fontSize: '10.5px', color: '#fae8a4', fontFamily: 'monospace', fontWeight: 600 }}>
                            {preset.areaSqFt.toLocaleString()} sq.ft
                          </span>
                        )}
                      </div>

                      <h4 style={{ margin: '0 0 6px', fontSize: '14px', color: '#f8fafc', fontWeight: 700 }}>
                        {preset.name}
                      </h4>
                      <p style={{ margin: '0 0 12px', fontSize: '11.5px', color: '#94a3b8', lineHeight: '1.45' }}>
                        {preset.desc}
                      </p>

                      <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap', marginBottom: '14px' }}>
                        <span style={{ fontSize: '10px', color: '#cbd5e1', background: 'rgba(255, 255, 255, 0.05)', padding: '2px 6px', borderRadius: '3px' }}>
                          📐 {preset.rooms.length} Rooms
                        </span>
                        <span style={{ fontSize: '10px', color: '#cbd5e1', background: 'rgba(255, 255, 255, 0.05)', padding: '2px 6px', borderRadius: '3px' }}>
                          🛋️ {preset.furniture.length} 3D Items
                        </span>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleLoadPreset(preset)}
                      className="ps-pill-btn gold"
                      style={{ width: '100%', justifyContent: 'center', padding: '9px', fontWeight: 600 }}
                    >
                      <span>Load Architectural Model</span>
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ── FIRST-TIME USER ONBOARDING & WELCOME MODAL ─────────────────── */}
      {isWelcomeModalOpen && (
        <div
          className="ps-modal-backdrop"
          onClick={() => {
            localStorage.setItem('wtp_seen_guide_v3', 'true');
            setIsWelcomeModalOpen(false);
          }}
        >
          <div className="ps-modal-card ps-welcome-modal" onClick={(e) => e.stopPropagation()} style={{ maxWidth: '680px' }}>
            <div className="ps-modal-header">
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <Sparkles size={22} color="#00f0ff" />
                <div>
                  <span className="ps-modal-title">Welcome to 1:1 Scale 3D Architectural Studio</span>
                  <span style={{ display: 'block', fontSize: '11px', color: '#94a3b8' }}>Professional 2D CAD Drafting & Real-Time 3D Spatial Walkthrough Engine</span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  localStorage.setItem('wtp_seen_guide_v3', 'true');
                  setIsWelcomeModalOpen(false);
                }}
                className="ps-modal-close"
              >
                <X size={18} />
              </button>
            </div>

            <div className="ps-modal-body" style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
              <span style={{ fontSize: '13px', color: '#cbd5e1', lineHeight: '1.5' }}>
                Design, customize, and walk inside your architectural floor plans in real-time 3D or at life-size 1:1 human scale before construction begins.
              </span>

              {/* 4 Interactive Feature Highlights */}
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))', gap: '10px' }}>
                <div style={{ background: '#091322', border: '1px solid rgba(0, 240, 255, 0.25)', borderRadius: '10px', padding: '12px' }}>
                  <div style={{ fontSize: '20px', marginBottom: '4px' }}>📐</div>
                  <strong style={{ fontSize: '12px', color: '#00f0ff', display: 'block', marginBottom: '2px' }}>1. Draft or Pick Preset</strong>
                  <span style={{ fontSize: '11px', color: '#94a3b8' }}>Draw walls with angle snap or choose a 1-click designer preset.</span>
                </div>

                <div style={{ background: '#091322', border: '1px solid rgba(250, 232, 164, 0.25)', borderRadius: '10px', padding: '12px' }}>
                  <div style={{ fontSize: '20px', marginBottom: '4px' }}>🚪</div>
                  <strong style={{ fontSize: '12px', color: '#fae8a4', display: 'block', marginBottom: '2px' }}>2. Snap Doors & Furnish</strong>
                  <span style={{ fontSize: '11px', color: '#94a3b8' }}>Snap doors and windows into walls; place 3D furniture from 8 categories.</span>
                </div>

                <div style={{ background: '#091322', border: '1px solid rgba(52, 211, 153, 0.25)', borderRadius: '10px', padding: '12px' }}>
                  <div style={{ fontSize: '20px', marginBottom: '4px' }}>🏛️</div>
                  <strong style={{ fontSize: '12px', color: '#34d399', display: 'block', marginBottom: '2px' }}>3. Real-Time 3D & Walk</strong>
                  <span style={{ fontSize: '11px', color: '#94a3b8' }}>Instant 3D conversion, split view, or 1:1 eye-level walkthrough.</span>
                </div>

                <div style={{ background: '#091322', border: '1px solid rgba(168, 85, 247, 0.25)', borderRadius: '10px', padding: '12px' }}>
                  <div style={{ fontSize: '20px', marginBottom: '4px' }}>✨</div>
                  <strong style={{ fontSize: '12px', color: '#c084fc', display: 'block', marginBottom: '2px' }}>4. Materials & Sun</strong>
                  <span style={{ fontSize: '11px', color: '#94a3b8' }}>Apply luxury Italian marble, oak flooring, and adjust sun daylighting.</span>
                </div>
              </div>

              {/* Quick Keyboard Hotkey Cheat Sheet */}
              <div style={{ background: '#050c18', border: '1px solid rgba(255, 255, 255, 0.08)', borderRadius: '10px', padding: '12px' }}>
                <span style={{ fontSize: '11px', fontWeight: 700, color: '#fae8a4', display: 'block', marginBottom: '8px' }}>
                  ⌨️ Quick Hotkeys & Touch Shortcuts
                </span>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(130px, 1fr))', gap: '6px', fontSize: '11px', color: '#94a3b8' }}>
                  <div><kbd style={{ background: '#1e293b', color: '#f8fafc', padding: '2px 5px', borderRadius: '3px' }}>V</kbd> Select Tool</div>
                  <div><kbd style={{ background: '#1e293b', color: '#f8fafc', padding: '2px 5px', borderRadius: '3px' }}>W</kbd> Draw Wall</div>
                  <div><kbd style={{ background: '#1e293b', color: '#f8fafc', padding: '2px 5px', borderRadius: '3px' }}>D</kbd> Add Door</div>
                  <div><kbd style={{ background: '#1e293b', color: '#f8fafc', padding: '2px 5px', borderRadius: '3px' }}>R</kbd> Rotate Item</div>
                  <div><kbd style={{ background: '#1e293b', color: '#f8fafc', padding: '2px 5px', borderRadius: '3px' }}>Space</kbd> Toggle 2D / 3D</div>
                  <div><kbd style={{ background: '#1e293b', color: '#f8fafc', padding: '2px 5px', borderRadius: '3px' }}>Del</kbd> Delete Item</div>
                </div>
              </div>

              {/* Action Buttons */}
              <div style={{ display: 'flex', gap: '10px', marginTop: '4px', flexWrap: 'wrap' }}>
                <button
                  type="button"
                  onClick={() => {
                    localStorage.setItem('wtp_seen_guide_v3', 'true');
                    setIsWelcomeModalOpen(false);
                    setIsPresetsModalOpen(true);
                  }}
                  className="ps-pill-btn gold"
                  style={{ flex: 1, minWidth: '160px', padding: '10px', justifyContent: 'center' }}
                >
                  <Building size={15} />
                  <span>Explore 1-Click Templates</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    localStorage.setItem('wtp_seen_guide_v3', 'true');
                    setIsWelcomeModalOpen(false);
                    setViewMode('2d_blueprint');
                    setActiveTool('draw_wall');
                  }}
                  className="ps-pill-btn"
                  style={{ flex: 1, minWidth: '160px', padding: '10px', justifyContent: 'center', borderColor: '#00f0ff', color: '#00f0ff' }}
                >
                  <PenTool size={15} />
                  <span>Draw From Scratch (W)</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    localStorage.setItem('wtp_seen_guide_v3', 'true');
                    setIsWelcomeModalOpen(false);
                    setIsUploadModalOpen(true);
                  }}
                  className="ps-pill-btn"
                  style={{ flex: 1, minWidth: '160px', padding: '10px', justifyContent: 'center' }}
                >
                  <UploadCloud size={15} />
                  <span>Import RoomPlan / CAD</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ── MODALS (VASTU, CLEARANCE, BOQ, HELP) ─────────────────────── */}
      {/* 1. Vastu Shastra Audit Modal */}
      {isVastuModalOpen && (
        <div className="ps-modal-backdrop" onClick={() => setIsVastuModalOpen(false)}>
          <div className="ps-modal-card" onClick={(e) => e.stopPropagation()}>
            <div className="ps-modal-header">
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <Sparkle size={20} color="#fae8a4" />
                <span className="ps-modal-title">Vastu Shastra Architectural Audit</span>
              </div>
              <button type="button" onClick={() => setIsVastuModalOpen(false)} className="ps-modal-close"><X size={18} /></button>
            </div>
            <div className="ps-modal-body">
              <div className="ps-score-hero">
                <span className="ps-score-num">{vastuResult.score}%</span>
                <span className="ps-score-label">Vastu Purusha Harmony Score</span>
                <p className="ps-score-sub">Architecturally aligned with ancient Vedic geometry for solar daylight and energy flow.</p>
              </div>
              <div className="ps-audit-list">
                {vastuResult.reports.map((item) => (
                  <div key={item.id} className="ps-audit-card pass">
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <span className="ps-audit-zone">{item.zone}</span>
                      <span className="ps-audit-tag">{item.score}</span>
                    </div>
                    <span className="ps-audit-card-title">{item.title}</span>
                    <p className="ps-audit-card-text">{item.text}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 2. Clearance & Ergonomics Audit Modal */}
      {isClearanceModalOpen && (
        <div className="ps-modal-backdrop" onClick={() => setIsClearanceModalOpen(false)}>
          <div className="ps-modal-card" onClick={(e) => e.stopPropagation()}>
            <div className="ps-modal-header">
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <ShieldCheck size={20} color="#38bdf8" />
                <span className="ps-modal-title">Ergonomics & Clearance Safety Check</span>
              </div>
              <button type="button" onClick={() => setIsClearanceModalOpen(false)} className="ps-modal-close"><X size={18} /></button>
            </div>
            <div className="ps-modal-body">
              {clearanceAlerts.length === 0 ? (
                <div style={{ textAlign: 'center', padding: '30px', color: '#10b981' }}>
                  <CheckCircle2 size={40} style={{ margin: '0 auto 12px' }} />
                  <p style={{ fontWeight: 700, fontSize: '16px' }}>All Clearances Meet NBC Standards!</p>
                  <p style={{ color: '#94a3b8', fontSize: '13px' }}>Corridors exceed 3'-0" (0.9m) and door swings are unhindered.</p>
                </div>
              ) : (
                <div className="ps-audit-list">
                  {clearanceAlerts.map((a) => (
                    <div key={a.id} className={`ps-audit-card ${a.severity}`}>
                      <span className="ps-audit-card-title">{a.title}</span>
                      <p className="ps-audit-card-text">{a.text}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* 3. Upgraded Industry-Grade Bill of Quantities (BOQ) Modal with Excel Export */}
      {isBoqModalOpen && (
        <div className="ps-modal-backdrop" onClick={() => setIsBoqModalOpen(false)}>
          <div className="ps-modal-card ps-boq-modal" onClick={(e) => e.stopPropagation()}>
            <div className="ps-modal-header">
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <FileSpreadsheet size={20} color="#fae8a4" />
                <span className="ps-modal-title">Bill of Quantities (BOQ) & Civil Estimator</span>
              </div>
              <button type="button" onClick={() => setIsBoqModalOpen(false)} className="ps-modal-close"><X size={18} /></button>
            </div>
            <div className="ps-modal-body">
              {/* 4 High-Precision KPI Metrics */}
              <div className="ps-boq-kpi-grid">
                <div className="ps-boq-kpi-card">
                  <span className="ps-kpi-label">Built-Up Area</span>
                  <span className="ps-kpi-val">{boqData.builtUpSqFt.toLocaleString()} sq.ft</span>
                  <span className="ps-kpi-sub">{boqData.builtUpSqM} m² total footprint</span>
                </div>
                <div className="ps-boq-kpi-card">
                  <span className="ps-kpi-label">Usable Carpet Area</span>
                  <span className="ps-kpi-val">{boqData.carpetSqFt.toLocaleString()} sq.ft</span>
                  <span className="ps-kpi-sub">{boqData.carpetSqM} m² living spaces</span>
                </div>
                <div className="ps-boq-kpi-card gold">
                  <span className="ps-kpi-label">Turnkey Project Estimate</span>
                  <span className="ps-kpi-val">₹{boqData.costTotalCrores} Cr</span>
                  <span className="ps-kpi-sub">₹{boqData.ratePerSqFt.toLocaleString()} / sq.ft</span>
                </div>
                <div className="ps-boq-kpi-card savings">
                  <span className="ps-kpi-label">Verified Savings with 1:1 Projection</span>
                  <span className="ps-kpi-val">₹{boqData.savingsLakhs} Lakhs</span>
                  <span className="ps-kpi-sub">Saved in avoided change-orders</span>
                </div>
              </div>

              {/* Walk The Plan Savings Banner */}
              <div className="ps-boq-savings-banner">
                <Sparkles size={18} color="#34d399" />
                <span>
                  <strong>Industry-Beating Advantage:</strong> Walking your floor plan at 1:1 true scale and projecting onto your plot eliminates 92% of on-site wall relocations, plumbing reroutes, and demolition reworks.
                </span>
              </div>

              {/* Complete Trade Cost Breakdown Table */}
              <div style={{ marginTop: '16px' }}>
                <span style={{ fontSize: '12px', fontWeight: 700, color: '#f8fafc', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                  Trade-Wise Civil & Interiors Cost Breakdown
                </span>
                <table className="ps-boq-table">
                  <thead>
                    <tr>
                      <th>Trade / Item Description</th>
                      <th>Coverage / Scope</th>
                      <th>Benchmark Rate</th>
                      <th>Total Amount (INR)</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>Civil Structure & RCC Foundation (Columns, Beams, Slabs)</td>
                      <td>{boqData.builtUpSqFt.toLocaleString()} sq.ft</td>
                      <td>₹1,650 / sq.ft</td>
                      <td>₹{(boqData.costStructure / 100000).toFixed(2)} Lakhs</td>
                    </tr>
                    <tr>
                      <td>Masonry & Brickwork (External 9" & Internal 4.5" AAC blocks)</td>
                      <td>{boqData.builtUpSqFt.toLocaleString()} sq.ft</td>
                      <td>₹450 / sq.ft</td>
                      <td>₹{(boqData.costMasonry / 100000).toFixed(2)} Lakhs</td>
                    </tr>
                    <tr>
                      <td>Luxury Flooring & Skirting (Italian Marble & Engineered Wood)</td>
                      <td>{boqData.carpetSqFt.toLocaleString()} sq.ft</td>
                      <td>₹380 / sq.ft</td>
                      <td>₹{(boqData.costFinishes / 100000).toFixed(2)} Lakhs</td>
                    </tr>
                    <tr>
                      <td>Wall Finishes & Architectural Emulsion (POP Punning + Primer)</td>
                      <td>{boqData.builtUpSqFt.toLocaleString()} sq.ft</td>
                      <td>₹180 / sq.ft</td>
                      <td>₹{(boqData.costPaint / 100000).toFixed(2)} Lakhs</td>
                    </tr>
                    <tr>
                      <td>MEP & Smart Home Conduiting (Concealed FRLS Copper Wiring)</td>
                      <td>{boqData.builtUpSqFt.toLocaleString()} sq.ft</td>
                      <td>₹240 / sq.ft</td>
                      <td>₹{(boqData.costMEP / 100000).toFixed(2)} Lakhs</td>
                    </tr>
                    <tr>
                      <td>Plumbing & Sanitaryware (CPVC Lines, Grohe/Kohler Luxury Fixtures)</td>
                      <td>{boqData.builtUpSqFt.toLocaleString()} sq.ft</td>
                      <td>₹190 / sq.ft</td>
                      <td>₹{(boqData.costPlumbing / 100000).toFixed(2)} Lakhs</td>
                    </tr>
                    <tr>
                      <td>UPVC & Acoustic Glazing (Soundproof Double Glazed Windows)</td>
                      <td>{boqData.builtUpSqFt.toLocaleString()} sq.ft</td>
                      <td>₹280 / sq.ft</td>
                      <td>₹{(boqData.costFenestration / 100000).toFixed(2)} Lakhs</td>
                    </tr>
                    <tr>
                      <td>Custom Interior Woodwork (Wardrobes, Modular Kitchen & TV units)</td>
                      <td>{boqData.builtUpSqFt.toLocaleString()} sq.ft</td>
                      <td>₹550 / sq.ft</td>
                      <td>₹{(boqData.costInterior / 100000).toFixed(2)} Lakhs</td>
                    </tr>
                    <tr>
                      <td>Placed Modular Furniture Pieces ({furniture.length} items configured)</td>
                      <td>{furniture.length} units</td>
                      <td>Catalog Market Rate</td>
                      <td>₹{(boqData.furnitureValue / 100000).toFixed(2)} Lakhs</td>
                    </tr>
                    <tr className="total-row">
                      <td colSpan="3">Total Estimated Turnkey Civil & Interior Value</td>
                      <td>₹{boqData.costTotalCrores} Crores</td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* Material Quantities Takeoff Estimation */}
              <div style={{ marginTop: '20px' }}>
                <span style={{ fontSize: '12px', fontWeight: 700, color: '#f8fafc', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                  Raw Materials Takeoff (Estimated Quantities)
                </span>
                <div className="ps-boq-materials-grid">
                  <div className="ps-material-card">
                    <span className="ps-mat-name">Cement</span>
                    <span className="ps-mat-val">{boqData.cementBags.toLocaleString()} Bags</span>
                    <span className="ps-mat-spec">Ultratech / ACC 53-Grade</span>
                  </div>
                  <div className="ps-material-card">
                    <span className="ps-mat-name">Reinforcement Steel</span>
                    <span className="ps-mat-val">{boqData.steelTonnes} Tonnes</span>
                    <span className="ps-mat-spec">Tata Tiscon / Jindal Fe550D TMT</span>
                  </div>
                  <div className="ps-material-card">
                    <span className="ps-mat-name">Masonry Bricks/Blocks</span>
                    <span className="ps-mat-val">{boqData.bricksUnits.toLocaleString()} Units</span>
                    <span className="ps-mat-spec">Standard Red Clay / Autoclaved AAC</span>
                  </div>
                  <div className="ps-material-card">
                    <span className="ps-mat-name">M-Sand / River Sand</span>
                    <span className="ps-mat-val">{boqData.sandCuFt.toLocaleString()} cu.ft</span>
                    <span className="ps-mat-spec">Washed plastering sand</span>
                  </div>
                  <div className="ps-material-card">
                    <span className="ps-mat-name">Coarse Aggregates</span>
                    <span className="ps-mat-val">{boqData.aggregateCuFt.toLocaleString()} cu.ft</span>
                    <span className="ps-mat-spec">20mm & 10mm graded granite blue metal</span>
                  </div>
                </div>
              </div>

              {/* Export Button */}
              <div style={{ marginTop: '20px', display: 'flex', justifyContent: 'flex-end', gap: '10px' }}>
                <button
                  type="button"
                  onClick={() => {
                    exportBOQToExcel(boqData, building.name, initialFloor.name);
                    showToast('Exported Detailed BOQ (.xlsx)', '📊');
                  }}
                  className="ps-btn-gold"
                >
                  <Download size={14} />
                  <span>Download Professional Excel BOQ (.xlsx)</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 4. Help & Shortcuts Modal */}
      {isHelpOpen && (
        <div className="ps-modal-backdrop" onClick={() => setIsHelpOpen(false)}>
          <div className="ps-modal-card" onClick={(e) => e.stopPropagation()}>
            <div className="ps-modal-header">
              <span className="ps-modal-title">Walk The Plan · 1:1 Studio Guide</span>
              <button type="button" onClick={() => setIsHelpOpen(false)} className="ps-modal-close"><X size={18} /></button>
            </div>
            <div className="ps-modal-body">
              <p style={{ color: '#cbd5e1', lineHeight: '1.6' }}>
                Welcome to <strong>Walk The Plan's 1:1 Scale Architectural Projection Studio</strong>.
                Step inside blueprints at true life-size, test furniture clearances, and inspect multi-floor CAD drawings before laying a single brick.
              </p>
              <div style={{ marginTop: '16px', display: 'flex', flexDirection: 'column', gap: '10px' }}>
                <div className="ps-help-item">
                  <strong>Move & Resize:</strong> In 2D CAD Blueprint view, drag furniture to move it. Select any room to drag its center handle or resize its walls via corner and edge handles!
                </div>
                <div className="ps-help-item">
                  <strong>Keyboard Shortcuts:</strong> Arrow keys nudge selected item (Shift+Arrows for 0.5m), 'R' rotates furniture, 'Delete' removes item, 'Esc' deselects, Ctrl+Z / Ctrl+Y for undo/redo.
                </div>
                <div className="ps-help-item">
                  <strong>3D Land Plot Projector:</strong> Select real plot dimensions (30'x60', 40'x60', etc.) and watch the 3D laser projector beam map the blueprint onto real land.
                </div>
                <div className="ps-help-item">
                  <strong>Industry-Beating BOQ:</strong> Real-time material takeoff and Excel export comparing actual costs against traditional contractor estimates.
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Toast Notification */}
      {toastMessage && (
        <div className="ps-toast">
          <span className="ps-toast-icon">{toastMessage.icon}</span>
          <span>{toastMessage.msg}</span>
        </div>
      )}
    </div>
  );
}
