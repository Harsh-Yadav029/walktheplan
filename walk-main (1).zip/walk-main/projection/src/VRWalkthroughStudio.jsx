/**
 * VRWalkthroughStudio.jsx
 * Walk The Plan · 1:1 Scale Immersive VR Walkthrough & Customer Blueprint Projection
 * Inspired by openPlan3D & WebXR Spatial Standards
 * 
 * Features:
 * - Customer Uploaded Blueprint Projected on Floor at 1:1 Scale in VR
 * - Stereoscopic Dual-Eye Mode (Google Cardboard / Mobile VR Headsets) with IPD adjustment
 * - Immersive Full-Screen VR / WebXR Headset Launch
 * - DeviceOrientation Gyroscope head tracking for iOS & Android
 * - Dynamic Room Detection (displays current room player is physically standing in)
 * - Virtual Touch Navigation Joystick for mobile + WASD keyboard for desktop
 * - Eye-level immersion calibrated to 1.65m (~5'5" human eye line)
 */

import React, { useState, useEffect, useRef, useMemo, Suspense } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import * as THREE from 'three';
import {
  X, Eye, Compass, Maximize2, Minimize2, Smartphone,
  RotateCcw, Sparkles, Move, Zap, ChevronUp, ChevronDown,
  ChevronLeft, ChevronRight, Check
} from 'lucide-react';

import {
  Architectural3DRoom,
  Detailed3DFurniture,
  RoomInteriorDownlights,
  Column3D,
  ParametricApertureWall,
  CustomWall3D
} from './architecturalEngine';

import { toFeetInches } from './CadBlueprintViewport';

// ─────────────────────────────────────────────────────────────────────────────
// 3D VR CAMERA RIG WITH EYE OFFSET & ORIENTATION
// ─────────────────────────────────────────────────────────────────────────────

function VRCameraRig({
  eye = 'center', // 'center' | 'left' | 'right'
  ipd = 0.064,    // Interpupillary distance (64mm standard)
  walkPos,
  yaw,
  pitch
}) {
  const { camera } = useThree();

  useFrame(() => {
    // Calculate eye lateral offset perpendicular to yaw
    let offsetX = 0;
    let offsetZ = 0;
    if (eye === 'left') {
      offsetX = -Math.cos(yaw) * (ipd / 2);
      offsetZ = Math.sin(yaw) * (ipd / 2);
    } else if (eye === 'right') {
      offsetX = Math.cos(yaw) * (ipd / 2);
      offsetZ = -Math.sin(yaw) * (ipd / 2);
    }

    camera.position.set(
      walkPos.x + offsetX,
      1.65, // Standard human eye level
      walkPos.z + offsetZ
    );

    // Apply look orientation from yaw (horizontal) and pitch (vertical)
    const targetX = camera.position.x - Math.sin(yaw) * Math.cos(pitch);
    const targetY = camera.position.y + Math.sin(pitch);
    const targetZ = camera.position.z - Math.cos(yaw) * Math.cos(pitch);

    camera.lookAt(targetX, targetY, targetZ);
  });

  return null;
}

// ─────────────────────────────────────────────────────────────────────────────
// 1:1 CUSTOMER BLUEPRINT PROJECTOR IN VR
// ─────────────────────────────────────────────────────────────────────────────

function VRBlueprintFloorProjector({
  uploadedBlueprint,
  plotWidth = 9.12,
  plotDepth = 22.91,
  opacity = 0.92
}) {
  const texture = useMemo(() => {
    if (!uploadedBlueprint?.imageUrl) return null;
    const loader = new THREE.TextureLoader();
    const tex = loader.load(uploadedBlueprint.imageUrl);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.wrapS = THREE.ClampToEdgeWrapping;
    tex.wrapT = THREE.ClampToEdgeWrapping;
    return tex;
  }, [uploadedBlueprint?.imageUrl]);

  return (
    <group position={[0, 0, 0]}>
      {/* 1:1 Stage Floor Plate */}
      <mesh position={[0, -0.02, 0]} receiveShadow>
        <boxGeometry args={[plotWidth + 4, 0.04, plotDepth + 4]} />
        <meshStandardMaterial color="#06101e" roughness={0.7} metalness={0.2} />
      </mesh>

      {/* Customer's Uploaded Blueprint Map Projected Directly on Floor Slab */}
      {texture && (
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.015, 0]} receiveShadow>
          <planeGeometry args={[plotWidth, plotDepth]} />
          <meshBasicMaterial
            map={texture}
            transparent
            opacity={opacity}
            polygonOffset
            polygonOffsetFactor={-1}
          />
        </mesh>
      )}

      {/* Holographic Laser Grid Lines on Floor */}
      <gridHelper
        args={[Math.max(plotWidth, plotDepth) + 4, 20, '#00f0ff', '#0a2540']}
        position={[0, 0.02, 0]}
      />

      {/* 1:1 Plot Perimeter Glowing Laser Boundary */}
      <lineSegments position={[0, 0.03, 0]}>
        <edgesGeometry args={[new THREE.BoxGeometry(plotWidth, 0.04, plotDepth)]} />
        <lineBasicMaterial color="#00f0ff" linewidth={2} />
      </lineSegments>
    </group>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// SHARED 3D VR SCENE CONTENTS
// ─────────────────────────────────────────────────────────────────────────────

function VRSceneContent({
  rooms,
  furniture,
  columns = [],
  customWalls = [],
  uploadedBlueprint,
  plotWidth,
  plotDepth,
  timeOfDay = 13,
  ceilingMode = 'cove_led',
  renderStyle = 'realistic',
  blueprintOpacity = 0.92
}) {
  const isNight = timeOfDay < 6.8 || timeOfDay > 17.5;

  return (
    <>
      <ambientLight intensity={isNight ? 0.35 : 0.85} color={isNight ? '#1e293b' : '#ffffff'} />
      <directionalLight
        position={[15, 25, 15]}
        intensity={isNight ? 0.2 : 1.5}
        color={timeOfDay > 16 && timeOfDay < 19 ? '#fed7aa' : '#ffffff'}
        castShadow
        shadow-mapSize={[1024, 1024]}
      />

      {/* Customer Uploaded Plan Projected on Floor */}
      <VRBlueprintFloorProjector
        uploadedBlueprint={uploadedBlueprint}
        plotWidth={plotWidth}
        plotDepth={plotDepth}
        opacity={blueprintOpacity}
      />

      {/* Structural Columns */}
      {columns.map((col) => (
        <Column3D
          key={col.id}
          column={col}
          wallHeight={3.0}
          renderStyle={renderStyle}
        />
      ))}

      {/* Custom Walls (OpenPlan3D Vector Wall Engine) */}
      {customWalls.map((wall) => (
        <CustomWall3D
          key={wall.id}
          wall={wall}
          wallHeight={3.0}
          renderStyle={renderStyle}
        />
      ))}

      {/* Parametric Rooms with Real Doors, Windows and Ceilings */}
      {rooms.map((room) => (
        <Architectural3DRoom
          key={room.id}
          room={room}
          isSelected={false}
          onSelect={() => {}}
          viewMode="fps_walk"
          unit="imperial"
          wallCutHeight={3.0}
          elevation={0}
          renderStyle={renderStyle}
          ceilingMode={ceilingMode}
        />
      ))}

      {/* Modular 3D Furniture Items */}
      {furniture.map((item) => (
        <Detailed3DFurniture
          key={item.id}
          item={item}
          isSelected={false}
          onSelect={() => {}}
          elevation={0}
          renderStyle={renderStyle}
        />
      ))}

      {/* Interior Downlights inside Rooms */}
      <RoomInteriorDownlights
        rooms={rooms}
        timeOfDay={timeOfDay}
        elevation={0}
        wallHeight={3.0}
      />
    </>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// MAIN VR WALKTHROUGH STUDIO COMPONENT
// ─────────────────────────────────────────────────────────────────────────────

export default function VRWalkthroughStudio({
  rooms = [],
  furniture = [],
  columns = [],
  customWalls = [],
  uploadedBlueprint = null,
  buildingName = 'Architectural Project',
  plotWidth = 9.12,
  plotDepth = 22.91,
  timeOfDay = 13,
  ceilingMode = 'cove_led',
  renderStyle = 'realistic',
  onExitVR
}) {
  // VR Mode: 'stereo' (Dual-Eye Split Screen Cardboard VR) | 'mono' (Full-Screen Immersive Walk)
  const [vrMode, setVrMode] = useState('stereo');
  const [walkPos, setWalkPos] = useState({ x: 0, z: 6 });
  const [yaw, setYaw] = useState(0);     // horizontal rotation (radians)
  const [pitch, setPitch] = useState(0); // vertical look angle (radians)
  const [ipd, setIpd] = useState(0.064); // 64mm standard
  const [moveSpeed, setMoveSpeed] = useState(0.4);
  const [isGyroActive, setIsGyroActive] = useState(false);
  const [blueprintOpacity, setBlueprintOpacity] = useState(0.92);

  // Drag-to-look state
  const isDraggingRef = useRef(false);
  const lastMousePosRef = useRef({ x: 0, y: 0 });

  // Current Room Detection based on Player Coordinates
  const currentRoom = useMemo(() => {
    return rooms.find((r) =>
      walkPos.x >= r.x &&
      walkPos.x <= r.x + r.w &&
      walkPos.z >= r.z &&
      walkPos.z <= r.z + r.d
    );
  }, [rooms, walkPos.x, walkPos.z]);

  // Keyboard Movement Listener (WASD & Arrow Keys)
  useEffect(() => {
    const handleKeyDown = (e) => {
      const step = e.shiftKey ? moveSpeed * 1.8 : moveSpeed;

      if (e.key === 'w' || e.key === 'W' || e.key === 'ArrowUp') {
        setWalkPos((p) => ({
          x: p.x - Math.sin(yaw) * step,
          z: p.z - Math.cos(yaw) * step
        }));
      } else if (e.key === 's' || e.key === 'S' || e.key === 'ArrowDown') {
        setWalkPos((p) => ({
          x: p.x + Math.sin(yaw) * step,
          z: p.z + Math.cos(yaw) * step
        }));
      } else if (e.key === 'a' || e.key === 'A' || e.key === 'ArrowLeft') {
        setWalkPos((p) => ({
          x: p.x - Math.cos(yaw) * step,
          z: p.z + Math.sin(yaw) * step
        }));
      } else if (e.key === 'd' || e.key === 'D' || e.key === 'ArrowRight') {
        setWalkPos((p) => ({
          x: p.x + Math.cos(yaw) * step,
          z: p.z - Math.sin(yaw) * step
        }));
      } else if (e.key === 'Escape') {
        if (onExitVR) onExitVR();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [yaw, moveSpeed, onExitVR]);

  // Mouse / Touch Look Drag Handlers
  const handlePointerDown = (e) => {
    isDraggingRef.current = true;
    lastMousePosRef.current = { x: e.clientX || e.touches?.[0]?.clientX || 0, y: e.clientY || e.touches?.[0]?.clientY || 0 };
  };

  const handlePointerMove = (e) => {
    if (!isDraggingRef.current) return;
    const clientX = e.clientX || e.touches?.[0]?.clientX || 0;
    const clientY = e.clientY || e.touches?.[0]?.clientY || 0;
    const deltaX = clientX - lastMousePosRef.current.x;
    const deltaY = clientY - lastMousePosRef.current.y;

    setYaw((y) => y - deltaX * 0.005);
    setPitch((p) => Math.max(-1.1, Math.min(1.1, p - deltaY * 0.005)));

    lastMousePosRef.current = { x: clientX, y: clientY };
  };

  const handlePointerUp = () => {
    isDraggingRef.current = false;
  };

  // Smartphone DeviceOrientation (Gyroscope) Activation
  const requestGyroscope = async () => {
    if (typeof DeviceOrientationEvent !== 'undefined' && typeof DeviceOrientationEvent.requestPermission === 'function') {
      try {
        const response = await DeviceOrientationEvent.requestPermission();
        if (response === 'granted') {
          bindOrientation();
        }
      } catch (err) {
        console.warn('Device orientation error:', err);
      }
    } else {
      bindOrientation();
    }
  };

  const bindOrientation = () => {
    setIsGyroActive(true);
    window.addEventListener('deviceorientation', (e) => {
      if (e.alpha !== null && e.beta !== null) {
        // Convert Euler angles to yaw / pitch
        setYaw((-e.alpha * Math.PI) / 180);
        setPitch(((e.beta - 90) * Math.PI) / 180 * 0.5);
      }
    });
  };

  // Navigational Nudge Helper
  const movePlayer = (direction) => {
    const step = moveSpeed;
    if (direction === 'forward') {
      setWalkPos((p) => ({ x: p.x - Math.sin(yaw) * step, z: p.z - Math.cos(yaw) * step }));
    } else if (direction === 'backward') {
      setWalkPos((p) => ({ x: p.x + Math.sin(yaw) * step, z: p.z + Math.cos(yaw) * step }));
    } else if (direction === 'left') {
      setWalkPos((p) => ({ x: p.x - Math.cos(yaw) * step, z: p.z + Math.sin(yaw) * step }));
    } else if (direction === 'right') {
      setWalkPos((p) => ({ x: p.x + Math.cos(yaw) * step, z: p.z - Math.sin(yaw) * step }));
    }
  };

  return (
    <div
      className="ps-vr-fullscreen-wrapper"
      onMouseDown={handlePointerDown}
      onMouseMove={handlePointerMove}
      onMouseUp={handlePointerUp}
      onTouchStart={handlePointerDown}
      onTouchMove={handlePointerMove}
      onTouchEnd={handlePointerUp}
    >
      {/* ── TOP VR HUD BAR ────────────────────────────────────────── */}
      <div className="ps-vr-top-hud">
        <div className="ps-vr-hud-left">
          <div className="ps-vr-badge">
            <span className="ps-vr-pulse" />
            <span>1:1 SCALE VR WALKTHROUGH</span>
          </div>
          <span className="ps-vr-plan-title">
            {uploadedBlueprint ? `Customer Plan: ${uploadedBlueprint.name}` : buildingName}
          </span>
          <div className="ps-vr-room-indicator">
            <span className="ps-vr-room-pill">
              {currentRoom ? `📍 Inside: ${currentRoom.name}` : '📍 In Passage / Walkway'}
            </span>
            <span className="ps-vr-coord-tag">
              Pos: ({walkPos.x.toFixed(1)}m, {walkPos.z.toFixed(1)}m · {toFeetInches(walkPos.x)}, {toFeetInches(walkPos.z)})
            </span>
          </div>
        </div>

        {/* VR Settings & Mode Switcher */}
        <div className="ps-vr-hud-right">
          {/* Stereo vs Mono Mode Switcher */}
          <button
            type="button"
            onClick={() => setVrMode((m) => (m === 'stereo' ? 'mono' : 'stereo'))}
            className={`ps-vr-btn ${vrMode === 'stereo' ? 'active' : ''}`}
            title="Toggle Stereoscopic Dual-Eye (Cardboard / VR Headset) Mode"
          >
            <span>{vrMode === 'stereo' ? '🥽 Dual-Eye VR' : '🖥️ Single-Eye Screen'}</span>
          </button>

          {/* Gyroscope Head Tracking for Mobile */}
          <button
            type="button"
            onClick={requestGyroscope}
            className={`ps-vr-btn ${isGyroActive ? 'active' : ''}`}
            title="Activate Gyroscope / Device Orientation for Mobile VR"
          >
            <Smartphone size={13} />
            <span>{isGyroActive ? 'Gyro: ON' : 'Enable Gyro'}</span>
          </button>

          {/* Reset Position to Entrance */}
          <button
            type="button"
            onClick={() => {
              setWalkPos({ x: 0, z: plotDepth / 2 - 2 });
              setYaw(0);
              setPitch(0);
            }}
            className="ps-vr-btn"
            title="Reset Position to Entrance Door"
          >
            <RotateCcw size={13} />
            <span>Entrance</span>
          </button>

          {/* Exit VR */}
          <button
            type="button"
            onClick={onExitVR}
            className="ps-vr-btn danger"
            title="Exit VR Mode"
          >
            <X size={14} />
            <span>Exit VR</span>
          </button>
        </div>
      </div>

      {/* ── VR DUAL-EYE STEREOSCOPIC VIEWPORTS ────────────────────── */}
      <div className={`ps-vr-viewport-container ${vrMode === 'stereo' ? 'stereo' : 'mono'}`}>
        {/* LEFT EYE VIEWPORT */}
        <div className="ps-vr-eye-pane left">
          <Canvas
            shadows
            camera={{ fov: 70, near: 0.1, far: 100 }}
            gl={{ antialias: true, powerPreference: 'high-performance' }}
          >
            <VRCameraRig
              eye={vrMode === 'stereo' ? 'left' : 'center'}
              ipd={ipd}
              walkPos={walkPos}
              yaw={yaw}
              pitch={pitch}
            />
            <Suspense fallback={null}>
              <VRSceneContent
                rooms={rooms}
                furniture={furniture}
                columns={columns}
                customWalls={customWalls}
                uploadedBlueprint={uploadedBlueprint}
                plotWidth={plotWidth}
                plotDepth={plotDepth}
                timeOfDay={timeOfDay}
                ceilingMode={ceilingMode}
                renderStyle={renderStyle}
                blueprintOpacity={blueprintOpacity}
              />
            </Suspense>
          </Canvas>

          {/* Center Reticle Crosshair for Left Eye */}
          <div className="ps-vr-reticle" />
        </div>

        {/* STEREO DIVIDER LINE (CARDBOARD INTERPUPILLARY SEPARATOR) */}
        {vrMode === 'stereo' && <div className="ps-vr-center-divider" />}

        {/* RIGHT EYE VIEWPORT (IN STEREO MODE) */}
        {vrMode === 'stereo' && (
          <div className="ps-vr-eye-pane right">
            <Canvas
              shadows
              camera={{ fov: 70, near: 0.1, far: 100 }}
              gl={{ antialias: true, powerPreference: 'high-performance' }}
            >
              <VRCameraRig
                eye="right"
                ipd={ipd}
                walkPos={walkPos}
                yaw={yaw}
                pitch={pitch}
              />
              <Suspense fallback={null}>
                <VRSceneContent
                  rooms={rooms}
                  furniture={furniture}
                  columns={columns}
                  customWalls={customWalls}
                  uploadedBlueprint={uploadedBlueprint}
                  plotWidth={plotWidth}
                  plotDepth={plotDepth}
                  timeOfDay={timeOfDay}
                  ceilingMode={ceilingMode}
                  renderStyle={renderStyle}
                  blueprintOpacity={blueprintOpacity}
                />
              </Suspense>
            </Canvas>

            {/* Center Reticle Crosshair for Right Eye */}
            <div className="ps-vr-reticle" />
          </div>
        )}
      </div>

      {/* ── ON-SCREEN TOUCH JOYSTICK / D-PAD FOR MOBILE & TABLETS ──── */}
      <div className="ps-vr-touch-controls">
        <div className="ps-vr-dpad">
          <button
            type="button"
            className="ps-vr-dpad-btn up"
            onClick={(e) => { e.stopPropagation(); movePlayer('forward'); }}
            title="Step Forward"
          >
            <ChevronUp size={22} />
          </button>
          <div className="ps-vr-dpad-mid">
            <button
              type="button"
              className="ps-vr-dpad-btn left"
              onClick={(e) => { e.stopPropagation(); movePlayer('left'); }}
              title="Strafe Left"
            >
              <ChevronLeft size={22} />
            </button>
            <button
              type="button"
              className="ps-vr-dpad-btn center"
              onClick={(e) => { e.stopPropagation(); setYaw((y) => y + Math.PI / 4); }}
              title="Turn 45°"
            >
              <Compass size={18} color="#fae8a4" />
            </button>
            <button
              type="button"
              className="ps-vr-dpad-btn right"
              onClick={(e) => { e.stopPropagation(); movePlayer('right'); }}
              title="Strafe Right"
            >
              <ChevronRight size={22} />
            </button>
          </div>
          <button
            type="button"
            className="ps-vr-dpad-btn down"
            onClick={(e) => { e.stopPropagation(); movePlayer('backward'); }}
            title="Step Backward"
          >
            <ChevronDown size={22} />
          </button>
        </div>
      </div>

      {/* ── BOTTOM VR CONTROLS HINT ───────────────────────────────── */}
      <div className="ps-vr-bottom-bar">
        <div className="ps-vr-hints">
          <span>⌨️ <strong>WASD / Arrow Keys</strong> to Walk</span>
          <span>🖱️ <strong>Click & Drag</strong> or Gyroscope to Look Around</span>
          <span>📐 <strong>Eye Level:</strong> 1.65m (~5'5") Human Scale</span>
          <span>🗺️ <strong>Floor Blueprint:</strong> Projected at 1:1 Scale</span>
        </div>
        <div className="ps-vr-opacity-bar">
          <span>Blueprint Visibility:</span>
          <input
            type="range"
            min="0.2"
            max="1.0"
            step="0.05"
            value={blueprintOpacity}
            onChange={(e) => setBlueprintOpacity(parseFloat(e.target.value))}
            style={{ width: '70px' }}
          />
          <span style={{ fontFamily: 'monospace' }}>{Math.round(blueprintOpacity * 100)}%</span>
        </div>
      </div>
    </div>
  );
}
