/**
 * exporters.js
 * Comprehensive 3D Model & Floor Plan Export Engine
 * Compatible with FloorPlan-3D-OpenSource, AutoCAD, Blender, SketchUp, Revit
 */

import { OBJExporter } from 'three/examples/jsm/exporters/OBJExporter.js';
import { GLTFExporter } from 'three/examples/jsm/exporters/GLTFExporter.js';
import { downloadFile } from './ProjectionStudio';

/**
 * Export complete 3D scene / group to standard Wavefront .OBJ file
 */
export function exportSceneToOBJ(sceneOrGroup, buildingName = 'ArchitecturalModel', floorTitle = 'ActiveFloor') {
  if (!sceneOrGroup) {
    throw new Error('No 3D scene available for OBJ export.');
  }

  const exporter = new OBJExporter();
  const objResult = exporter.parse(sceneOrGroup);
  const cleanName = `${buildingName}_${floorTitle}`.replace(/[^a-zA-Z0-9_-]/g, '_');
  const fileName = `WalkThePlan_${cleanName}_3D.obj`;

  downloadFile(objResult, fileName, 'text/plain;charset=utf-8');
  return fileName;
}

/**
 * Export complete 3D scene / group to standard .GLTF / .GLB file
 */
export function exportSceneToGLTF(sceneOrGroup, buildingName = 'ArchitecturalModel', floorTitle = 'ActiveFloor') {
  return new Promise((resolve, reject) => {
    if (!sceneOrGroup) {
      return reject(new Error('No 3D scene available for GLTF export.'));
    }

    const exporter = new GLTFExporter();
    exporter.parse(
      sceneOrGroup,
      (gltf) => {
        const output = typeof gltf === 'string' ? gltf : JSON.stringify(gltf, null, 2);
        const cleanName = `${buildingName}_${floorTitle}`.replace(/[^a-zA-Z0-9_-]/g, '_');
        const fileName = `WalkThePlan_${cleanName}_3D.gltf`;
        downloadFile(output, fileName, 'model/gltf+json;charset=utf-8');
        resolve(fileName);
      },
      (error) => {
        reject(error);
      },
      { binary: false }
    );
  });
}

/**
 * Export complete project structure to FloorPlan-3D compatible JSON file
 */
export function exportProjectJSON(data, buildingName = 'FloorPlan_Project') {
  const exportPayload = {
    generator: 'WalkThePlan 1:1 Projection & 3D Architectural Studio',
    version: '2.5.0',
    exportTimestamp: new Date().toISOString(),
    building: {
      name: data.buildingName || 'Architectural Design',
      plotWidth: data.plotWidth || 9.12,
      plotDepth: data.plotDepth || 22.91,
      unit: data.unit || 'imperial'
    },
    activeFloor: data.activeFloorKey || 'ground',
    rooms: data.rooms || [],
    walls: data.walls || [],
    openings: data.openings || [],
    columns: data.columns || [],
    furniture: data.furniture || [],
    settings: {
      timeOfDay: data.timeOfDay || 12,
      renderStyle: data.renderStyle || 'realistic',
      ceilingMode: data.ceilingMode || 'cove_led',
      wallCutMode: data.wallCutMode || 'full'
    }
  };

  const jsonString = JSON.stringify(exportPayload, null, 2);
  const cleanName = (data.buildingName || buildingName).replace(/[^a-zA-Z0-9_-]/g, '_');
  const fileName = `WalkThePlan_${cleanName}_FullDesign.json`;

  downloadFile(jsonString, fileName, 'application/json;charset=utf-8');
  return fileName;
}

/**
 * Capture high-resolution PNG snapshot from WebGL Canvas
 */
export function captureCanvasSnapshot(canvasElement, buildingName = 'RenderSnapshot') {
  if (!canvasElement) {
    throw new Error('Canvas element not found for snapshot.');
  }

  const dataUrl = canvasElement.toDataURL('image/png', 1.0);
  const cleanName = buildingName.replace(/[^a-zA-Z0-9_-]/g, '_');
  const fileName = `WalkThePlan_${cleanName}_${Date.now()}.png`;

  const link = document.createElement('a');
  link.href = dataUrl;
  link.download = fileName;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  return fileName;
}
