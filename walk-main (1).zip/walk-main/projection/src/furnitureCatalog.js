/**
 * furnitureCatalog.js
 * Comprehensive Architectural Furniture, Fixtures & Equipment (FF&E) Library
 * Categorized for instant placement and 2D/3D BIM design
 */

export const EXTENDED_FURNITURE_CATALOG = [
  // ── LIVING ROOM ──
  {
    type: 'sofa',
    name: 'Italian 3-Seater Leather Sofa',
    category: 'Living',
    w: 2.8,
    d: 1.0,
    h: 0.85,
    clearance: 0.9,
    color: '#1e3a5f',
    tag: 'Plush Luxury',
    icon: 'Sofa'
  },
  {
    type: 'sofa_sectional',
    name: 'Contemporary L-Shaped Sectional',
    category: 'Living',
    w: 3.2,
    d: 2.2,
    h: 0.85,
    clearance: 1.0,
    color: '#334155',
    tag: 'Grand Lounge',
    icon: 'Sofa'
  },
  {
    type: 'sofa_2seat',
    name: '2-Seater Accent Lounge Sofa',
    category: 'Living',
    w: 1.8,
    d: 0.9,
    h: 0.82,
    clearance: 0.85,
    color: '#475569',
    tag: 'Compact',
    icon: 'Sofa'
  },
  {
    type: 'table',
    name: 'Calacatta Marble Coffee Table',
    category: 'Living',
    w: 1.3,
    d: 0.8,
    h: 0.45,
    clearance: 0.6,
    color: '#cbd5e1',
    tag: 'Centerpiece',
    icon: 'Table'
  },
  {
    type: 'indoor_plant',
    name: 'Monstera Potted Architectural Plant',
    category: 'Living',
    w: 0.7,
    d: 0.7,
    h: 1.4,
    clearance: 0.3,
    color: '#15803d',
    tag: 'Biophilic Green',
    icon: 'Trees'
  },
  {
    type: 'media_wall_unit',
    name: '4K OLED TV & Acoustic Fluted Media Wall',
    category: 'Living',
    w: 2.4,
    d: 0.45,
    h: 1.8,
    clearance: 0.7,
    color: '#1a1410',
    tag: 'Entertainment',
    icon: 'Tv'
  },
  {
    type: 'lounge_chair',
    name: 'Scandinavian Curved Lounge Armchair',
    category: 'Living',
    w: 0.85,
    d: 0.85,
    h: 0.8,
    clearance: 0.6,
    color: '#334155',
    tag: 'Designer Seating',
    icon: 'Armchair'
  },
  {
    type: 'floor_lamp',
    name: 'Brass Arched Floor Lamp & Downlight',
    category: 'Decor & Lighting',
    w: 0.5,
    d: 0.5,
    h: 1.8,
    clearance: 0.3,
    color: '#d4af37',
    tag: 'Warm Lighting',
    icon: 'Lightbulb'
  },

  // ── BEDROOM ──
  {
    type: 'bed_king',
    name: 'Grand Master King Bed (6\'-9" × 6\'-6")',
    category: 'Bedroom',
    w: 2.1,
    d: 2.0,
    h: 1.0,
    clearance: 0.9,
    color: '#2a3547',
    tag: 'King Suite',
    icon: 'Bed'
  },
  {
    type: 'bed_queen',
    name: 'Queen Bed with Hydraulic Lift Base',
    category: 'Bedroom',
    w: 1.8,
    d: 2.1,
    h: 0.9,
    clearance: 0.85,
    color: '#334155',
    tag: 'Comfort Queen',
    icon: 'Bed'
  },
  {
    type: 'wardrobe',
    name: '4-Door Floor-to-Ceiling Wardrobe',
    category: 'Bedroom',
    w: 2.4,
    d: 0.65,
    h: 2.4,
    clearance: 0.9,
    color: '#192231',
    tag: 'Built-in Closet',
    icon: 'Archive'
  },

  // ── DINING ──
  {
    type: 'dining_set',
    name: '8-Seat Solid Teak Dining Suite',
    category: 'Dining',
    w: 2.4,
    d: 1.2,
    h: 0.78,
    clearance: 1.0,
    color: '#b45309',
    tag: 'Teakwood Set',
    icon: 'Utensils'
  },

  // ── KITCHEN ──
  {
    type: 'kitchen_island',
    name: 'Cooking Island with Waterfall Quartz',
    category: 'Kitchen',
    w: 2.4,
    d: 1.0,
    h: 0.92,
    clearance: 1.0,
    color: '#0369a1',
    tag: 'Quartz Island',
    icon: 'Box'
  },
  {
    type: 'kitchen_fridge',
    name: 'French-Door Smart Refrigerator',
    category: 'Kitchen',
    w: 0.95,
    d: 0.85,
    h: 1.85,
    clearance: 0.8,
    color: '#64748b',
    tag: 'Appliance',
    icon: 'Box'
  },
  {
    type: 'kitchen_cooktop',
    name: 'Island Induction Cooktop & Chimney Hood',
    category: 'Kitchen',
    w: 1.2,
    d: 0.7,
    h: 2.4,
    clearance: 0.9,
    color: '#0f172a',
    tag: 'Island Cooking',
    icon: 'Flame'
  },

  // ── ARCHITECTURAL & STAIRS ──
  {
    type: 'staircase',
    name: 'Architectural Open-Tread Staircase with Glass Railing',
    category: 'Architectural',
    w: 1.1,
    d: 3.4,
    h: 3.0,
    clearance: 0.8,
    color: '#8c6d48',
    tag: 'Modern Stairs',
    icon: 'TrendingUp'
  },
  {
    type: 'patio_lounger',
    name: 'Teak Outdoor Sunbed & Deck Lounger',
    category: 'Outdoor',
    w: 0.8,
    d: 2.0,
    h: 0.45,
    clearance: 0.6,
    color: '#5c3a21',
    tag: 'Patio Living',
    icon: 'Sun'
  },

  // ── BATHROOM ──
  {
    type: 'bath_vanity',
    name: 'Floating Double Vanity with Vessel Sinks',
    category: 'Bathroom',
    w: 1.6,
    d: 0.55,
    h: 0.85,
    clearance: 0.7,
    color: '#0f172a',
    tag: 'LED Mirror',
    icon: 'Droplet'
  },
  {
    type: 'luxury_bathtub',
    name: 'Freestanding Oval Soaking Tub',
    category: 'Bathroom',
    w: 1.7,
    d: 0.85,
    h: 0.65,
    clearance: 0.7,
    color: '#f8fafc',
    tag: 'Luxury Bath',
    icon: 'Bath'
  },

  // ── OFFICE & WORK ──
  {
    type: 'desk',
    name: 'Executive Acoustic Workstation & Chair',
    category: 'Office',
    w: 1.6,
    d: 0.8,
    h: 0.75,
    clearance: 0.8,
    color: '#1e3a5f',
    tag: 'Ergonomic Desk',
    icon: 'Briefcase'
  },

  // ── VEHICLES & GARAGE ──
  {
    type: 'car_sedan',
    name: 'Executive Luxury Sedan',
    category: 'Vehicles',
    w: 1.9,
    d: 4.6,
    h: 1.5,
    clearance: 0.6,
    color: '#334155',
    tag: "8'×16' Stall",
    icon: 'Car'
  },
  {
    type: 'car_suv',
    name: 'Full-Size Luxury SUV',
    category: 'Vehicles',
    w: 2.0,
    d: 4.8,
    h: 1.7,
    clearance: 0.6,
    color: '#0369a1',
    tag: "8'×16' Stall",
    icon: 'Car'
  }
];

export const ARCHITECTURAL_DOOR_STYLES = [
  { id: 'single', name: 'Standard Flush Timber Door', w: 0.9, h: 2.1, desc: '900mm (3\'-0") wide internal door' },
  { id: 'french_glass', name: 'Double French Glass Door', w: 1.8, h: 2.2, desc: '1800mm (6\'-0") wide patio or balcony door' },
  { id: 'sliding', name: 'Sliding Cavity Glass Door', w: 1.5, h: 2.1, desc: 'Pocket sliding space-saving door' },
  { id: 'archway', name: 'Open Cased Archway Opening', w: 1.2, h: 2.4, desc: 'Open passage without door leaf' }
];

export const ARCHITECTURAL_WINDOW_STYLES = [
  { id: 'casement', name: 'Standard Casement Glazed Window', w: 1.4, h: 1.2, sillH: 0.9, desc: '1400mm × 1200mm (4\'-7" × 4\'-0")' },
  { id: 'picture', name: 'Floor-to-Ceiling Picture Window', w: 2.4, h: 2.2, sillH: 0.1, desc: 'Full-height panoramic curtain glass' },
  { id: 'slider', name: 'Double Sliding Aluminum Window', w: 1.8, h: 1.2, sillH: 0.9, desc: '1800mm × 1200mm (6\'-0" × 4\'-0")' },
  { id: 'ventilator', name: 'High Clerestory / Toilet Ventilator', w: 0.8, h: 0.6, sillH: 2.0, desc: 'High wall louvered exhaust window' }
];

export const STRUCTURAL_COLUMN_TYPES = [
  { id: 'square_col', name: 'RCC Square Column (400mm × 400mm)', shape: 'square', size: 0.4 },
  { id: 'round_col', name: 'Circular Architectural Pillar (Ø 400mm)', shape: 'round', size: 0.4 }
];
