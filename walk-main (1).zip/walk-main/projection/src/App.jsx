import React, { Suspense } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import ProjectionStudio from './ProjectionStudio';

export default function App() {
  return (
    <Router>
      <Suspense fallback={<div style={{ background: '#0a0a0c', height: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#f59e0b', fontFamily: 'monospace' }}>Loading 1:1 Projection Studio...</div>}>
        <Routes>
          <Route path="/projection" element={<ProjectionStudio />} />
          <Route path="/" element={<Navigate to="/projection" replace />} />
          <Route path="*" element={<Navigate to="/projection" replace />} />
        </Routes>
      </Suspense>
    </Router>
  );
}
