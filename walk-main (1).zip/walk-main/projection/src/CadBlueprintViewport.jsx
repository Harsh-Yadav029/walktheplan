/**
 * CadBlueprintViewport.jsx
 * Walk The Plan · 2D Architectural CAD Blueprint Viewport & Drafting Engine
 * Inspired by professional CAD & FloorPlan-3D-OpenSource
 * 
 * Features:
 * - Interactive Wall Drawing (Angle Snapping 0°/45°/90°, Live Distance HUD, Room Closure Detection)
 * - Door & Window Placement Tool (Snaps to Room Wall Edges with Live Swing Arc / Mullion Glazing)
 * - Structural RCC Column Placement (Square / Round)
 * - Room Move & Resize Transform Handles
 * - Furniture Move & Rotate Handles with Clearance Rings
 * - Two-Point Tape Measurement Tool
 * - Pan & Smooth Zoom Controls
 * - Title Block & Plot Boundary Dimension Strings
 */

import React, { useRef, useState, useMemo } from 'react';
import {
  ZoomIn, ZoomOut, RotateCcw, Move, Ruler, PenTool,
  Plus, Check, X, ShieldAlert, Square, Circle, Scissors
} from 'lucide-react';

export function toFeetInches(meters) {
  if (meters === undefined || meters === null || isNaN(meters)) return "0'-0\"";
  const totalInches = Math.round(meters * 39.3701);
  const feet = Math.floor(totalInches / 12);
  const inches = totalInches % 12;
  return `${feet}'-${inches}"`;
}

export function formatDim(meters, unit) {
  if (unit === 'imperial') return toFeetInches(meters);
  return `${Number(meters).toFixed(2)}m`;
}

export function formatArea(sqM, unit) {
  if (!sqM || isNaN(sqM)) return '0 sq.ft';
  if (unit === 'imperial') return `${Math.round(sqM * 10.7639).toLocaleString()} sq.ft`;
  return `${Number(sqM).toFixed(1)} m²`;
}

export function CadBlueprintViewport({
  rooms = [],
  furniture = [],
  columns = [],
  customWalls = [],
  selectedRoomId = null,
  selectedFurnitureId = null,
  selectedOpeningId = null,
  selectedColumnId = null,
  selectedWallId = null,
  onSelectRoom,
  onSelectFurniture,
  onSelectOpening,
  onSelectColumn,
  onSelectWall,
  onUpdateFurniture,
  onUpdateRooms,
  onUpdateColumns,
  onUpdateCustomWalls,
  onCommitHistory,
  unit = 'imperial',
  activeTool = 'select',
  doorStyle = 'single',
  windowStyle = 'casement',
  columnShape = 'square',
  buildingName = 'Architectural Project',
  floorTitle = 'Floor Plan',
  plotWidth = 9.12,
  plotDepth = 22.91,
  showDimensions = true,
  showFurniture = true,
  showGrid = true,
  measurePoints = { p1: null, p2: null },
  onMeasureClick,
  uploadedBlueprint = null,
  showUnderlay = true,
  blueprintOpacity = 0.85
}) {
  const containerRef = useRef(null);
  const [zoom, setZoom] = useState(1.1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [isPanning, setIsPanning] = useState(false);
  const [startPan, setStartPan] = useState({ x: 0, y: 0 });

  // Interactive drag / resize state
  const [dragState, setDragState] = useState(null);
  const [dragFeedback, setDragFeedback] = useState(null);

  // Wall Drafting State
  const [wallDrawPoints, setWallDrawPoints] = useState([]);
  const [hoverMeter, setHoverMeter] = useState(null);

  const baseScale = 34; // pixels per meter
  const svgWidth = 1040;
  const svgHeight = 900;
  const centerX = svgWidth / 2 + pan.x;
  const centerY = svgHeight / 2 + pan.y;

  // Coordinate Conversion Helpers
  const screenToMeter = (clientX, clientY) => {
    if (!containerRef.current) return { x: 0, z: 0 };
    const rect = containerRef.current.getBoundingClientRect();
    const clickX = clientX - rect.left;
    const clickY = clientY - rect.top;
    const meterX = (clickX - centerX) / (baseScale * zoom);
    const meterZ = (clickY - centerY) / (baseScale * zoom);
    return {
      x: Math.round(meterX * 100) / 100,
      z: Math.round(meterZ * 100) / 100
    };
  };

  // Snapping & Wall Segment Calculations
  const getSnappedPoint = (rawX, rawZ) => {
    if (wallDrawPoints.length === 0) {
      return { x: Math.round(rawX * 20) / 20, z: Math.round(rawZ * 20) / 20, angle: 0, isClose: false };
    }

    const last = wallDrawPoints[wallDrawPoints.length - 1];
    const dx = rawX - last.x;
    const dz = rawZ - last.z;
    const dist = Math.hypot(dx, dz);

    // Check room closure snap (to first point)
    if (wallDrawPoints.length >= 3) {
      const first = wallDrawPoints[0];
      const distToFirst = Math.hypot(rawX - first.x, rawZ - first.z);
      if (distToFirst < 0.45) {
        return { x: first.x, z: first.z, angle: 0, isClose: true, dist };
      }
    }

    // Angle snapping (0°, 45°, 90°, 135°, 180°, etc.)
    const rawDeg = (Math.atan2(dz, dx) * 180 / Math.PI + 360) % 360;
    const snapDegs = [0, 45, 90, 135, 180, 225, 270, 315, 360];
    let closestDeg = snapDegs[0];
    let minDiff = 360;

    snapDegs.forEach((sd) => {
      const diff = Math.abs(rawDeg - sd);
      if (diff < minDiff) {
        minDiff = diff;
        closestDeg = sd % 360;
      }
    });

    if (minDiff < 8) {
      const rad = (closestDeg * Math.PI) / 180;
      return {
        x: Math.round((last.x + Math.cos(rad) * dist) * 20) / 20,
        z: Math.round((last.z + Math.sin(rad) * dist) * 20) / 20,
        angle: closestDeg,
        isClose: false,
        dist
      };
    }

    return {
      x: Math.round(rawX * 20) / 20,
      z: Math.round(rawZ * 20) / 20,
      angle: Math.round(rawDeg),
      isClose: false,
      dist
    };
  };

  // Find Nearest Room Wall Edge for Door/Window Placement
  const findNearestRoomEdge = (mx, mz) => {
    let nearest = null;
    let minDist = 1.2; // max snap threshold

    rooms.forEach((r) => {
      // 1. North Edge: z = r.z, x in [r.x, r.x + r.w]
      const dNorth = Math.abs(mz - r.z);
      if (dNorth < minDist && mx >= r.x && mx <= r.x + r.w) {
        minDist = dNorth;
        nearest = { roomId: r.id, room: r, side: 'north', offset: mx - r.x };
      }
      // 2. South Edge: z = r.z + r.d, x in [r.x, r.x + r.w]
      const dSouth = Math.abs(mz - (r.z + r.d));
      if (dSouth < minDist && mx >= r.x && mx <= r.x + r.w) {
        minDist = dSouth;
        nearest = { roomId: r.id, room: r, side: 'south', offset: mx - r.x };
      }
      // 3. West Edge: x = r.x, z in [r.z, r.z + r.d]
      const dWest = Math.abs(mx - r.x);
      if (dWest < minDist && mz >= r.z && mz <= r.z + r.d) {
        minDist = dWest;
        nearest = { roomId: r.id, room: r, side: 'west', offset: mz - r.z };
      }
      // 4. East Edge: x = r.x + r.w, z in [r.z, r.z + r.d]
      const dEast = Math.abs(mx - (r.x + r.w));
      if (dEast < minDist && mz >= r.z && mz <= r.z + r.d) {
        minDist = dEast;
        nearest = { roomId: r.id, room: r, side: 'east', offset: mz - r.z };
      }
    });

    return nearest;
  };

  // ── MOUSE EVENT HANDLERS ──────────────────────────────────────────

  const handleWheel = (e) => {
    e.preventDefault();
    const factor = e.deltaY < 0 ? 1.08 : 0.92;
    setZoom((z) => Math.max(0.4, Math.min(3.5, z * factor)));
  };

  const handleMouseDown = (e) => {
    if (activeTool !== 'select') return;
    if (e.target.closest('.ps-interactive-item') || e.target.closest('.ps-handle')) return;
    setIsPanning(true);
    setStartPan({ x: e.clientX - pan.x, y: e.clientY - pan.y });
  };

  const handleMouseMove = (e) => {
    if (isPanning) {
      setPan({ x: e.clientX - startPan.x, y: e.clientY - startPan.y });
      return;
    }

    const { x: rawX, z: rawZ } = screenToMeter(e.clientX, e.clientY);
    const snapped = getSnappedPoint(rawX, rawZ);
    setHoverMeter(snapped);

    if (!dragState) return;

    const deltaMetersX = (e.clientX - dragState.mouseStartX) / (baseScale * zoom);
    const deltaMetersZ = (e.clientY - dragState.mouseStartY) / (baseScale * zoom);

    if (dragState.type === 'furniture') {
      const snapX = Math.round((dragState.startX + deltaMetersX) * 20) / 20;
      const snapZ = Math.round((dragState.startZ + deltaMetersZ) * 20) / 20;
      if (onUpdateFurniture) {
        onUpdateFurniture((prev) =>
          prev.map((f) => (f.id === dragState.id ? { ...f, x: snapX, z: snapZ } : f))
        );
      }
      setDragFeedback(`X: ${snapX >= 0 ? '+' : ''}${snapX.toFixed(2)}m, Z: ${snapZ >= 0 ? '+' : ''}${snapZ.toFixed(2)}m (${toFeetInches(snapX)}, ${toFeetInches(snapZ)})`);
    } else if (dragState.type === 'room_move') {
      const snapX = Math.round((dragState.startX + deltaMetersX) * 20) / 20;
      const snapZ = Math.round((dragState.startZ + deltaMetersZ) * 20) / 20;
      if (onUpdateRooms) {
        onUpdateRooms((prev) =>
          prev.map((r) => (r.id === dragState.id ? { ...r, x: snapX, z: snapZ } : r))
        );
      }
      setDragFeedback(`Room Wall: (${snapX.toFixed(2)}m, ${snapZ.toFixed(2)}m)`);
    } else if (dragState.type === 'room_resize') {
      const { handle, startX, startZ, startW, startD } = dragState;
      let newX = startX;
      let newZ = startZ;
      let newW = startW;
      let newD = startD;

      if (handle.includes('e')) newW = Math.max(1.2, Math.round((startW + deltaMetersX) * 20) / 20);
      if (handle.includes('s')) newD = Math.max(1.2, Math.round((startD + deltaMetersZ) * 20) / 20);
      if (handle.includes('w')) {
        const potentialW = Math.max(1.2, Math.round((startW - deltaMetersX) * 20) / 20);
        newX = startX + (startW - potentialW);
        newW = potentialW;
      }
      if (handle.includes('n')) {
        const potentialD = Math.max(1.2, Math.round((startD - deltaMetersZ) * 20) / 20);
        newZ = startZ + (startD - potentialD);
        newD = potentialD;
      }

      if (onUpdateRooms) {
        onUpdateRooms((prev) =>
          prev.map((r) => (r.id === dragState.id ? { ...r, x: newX, z: newZ, w: newW, d: newD } : r))
        );
      }
      setDragFeedback(`Room Size: ${newW.toFixed(2)}m × ${newD.toFixed(2)}m (${toFeetInches(newW)} × ${toFeetInches(newD)})`);
    }
  };

  const lastTouchDistRef = useRef(null);
  const touchStartPosRef = useRef(null);

  const handleTouchStart = (e) => {
    if (e.touches.length === 2) {
      const dist = Math.hypot(
        e.touches[0].clientX - e.touches[1].clientX,
        e.touches[0].clientY - e.touches[1].clientY
      );
      lastTouchDistRef.current = dist;
      touchStartPosRef.current = {
        x: (e.touches[0].clientX + e.touches[1].clientX) / 2 - pan.x,
        y: (e.touches[0].clientY + e.touches[1].clientY) / 2 - pan.y
      };
    } else if (e.touches.length === 1 && activeTool === 'select') {
      const touch = e.touches[0];
      setStartPan({ x: touch.clientX - pan.x, y: touch.clientY - pan.y });
    }
  };

  const handleTouchMove = (e) => {
    if (e.touches.length === 2 && lastTouchDistRef.current) {
      const dist = Math.hypot(
        e.touches[0].clientX - e.touches[1].clientX,
        e.touches[0].clientY - e.touches[1].clientY
      );
      const factor = dist / lastTouchDistRef.current;
      setZoom((z) => Math.max(0.4, Math.min(3.5, z * factor)));
      lastTouchDistRef.current = dist;

      if (touchStartPosRef.current) {
        const midX = (e.touches[0].clientX + e.touches[1].clientX) / 2;
        const midY = (e.touches[0].clientY + e.touches[1].clientY) / 2;
        setPan({
          x: midX - touchStartPosRef.current.x,
          y: midY - touchStartPosRef.current.y
        });
      }
    } else if (e.touches.length === 1 && activeTool === 'select' && !dragState) {
      const touch = e.touches[0];
      setPan({ x: touch.clientX - startPan.x, y: touch.clientY - startPan.y });
    }
  };

  const handleTouchEnd = () => {
    lastTouchDistRef.current = null;
    touchStartPosRef.current = null;
  };

  const handleMouseUp = () => {
    if (isPanning) setIsPanning(false);
    if (dragState) {
      if (onCommitHistory) onCommitHistory(rooms, furniture);
      setDragState(null);
      setTimeout(() => setDragFeedback(null), 1400);
    }
  };

  const handleSvgClick = (e) => {
    const { x: rawX, z: rawZ } = screenToMeter(e.clientX, e.clientY);

    // 1. Tape Measure Tool
    if (activeTool === 'measure') {
      if (onMeasureClick) onMeasureClick({ x: rawX, z: rawZ });
      return;
    }

    // 2. Interactive Wall Drawing Tool
    if (activeTool === 'draw_wall') {
      const snapped = getSnappedPoint(rawX, rawZ);

      // Check room closure
      if (snapped.isClose && wallDrawPoints.length >= 3) {
        const xs = wallDrawPoints.map((p) => p.x);
        const zs = wallDrawPoints.map((p) => p.z);
        const minX = Math.min(...xs);
        const maxX = Math.max(...xs);
        const minZ = Math.min(...zs);
        const maxZ = Math.max(...zs);

        const newRoom = {
          id: `r_custom_${Date.now()}`,
          name: `Room ${rooms.length + 1}`,
          type: 'living',
          x: Math.round(minX * 20) / 20,
          z: Math.round(minZ * 20) / 20,
          w: Math.max(1.5, Math.round((maxX - minX) * 20) / 20),
          d: Math.max(1.5, Math.round((maxZ - minZ) * 20) / 20),
          h: 3.0,
          wallThick: 0.23,
          floorMat: 'floor_calacatta',
          wallMat: 'wall_pure_white',
          doorSide: 'open',
          openings: []
        };

        if (onUpdateRooms) {
          onUpdateRooms((prev) => [...prev, newRoom]);
          if (onCommitHistory) onCommitHistory([...rooms, newRoom], furniture);
        }
        setWallDrawPoints([]);
        return;
      }

      // Add wall node
      if (wallDrawPoints.length > 0) {
        const last = wallDrawPoints[wallDrawPoints.length - 1];
        const newSegment = {
          id: `w_${Date.now()}`,
          x1: last.x,
          z1: last.z,
          x2: snapped.x,
          z2: snapped.z,
          thick: 0.23,
          height: 3.0
        };
        if (onUpdateCustomWalls) {
          onUpdateCustomWalls((prev) => [...prev, newSegment]);
        }
      }
      setWallDrawPoints((prev) => [...prev, { x: snapped.x, z: snapped.z }]);
      return;
    }

    // 3. Add Door Tool (Snap to Nearest Wall Edge)
    if (activeTool === 'add_door') {
      const edge = findNearestRoomEdge(rawX, rawZ);
      if (edge && onUpdateRooms) {
        const newDoor = {
          id: `door_${Date.now()}`,
          type: 'door',
          style: doorStyle,
          side: edge.side,
          offset: Math.max(0.2, Math.round(edge.offset * 20) / 20),
          w: doorStyle === 'french_glass' ? 1.8 : 0.9,
          h: 2.1,
          swing: 'left'
        };
        onUpdateRooms((prev) =>
          prev.map((r) =>
            r.id === edge.roomId ? { ...r, openings: [...(r.openings || []), newDoor] } : r
          )
        );
        if (onCommitHistory) onCommitHistory(rooms, furniture);
      }
      return;
    }

    // 4. Add Window Tool (Snap to Nearest Wall Edge)
    if (activeTool === 'add_window') {
      const edge = findNearestRoomEdge(rawX, rawZ);
      if (edge && onUpdateRooms) {
        const newWin = {
          id: `win_${Date.now()}`,
          type: 'window',
          style: windowStyle,
          side: edge.side,
          offset: Math.max(0.2, Math.round(edge.offset * 20) / 20),
          w: windowStyle === 'picture' ? 2.4 : windowStyle === 'ventilator' ? 0.8 : 1.4,
          h: windowStyle === 'ventilator' ? 0.6 : 1.2,
          sillH: windowStyle === 'ventilator' ? 2.0 : windowStyle === 'picture' ? 0.1 : 0.9
        };
        onUpdateRooms((prev) =>
          prev.map((r) =>
            r.id === edge.roomId ? { ...r, openings: [...(r.openings || []), newWin] } : r
          )
        );
        if (onCommitHistory) onCommitHistory(rooms, furniture);
      }
      return;
    }

    // 5. Add Column Tool
    if (activeTool === 'add_column') {
      if (onUpdateColumns) {
        const newCol = {
          id: `col_${Date.now()}`,
          shape: columnShape,
          size: 0.4,
          x: Math.round(rawX * 20) / 20,
          z: Math.round(rawZ * 20) / 20
        };
        onUpdateColumns((prev) => [...prev, newCol]);
      }
      return;
    }
  };

  // Complete Wall Drawing Button
  const handleFinishWallDrawing = () => {
    setWallDrawPoints([]);
  };

  return (
    <div
      ref={containerRef}
      className="ps-cad-container"
      onWheel={handleWheel}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      onClick={handleSvgClick}
      style={{
        cursor:
          activeTool === 'measure'
            ? 'crosshair'
            : activeTool === 'draw_wall'
            ? 'crosshair'
            : activeTool === 'add_door' || activeTool === 'add_window' || activeTool === 'add_column'
            ? 'cell'
            : isPanning
            ? 'grabbing'
            : dragState
            ? 'grabbing'
            : 'grab'
      }}
    >
      {/* 2D Zoom / Pan Controls Overlay */}
      <div className="ps-cad-controls">
        <button type="button" onClick={() => setZoom((z) => Math.min(3.5, z * 1.2))} title="Zoom In">
          <ZoomIn size={15} />
        </button>
        <button type="button" onClick={() => setZoom((z) => Math.max(0.4, z / 1.2))} title="Zoom Out">
          <ZoomOut size={15} />
        </button>
        <button
          type="button"
          onClick={() => {
            setZoom(1.1);
            setPan({ x: 0, y: 0 });
          }}
          title="Reset View"
        >
          <RotateCcw size={15} />
        </button>
      </div>

      {/* Wall Drawing Floating Toolbar HUD */}
      {activeTool === 'draw_wall' && (
        <div className="ps-cad-drafting-hud">
          <div className="ps-drafting-info">
            <PenTool size={14} color="#00f0ff" />
            <span>
              {wallDrawPoints.length === 0
                ? 'Click anywhere to start drawing wall'
                : `Drawing wall: ${wallDrawPoints.length} vertices placed. Click to add next corner, or click start point to close room.`}
            </span>
          </div>
          {wallDrawPoints.length > 0 && (
            <button
              type="button"
              className="ps-drafting-btn"
              onClick={handleFinishWallDrawing}
            >
              <Check size={13} />
              <span>Finish Drawing</span>
            </button>
          )}
        </div>
      )}

      {/* Real-time Drag / Transform Coordinate Tooltip Badge */}
      {dragFeedback && (
        <div className="ps-cad-drag-badge">
          <Move size={13} color="#00f0ff" />
          <span>{dragFeedback}</span>
        </div>
      )}

      <svg
        className="ps-cad-svg"
        viewBox={`0 0 ${svgWidth} ${svgHeight}`}
        style={{ width: '100%', height: '100%' }}
      >
        <defs>
          <pattern id="cadGridSmall" width={baseScale * zoom} height={baseScale * zoom} patternUnits="userSpaceOnUse">
            <path d={`M ${baseScale * zoom} 0 L 0 0 0 ${baseScale * zoom}`} fill="none" stroke="#0a182b" strokeWidth="0.8" />
          </pattern>
          <pattern id="cadGridMajor" width={baseScale * zoom * 5} height={baseScale * zoom * 5} patternUnits="userSpaceOnUse">
            <path d={`M ${baseScale * zoom * 5} 0 L 0 0 0 ${baseScale * zoom * 5}`} fill="none" stroke="#0f294a" strokeWidth="1.2" />
          </pattern>
        </defs>

        {/* Background Grid */}
        <rect width={svgWidth} height={svgHeight} fill="#040a14" />
        {showGrid && (
          <>
            <rect width={svgWidth} height={svgHeight} fill="url(#cadGridSmall)" />
            <rect width={svgWidth} height={svgHeight} fill="url(#cadGridMajor)" />
          </>
        )}

        <g transform={`translate(${centerX}, ${centerY}) scale(${zoom})`}>
          {/* Plot Boundary Outer Glow */}
          <rect
            x={(-plotWidth / 2) * baseScale}
            y={(-plotDepth / 2) * baseScale}
            width={plotWidth * baseScale}
            height={plotDepth * baseScale}
            fill="#091322"
            stroke="#fae8a4"
            strokeWidth="3.5"
            strokeOpacity="0.85"
            rx="2"
          />

          {/* Uploaded Blueprint Architectural Underlay */}
          {uploadedBlueprint && showUnderlay && uploadedBlueprint.imageUrl && (
            <image
              href={uploadedBlueprint.imageUrl}
              x={(-plotWidth / 2) * baseScale}
              y={(-plotDepth / 2) * baseScale}
              width={plotWidth * baseScale}
              height={plotDepth * baseScale}
              opacity={blueprintOpacity !== undefined ? blueprintOpacity : 0.85}
              preserveAspectRatio="none"
              style={{ pointerEvents: 'none' }}
            />
          )}

          {/* Custom Drawn Walls (OpenPlan3D Vector Wall Engine) */}
          {customWalls.map((w) => {
            const isSelected = selectedWallId === w.id;
            const len = Math.hypot((w.x2 || 0) - (w.x1 || 0), (w.z2 || 0) - (w.z1 || 0));
            const midX = (((w.x1 || 0) + (w.x2 || 0)) / 2) * baseScale;
            const midY = (((w.z1 || 0) + (w.z2 || 0)) / 2) * baseScale;

            return (
              <g
                key={w.id}
                className="ps-interactive-item"
                style={{ cursor: activeTool === 'select' ? 'pointer' : 'default' }}
                onClick={(e) => {
                  if (activeTool === 'select') {
                    e.stopPropagation();
                    if (onSelectWall) onSelectWall(w);
                  }
                }}
              >
                {/* Thick Invisible Hit Area for Easy Touch / Click Selection */}
                <line
                  x1={w.x1 * baseScale}
                  y1={w.z1 * baseScale}
                  x2={w.x2 * baseScale}
                  y2={w.z2 * baseScale}
                  stroke="transparent"
                  strokeWidth={Math.max(18, (w.thick || 0.23) * baseScale + 12)}
                />

                {/* Visible Architectural Wall Core */}
                <line
                  x1={w.x1 * baseScale}
                  y1={w.z1 * baseScale}
                  x2={w.x2 * baseScale}
                  y2={w.z2 * baseScale}
                  stroke={isSelected ? '#00f0ff' : '#fae8a4'}
                  strokeWidth={Math.max(4, (w.thick || 0.23) * baseScale)}
                  strokeLinecap="round"
                />

                {/* Live Dimension Metric Tag */}
                {(isSelected || showDimensions) && len > 0.6 && (
                  <g transform={`translate(${midX}, ${midY})`}>
                    <rect
                      x="-34"
                      y="-10"
                      width="68"
                      height="20"
                      rx="3"
                      fill="#030812"
                      stroke={isSelected ? '#00f0ff' : '#64748b'}
                      strokeWidth="1"
                    />
                    <text
                      x="0"
                      y="4"
                      textAnchor="middle"
                      fill={isSelected ? '#00f0ff' : '#f8fafc'}
                      fontSize="9.5"
                      fontFamily="monospace"
                      fontWeight="600"
                    >
                      {formatDim(len, unit)}
                    </text>
                  </g>
                )}

                {/* Selected Corner Nodes */}
                {isSelected && (
                  <>
                    <circle cx={w.x1 * baseScale} cy={w.z1 * baseScale} r="5" fill="#00f0ff" stroke="#000" strokeWidth="1.5" />
                    <circle cx={w.x2 * baseScale} cy={w.z2 * baseScale} r="5" fill="#00f0ff" stroke="#000" strokeWidth="1.5" />
                  </>
                )}
              </g>
            );
          })}

          {/* Rooms Rendering with Live Openings & Handles */}
          {rooms.map((r) => {
            const rx = r.x * baseScale;
            const rz = r.z * baseScale;
            const rw = r.w * baseScale;
            const rd = r.d * baseScale;
            const isSelected = selectedRoomId === r.id;

            return (
              <g
                key={r.id}
                className="ps-interactive-item"
                onClick={(e) => {
                  if (activeTool === 'select') {
                    e.stopPropagation();
                    if (onSelectRoom) onSelectRoom(r);
                  }
                }}
                style={{ cursor: isSelected ? 'default' : 'pointer' }}
              >
                {/* Room Floor Fill */}
                <rect
                  x={rx}
                  y={rz}
                  width={rw}
                  height={rd}
                  fill={isSelected ? '#0369a1' : r.type === 'balcony' ? '#0f2942' : '#0c1b2f'}
                  fillOpacity={isSelected ? 0.75 : uploadedBlueprint && showUnderlay ? 0.25 : 0.88}
                  stroke={isSelected ? '#00f0ff' : '#fae8a4'}
                  strokeWidth={isSelected ? 3 : 2}
                  strokeDasharray={r.type === 'balcony' ? '4,4' : 'none'}
                />

                {/* Double-Line Wall Thickness */}
                <rect
                  x={rx + 2.5}
                  y={rz + 2.5}
                  width={rw - 5}
                  height={rd - 5}
                  fill="none"
                  stroke={isSelected ? '#00f0ff' : '#38bdf8'}
                  strokeWidth="1"
                  strokeOpacity="0.4"
                />

                {/* Architectural Openings on this Room (Doors & Windows) */}
                {(r.openings || []).map((op) => {
                  const opW = (op.w || 0.9) * baseScale;
                  const offsetPix = (op.offset || 0.5) * baseScale;

                  if (op.type === 'door') {
                    // Door Arc & Swing Leaf
                    let doorX = rx + offsetPix;
                    let doorY = rz;
                    if (op.side === 'south') { doorX = rx + offsetPix; doorY = rz + rd; }
                    if (op.side === 'west') { doorX = rx; doorY = rz + offsetPix; }
                    if (op.side === 'east') { doorX = rx + rw; doorY = rz + offsetPix; }

                    return (
                      <g key={op.id}>
                        {/* Door opening gap / sill */}
                        <line
                          x1={op.side === 'west' || op.side === 'east' ? doorX : doorX}
                          y1={op.side === 'west' || op.side === 'east' ? doorY : doorY}
                          x2={op.side === 'west' || op.side === 'east' ? doorX : doorX + opW}
                          y2={op.side === 'west' || op.side === 'east' ? doorY + opW : doorY}
                          stroke="#040a14"
                          strokeWidth="3.5"
                        />
                        {/* Door Swing Arc */}
                        <path
                          d={`M ${doorX} ${doorY} A ${opW} ${opW} 0 0 1 ${doorX + opW * 0.7} ${doorY + opW * 0.7}`}
                          fill="none"
                          stroke="#00f0ff"
                          strokeWidth="1.2"
                          strokeDasharray="2,2"
                        />
                        {/* Door Leaf Line */}
                        <line
                          x1={doorX}
                          y1={doorY}
                          x2={doorX + opW * 0.7}
                          y2={doorY + opW * 0.7}
                          stroke="#00f0ff"
                          strokeWidth="1.8"
                        />
                      </g>
                    );
                  }

                  if (op.type === 'window') {
                    // Window Triple-Line Glazing Symbol
                    let winX1 = rx + offsetPix;
                    let winY1 = rz;
                    let winX2 = rx + offsetPix + opW;
                    let winY2 = rz;

                    if (op.side === 'south') { winX1 = rx + offsetPix; winY1 = rz + rd; winX2 = rx + offsetPix + opW; winY2 = rz + rd; }
                    if (op.side === 'west') { winX1 = rx; winY1 = rz + offsetPix; winX2 = rx; winY2 = rz + offsetPix + opW; }
                    if (op.side === 'east') { winX1 = rx + rw; winY1 = rz + offsetPix; winX2 = rx + rw; winY2 = rz + offsetPix + opW; }

                    return (
                      <g key={op.id}>
                        {/* Window Aperture Cutout */}
                        <line x1={winX1} y1={winY1} x2={winX2} y2={winY2} stroke="#38bdf8" strokeWidth="4" />
                        {/* Window Glass Pane Line */}
                        <line x1={winX1} y1={winY1} x2={winX2} y2={winY2} stroke="#ffffff" strokeWidth="1.2" />
                      </g>
                    );
                  }

                  return null;
                })}

                {/* Legacy Door Swing Arc fallback */}
                {(!r.openings || r.openings.length === 0) && r.doorSide === 'west' && (
                  <g>
                    <path
                      d={`M ${rx} ${rz + 15} A 24 24 0 0 1 ${rx + 24} ${rz + 39}`}
                      fill="none"
                      stroke="#00f0ff"
                      strokeWidth="1.2"
                      strokeDasharray="2,2"
                    />
                    <line x1={rx} y1={rz + 15} x2={rx + 24} y2={rz + 15} stroke="#00f0ff" strokeWidth="1.5" />
                  </g>
                )}
                {(!r.openings || r.openings.length === 0) && r.doorSide === 'east' && (
                  <g>
                    <path
                      d={`M ${rx + rw} ${rz + 15} A 24 24 0 0 0 ${rx + rw - 24} ${rz + 39}`}
                      fill="none"
                      stroke="#00f0ff"
                      strokeWidth="1.2"
                      strokeDasharray="2,2"
                    />
                    <line x1={rx + rw} y1={rz + 15} x2={rx + rw - 24} y2={rz + 15} stroke="#00f0ff" strokeWidth="1.5" />
                  </g>
                )}
                {(!r.openings || r.openings.length === 0) && r.doorSide === 'south' && (
                  <g>
                    <path
                      d={`M ${rx + rw / 2} ${rz + rd} A 24 24 0 0 1 ${rx + rw / 2 + 24} ${rz + rd - 24}`}
                      fill="none"
                      stroke="#00f0ff"
                      strokeWidth="1.2"
                      strokeDasharray="2,2"
                    />
                  </g>
                )}

                {/* Elevator Shaft Crossed Diagonals [X] */}
                {r.type === 'lift' && (
                  <g>
                    <line x1={rx} y1={rz} x2={rx + rw} y2={rz + rd} stroke="#fae8a4" strokeWidth="1.5" strokeDasharray="3,3" />
                    <line x1={rx + rw} y1={rz} x2={rx} y2={rz + rd} stroke="#fae8a4" strokeWidth="1.5" strokeDasharray="3,3" />
                    <rect x={rx + rw / 2 - 12} y={rz + rd / 2 - 10} width="24" height="20" fill="#061220" stroke="#00f0ff" strokeWidth="1" />
                    <text x={rx + rw / 2} y={rz + rd / 2 + 4} fill="#fae8a4" fontSize="9" fontWeight="bold" textAnchor="middle">LIFT</text>
                  </g>
                )}

                {/* Staircase Step Treads */}
                {r.type === 'staircase' && (
                  <g>
                    {[1, 2, 3, 4, 5, 6, 7].map((step) => (
                      <line
                        key={step}
                        x1={rx + 4}
                        y1={rz + (step * rd) / 8}
                        x2={rx + rw - 4}
                        y2={rz + (step * rd) / 8}
                        stroke="#94a3b8"
                        strokeWidth="1"
                        strokeDasharray="1,1"
                      />
                    ))}
                    <text x={rx + rw / 2} y={rz + rd - 12} fill="#38bdf8" fontSize="10" fontWeight="bold" textAnchor="middle">↑ UP</text>
                  </g>
                )}

                {/* Room Center Name & Dimension Tag */}
                {rw > 45 && rd > 35 && (
                  <g>
                    <rect
                      x={rx + rw / 2 - 50}
                      y={rz + rd / 2 - 16}
                      width="100"
                      height="32"
                      rx="4"
                      fill="#060e1b"
                      fillOpacity="0.88"
                      stroke={isSelected ? '#00f0ff' : 'rgba(250, 232, 164, 0.4)'}
                      strokeWidth="1"
                    />
                    <text
                      x={rx + rw / 2}
                      y={rz + rd / 2 - 3}
                      fill="#f8fafc"
                      fontSize="10"
                      fontWeight="700"
                      textAnchor="middle"
                    >
                      {r.name.length > 18 ? r.name.slice(0, 16) + '..' : r.name}
                    </text>
                    <text
                      x={rx + rw / 2}
                      y={rz + rd / 2 + 10}
                      fill="#fae8a4"
                      fontSize="8.5"
                      fontFamily="monospace"
                      fontWeight="600"
                      textAnchor="middle"
                    >
                      {unit === 'imperial'
                        ? `${toFeetInches(r.w)} × ${toFeetInches(r.d)}`
                        : `${r.w.toFixed(1)}m × ${r.d.toFixed(1)}m`}
                    </text>
                  </g>
                )}

                {/* Selected Room Wall Transform Handles (Center Move + 4 Corner + 4 Edge Resize) */}
                {isSelected && activeTool === 'select' && (
                  <g className="ps-wall-handles">
                    {/* Center Move Handle */}
                    <g
                      className="ps-handle"
                      onMouseDown={(e) => {
                        e.stopPropagation();
                        if (onSelectRoom) onSelectRoom(r);
                        setDragState({
                          type: 'room_move',
                          id: r.id,
                          startX: r.x,
                          startZ: r.z,
                          mouseStartX: e.clientX,
                          mouseStartY: e.clientY
                        });
                        setDragFeedback(`Moving ${r.name}`);
                      }}
                      style={{ cursor: 'move' }}
                    >
                      <circle
                        cx={rx + rw / 2}
                        cy={rz + rd / 2}
                        r="14"
                        fill="#0284c7"
                        stroke="#ffffff"
                        strokeWidth="2"
                      />
                      <text x={rx + rw / 2} y={rz + rd / 2 + 4} fill="#ffffff" fontSize="12" textAnchor="middle">✥</text>
                    </g>

                    {/* Corner Resize Handles */}
                    {['nw', 'ne', 'se', 'sw'].map((h) => {
                      const hx = h.includes('e') ? rx + rw : rx;
                      const hz = h.includes('s') ? rz + rd : rz;
                      return (
                        <circle
                          key={h}
                          cx={hx}
                          cy={hz}
                          r="6"
                          className="ps-handle"
                          fill="#00f0ff"
                          stroke="#ffffff"
                          strokeWidth="2"
                          style={{ cursor: h === 'nw' || h === 'se' ? 'nwse-resize' : 'nesw-resize' }}
                          onMouseDown={(e) => {
                            e.stopPropagation();
                            if (onSelectRoom) onSelectRoom(r);
                            setDragState({
                              type: 'room_resize',
                              id: r.id,
                              handle: h,
                              startX: r.x,
                              startZ: r.z,
                              startW: r.w,
                              startD: r.d,
                              mouseStartX: e.clientX,
                              mouseStartY: e.clientY
                            });
                            setDragFeedback(`Resizing ${r.name}`);
                          }}
                        />
                      );
                    })}

                    {/* Edge Resize Handles */}
                    <circle
                      cx={rx + rw / 2}
                      cy={rz}
                      r="5"
                      className="ps-handle"
                      fill="#fae8a4"
                      stroke="#000000"
                      strokeWidth="1.5"
                      style={{ cursor: 'ns-resize' }}
                      onMouseDown={(e) => {
                        e.stopPropagation();
                        setDragState({
                          type: 'room_resize',
                          id: r.id,
                          handle: 'n',
                          startX: r.x,
                          startZ: r.z,
                          startW: r.w,
                          startD: r.d,
                          mouseStartX: e.clientX,
                          mouseStartY: e.clientY
                        });
                      }}
                    />
                    <circle
                      cx={rx + rw / 2}
                      cy={rz + rd}
                      r="5"
                      className="ps-handle"
                      fill="#fae8a4"
                      stroke="#000000"
                      strokeWidth="1.5"
                      style={{ cursor: 'ns-resize' }}
                      onMouseDown={(e) => {
                        e.stopPropagation();
                        setDragState({
                          type: 'room_resize',
                          id: r.id,
                          handle: 's',
                          startX: r.x,
                          startZ: r.z,
                          startW: r.w,
                          startD: r.d,
                          mouseStartX: e.clientX,
                          mouseStartY: e.clientY
                        });
                      }}
                    />
                    <circle
                      cx={rx}
                      cy={rz + rd / 2}
                      r="5"
                      className="ps-handle"
                      fill="#fae8a4"
                      stroke="#000000"
                      strokeWidth="1.5"
                      style={{ cursor: 'ew-resize' }}
                      onMouseDown={(e) => {
                        e.stopPropagation();
                        setDragState({
                          type: 'room_resize',
                          id: r.id,
                          handle: 'w',
                          startX: r.x,
                          startZ: r.z,
                          startW: r.w,
                          startD: r.d,
                          mouseStartX: e.clientX,
                          mouseStartY: e.clientY
                        });
                      }}
                    />
                    <circle
                      cx={rx + rw}
                      cy={rz + rd / 2}
                      r="5"
                      className="ps-handle"
                      fill="#fae8a4"
                      stroke="#000000"
                      strokeWidth="1.5"
                      style={{ cursor: 'ew-resize' }}
                      onMouseDown={(e) => {
                        e.stopPropagation();
                        setDragState({
                          type: 'room_resize',
                          id: r.id,
                          handle: 'e',
                          startX: r.x,
                          startZ: r.z,
                          startW: r.w,
                          startD: r.d,
                          mouseStartX: e.clientX,
                          mouseStartY: e.clientY
                        });
                      }}
                    />
                  </g>
                )}
              </g>
            );
          })}

          {/* Structural RCC Columns Rendering */}
          {columns.map((col) => {
            const cx = col.x * baseScale;
            const cz = col.z * baseScale;
            const size = (col.size || 0.4) * baseScale;
            const isSelected = selectedColumnId === col.id;

            return (
              <g
                key={col.id}
                className="ps-interactive-item"
                onClick={(e) => {
                  e.stopPropagation();
                  if (onSelectColumn) onSelectColumn(col);
                }}
              >
                {col.shape === 'round' ? (
                  <circle
                    cx={cx}
                    cy={cz}
                    r={size / 2}
                    fill={isSelected ? '#00f0ff' : '#475569'}
                    stroke="#fae8a4"
                    strokeWidth="1.5"
                  />
                ) : (
                  <>
                    <rect
                      x={cx - size / 2}
                      y={cz - size / 2}
                      width={size}
                      height={size}
                      fill={isSelected ? '#00f0ff' : '#475569'}
                      stroke="#fae8a4"
                      strokeWidth="1.5"
                    />
                    <line x1={cx - size / 2} y1={cz - size / 2} x2={cx + size / 2} y2={cz + size / 2} stroke="#fae8a4" strokeWidth="1" />
                    <line x1={cx + size / 2} y1={cz - size / 2} x2={cx - size / 2} y2={cz + size / 2} stroke="#fae8a4" strokeWidth="1" />
                  </>
                )}
              </g>
            );
          })}

          {/* Furniture & Vehicles Rendering with Live Interactive Drag */}
          {showFurniture && furniture.map((f) => {
            const fx = f.x * baseScale;
            const fz = f.z * baseScale;
            const fw = f.w * baseScale;
            const fd = f.d * baseScale;
            const isSelected = selectedFurnitureId === f.id;

            return (
              <g
                key={f.id}
                className="ps-interactive-item"
                transform={`translate(${fx}, ${fz}) rotate(${f.rot || 0})`}
                onMouseDown={(e) => {
                  if (activeTool !== 'select') return;
                  e.stopPropagation();
                  if (onSelectFurniture) onSelectFurniture(f);
                  setDragState({
                    type: 'furniture',
                    id: f.id,
                    startX: f.x,
                    startZ: f.z,
                    mouseStartX: e.clientX,
                    mouseStartY: e.clientY
                  });
                  setDragFeedback(`Moving ${f.name}`);
                }}
                onClick={(e) => {
                  if (activeTool === 'select') {
                    e.stopPropagation();
                    if (onSelectFurniture) onSelectFurniture(f);
                  }
                }}
                style={{ cursor: dragState?.id === f.id ? 'grabbing' : 'grab' }}
              >
                {/* Clearance Area Indicator */}
                <rect
                  x={-fw / 2 - 8}
                  y={-fd / 2 - 8}
                  width={fw + 16}
                  height={fd + 16}
                  fill="none"
                  stroke="#38bdf8"
                  strokeWidth="0.8"
                  strokeDasharray="2,2"
                  strokeOpacity="0.4"
                />

                {/* Furniture Body */}
                <rect
                  x={-fw / 2}
                  y={-fd / 2}
                  width={fw}
                  height={fd}
                  rx="3"
                  fill={f.color || '#1e3a5f'}
                  fillOpacity="0.85"
                  stroke={isSelected ? '#00f0ff' : '#fae8a4'}
                  strokeWidth={isSelected ? 2.5 : 1.2}
                />

                {/* Vehicle-specific CAD silhouette */}
                {(f.type === 'car_sedan' || f.type === 'car_suv') && (
                  <g>
                    <rect x={-fw / 2 + 4} y={-fd / 2 + 8} width={fw - 8} height="12" rx="2" fill="#040a14" opacity="0.6" />
                    <rect x={-fw / 2 + 4} y={fd / 2 - 18} width={fw - 8} height="10" rx="2" fill="#040a14" opacity="0.6" />
                    <circle cx={-fw / 2 + 5} cy={-fd / 2 + 3} r="2" fill="#fae8a4" />
                    <circle cx={fw / 2 - 5} cy={-fd / 2 + 3} r="2" fill="#fae8a4" />
                  </g>
                )}

                {/* Furniture Name Tag */}
                <text
                  x="0"
                  y="3"
                  fill="#ffffff"
                  fontSize="7.5"
                  fontWeight="600"
                  textAnchor="middle"
                >
                  {f.name.length > 14 ? f.name.slice(0, 12) + '..' : f.name}
                </text>
              </g>
            );
          })}

          {/* Active Wall Drawing Rubber-Band Preview */}
          {activeTool === 'draw_wall' && (
            <g>
              {/* Committed Segments in Current Chain */}
              {wallDrawPoints.map((p, idx) => {
                if (idx === 0) return null;
                const prev = wallDrawPoints[idx - 1];
                return (
                  <line
                    key={`chain-${idx}`}
                    x1={prev.x * baseScale}
                    y1={prev.z * baseScale}
                    x2={p.x * baseScale}
                    y2={p.z * baseScale}
                    stroke="#00f0ff"
                    strokeWidth="3.5"
                  />
                );
              })}

              {/* Placed Corner Nodes */}
              {wallDrawPoints.map((p, idx) => (
                <circle
                  key={`node-${idx}`}
                  cx={p.x * baseScale}
                  cy={p.z * baseScale}
                  r="5"
                  fill={idx === 0 && hoverMeter?.isClose ? '#10b981' : '#00f0ff'}
                  stroke="#ffffff"
                  strokeWidth="2"
                />
              ))}

              {/* Active Rubber-Band Line from Last Node to Cursor */}
              {wallDrawPoints.length > 0 && hoverMeter && (
                <>
                  <line
                    x1={wallDrawPoints[wallDrawPoints.length - 1].x * baseScale}
                    y1={wallDrawPoints[wallDrawPoints.length - 1].z * baseScale}
                    x2={hoverMeter.x * baseScale}
                    y2={hoverMeter.z * baseScale}
                    stroke={hoverMeter.isClose ? '#10b981' : '#00f0ff'}
                    strokeWidth="2.5"
                    strokeDasharray="4,4"
                  />
                  {/* Cursor Snap Node */}
                  <circle
                    cx={hoverMeter.x * baseScale}
                    cy={hoverMeter.z * baseScale}
                    r="6"
                    fill={hoverMeter.isClose ? '#10b981' : '#00f0ff'}
                    stroke="#ffffff"
                    strokeWidth="2"
                  />
                  {/* Real-time Dimension Badge along the line */}
                  <g
                    transform={`translate(${
                      ((wallDrawPoints[wallDrawPoints.length - 1].x + hoverMeter.x) / 2) * baseScale
                    }, ${
                      ((wallDrawPoints[wallDrawPoints.length - 1].z + hoverMeter.z) / 2) * baseScale - 16
                    })`}
                  >
                    <rect x="-42" y="-10" width="84" height="20" rx="3" fill="#040a14" stroke="#00f0ff" strokeWidth="1" />
                    <text x="0" y="3" fill="#00f0ff" fontSize="9.5" fontWeight="bold" fontFamily="monospace" textAnchor="middle">
                      {hoverMeter.isClose ? 'CLOSE ROOM' : `${toFeetInches(hoverMeter.dist || 0)} · ${hoverMeter.angle || 0}°`}
                    </text>
                  </g>
                </>
              )}
            </g>
          )}

          {/* Interactive Tape Measure Line */}
          {activeTool === 'measure' && measurePoints?.p1 && (
            <g>
              <circle
                cx={measurePoints.p1.x * baseScale}
                cy={measurePoints.p1.z * baseScale}
                r="6"
                fill="#ef4444"
                stroke="#ffffff"
                strokeWidth="2"
              />
              {measurePoints.p2 ? (
                <>
                  <circle
                    cx={measurePoints.p2.x * baseScale}
                    cy={measurePoints.p2.z * baseScale}
                    r="6"
                    fill="#ef4444"
                    stroke="#ffffff"
                    strokeWidth="2"
                  />
                  <line
                    x1={measurePoints.p1.x * baseScale}
                    y1={measurePoints.p1.z * baseScale}
                    x2={measurePoints.p2.x * baseScale}
                    y2={measurePoints.p2.z * baseScale}
                    stroke="#ef4444"
                    strokeWidth="2"
                    strokeDasharray="4,4"
                  />
                  <g
                    transform={`translate(${
                      ((measurePoints.p1.x + measurePoints.p2.x) / 2) * baseScale
                    }, ${
                      ((measurePoints.p1.z + measurePoints.p2.z) / 2) * baseScale - 14
                    })`}
                  >
                    <rect x="-35" y="-10" width="70" height="20" rx="3" fill="#050a12" stroke="#ef4444" strokeWidth="1" />
                    <text x="0" y="4" fill="#ffffff" fontSize="10" fontWeight="bold" fontFamily="monospace" textAnchor="middle">
                      {toFeetInches(Math.hypot(measurePoints.p2.x - measurePoints.p1.x, measurePoints.p2.z - measurePoints.p1.z))}
                    </text>
                  </g>
                </>
              ) : hoverMeter ? (
                <line
                  x1={measurePoints.p1.x * baseScale}
                  y1={measurePoints.p1.z * baseScale}
                  x2={hoverMeter.x * baseScale}
                  y2={hoverMeter.z * baseScale}
                  stroke="#ef4444"
                  strokeWidth="1.5"
                  strokeDasharray="2,2"
                />
              ) : null}
            </g>
          )}

          {/* Overall Plot Dimension Strings */}
          {showDimensions && (
            <g>
              {/* Plot Width Top Dimension */}
              <line
                x1={(-plotWidth / 2) * baseScale}
                y1={(-plotDepth / 2) * baseScale - 24}
                x2={(plotWidth / 2) * baseScale}
                y2={(-plotDepth / 2) * baseScale - 24}
                stroke="#fae8a4"
                strokeWidth="1.5"
              />
              <line
                x1={(-plotWidth / 2) * baseScale}
                y1={(-plotDepth / 2) * baseScale - 32}
                x2={(-plotWidth / 2) * baseScale}
                y2={(-plotDepth / 2) * baseScale - 16}
                stroke="#fae8a4"
                strokeWidth="1.5"
              />
              <line
                x1={(plotWidth / 2) * baseScale}
                y1={(-plotDepth / 2) * baseScale - 32}
                x2={(plotWidth / 2) * baseScale}
                y2={(-plotDepth / 2) * baseScale - 16}
                stroke="#fae8a4"
                strokeWidth="1.5"
              />
              <rect
                x="-36"
                y={(-plotDepth / 2) * baseScale - 34}
                width="72"
                height="18"
                rx="3"
                fill="#050a12"
                stroke="#fae8a4"
                strokeWidth="1"
              />
              <text
                x="0"
                y={(-plotDepth / 2) * baseScale - 21}
                fill="#fae8a4"
                fontSize="10"
                fontWeight="bold"
                fontFamily="monospace"
                textAnchor="middle"
              >
                {unit === 'imperial' ? formatDim(plotWidth, 'imperial') : `${plotWidth}m`}
              </text>

              {/* Plot Depth Right Dimension */}
              <line
                x1={(plotWidth / 2) * baseScale + 24}
                y1={(-plotDepth / 2) * baseScale}
                x2={(plotWidth / 2) * baseScale + 24}
                y2={(plotDepth / 2) * baseScale}
                stroke="#fae8a4"
                strokeWidth="1.5"
              />
              <line
                x1={(plotWidth / 2) * baseScale + 16}
                y1={(-plotDepth / 2) * baseScale}
                x2={(plotWidth / 2) * baseScale + 32}
                y2={(-plotDepth / 2) * baseScale}
                stroke="#fae8a4"
                strokeWidth="1.5"
              />
              <line
                x1={(plotWidth / 2) * baseScale + 16}
                y1={(plotDepth / 2) * baseScale}
                x2={(plotWidth / 2) * baseScale + 32}
                y2={(plotDepth / 2) * baseScale}
                stroke="#fae8a4"
                strokeWidth="1.5"
              />
              <rect
                x={(plotWidth / 2) * baseScale + 12}
                y="-9"
                width="70"
                height="18"
                rx="3"
                fill="#050a12"
                stroke="#fae8a4"
                strokeWidth="1"
              />
              <text
                x={(plotWidth / 2) * baseScale + 47}
                y="4"
                fill="#fae8a4"
                fontSize="10"
                fontWeight="bold"
                fontFamily="monospace"
                textAnchor="middle"
              >
                {unit === 'imperial' ? formatDim(plotDepth, 'imperial') : `${plotDepth}m`}
              </text>
            </g>
          )}

          {/* Compass Rose Badge */}
          <g transform={`translate(${(-plotWidth / 2) * baseScale + 40}, ${(-plotDepth / 2) * baseScale + 40})`}>
            <circle cx="0" cy="0" r="22" fill="#040914" stroke="#fae8a4" strokeWidth="1.5" />
            <polygon points="0,-18 5,-4 0,-7 -5,-4" fill="#ef4444" />
            <polygon points="0,18 5,4 0,7 -5,4" fill="#94a3b8" />
            <text x="0" y="-8" fill="#ef4444" fontSize="9" fontWeight="bold" textAnchor="middle">N</text>
          </g>

          {/* Architectural Drawing Title Block Stamp */}
          <g transform={`translate(${(-plotWidth / 2) * baseScale}, ${(plotDepth / 2) * baseScale + 35})`}>
            <rect width={plotWidth * baseScale} height="42" fill="#040a14" stroke="#00f0ff" strokeWidth="1.2" rx="3" />
            <text x="14" y="18" fill="#fae8a4" fontSize="11" fontWeight="bold">
              {buildingName.toUpperCase()} · {floorTitle.toUpperCase()}
            </text>
            <text x="14" y="32" fill="#94a3b8" fontSize="8.5" fontFamily="monospace">
              SCALE: 1:1 REPRODUCIBLE · BIM ACCREDITED · CAD COMPLIANT
            </text>
            <text x={plotWidth * baseScale - 14} y="24" fill="#00f0ff" fontSize="10" fontWeight="bold" textAnchor="end">
              WALK THE PLAN PROJECTION
            </text>
          </g>
        </g>
      </svg>
    </div>
  );
}
