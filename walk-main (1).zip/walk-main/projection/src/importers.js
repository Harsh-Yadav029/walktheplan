/**
 * importers.js
 * Comprehensive Architectural Blueprint & Spatial Importer
 * Compatible with Apple RoomPlan (LiDAR JSON), OpenPlan3D, and WalkThePlan JSON
 */

/**
 * Parses Apple RoomPlan JSON (from iPhone / iPad Pro LiDAR RoomCapture)
 * Apple RoomPlan exports walls, doors, windows, openings, and objects.
 * Transforms are 4x4 column-major matrices or { position, dimensions, transform }.
 */
export function parseAppleRoomPlanJSON(data) {
  const result = {
    buildingName: 'RoomPlan LiDAR Scan',
    unit: 'metric',
    rooms: [],
    customWalls: [],
    openings: [],
    columns: [],
    furniture: []
  };

  if (!data) return result;

  // Helper to extract position & rotation from 4x4 matrix or position array
  const extractTransform = (obj) => {
    let x = 0, y = 0, z = 0, rotY = 0;
    if (obj.transform && Array.isArray(obj.transform) && obj.transform.length >= 16) {
      // 4x4 column-major matrix: position is at indices 12 (X), 13 (Y), 14 (Z)
      x = obj.transform[12] || 0;
      y = obj.transform[13] || 0;
      z = obj.transform[14] || 0;
      // Rotation around Y from matrix: rotY = atan2(m[8], m[0]) or m[2], m[0]
      const m00 = obj.transform[0];
      const m02 = obj.transform[2];
      rotY = (Math.atan2(m02, m00) * 180) / Math.PI;
    } else if (obj.position && Array.isArray(obj.position)) {
      x = obj.position[0] || 0;
      y = obj.position[1] || 0;
      z = obj.position[2] || 0;
    } else if (obj.position && typeof obj.position === 'object') {
      x = obj.position.x || 0;
      y = obj.position.y || 0;
      z = obj.position.z || 0;
    }
    return { x: Math.round(x * 100) / 100, y, z: Math.round(z * 100) / 100, rotY: Math.round(rotY) };
  };

  // Helper to extract dimensions [w, h, d] or [length, height, thickness]
  const extractDimensions = (obj) => {
    let w = 1.0, h = 2.8, d = 0.2;
    if (obj.dimensions && Array.isArray(obj.dimensions)) {
      w = obj.dimensions[0] || 1.0;
      h = obj.dimensions[1] || 2.8;
      d = obj.dimensions[2] || 0.2;
    } else if (obj.dimensions && typeof obj.dimensions === 'object') {
      w = obj.dimensions.x || obj.dimensions.width || 1.0;
      h = obj.dimensions.y || obj.dimensions.height || 2.8;
      d = obj.dimensions.z || obj.dimensions.depth || 0.2;
    }
    return { w: Math.round(w * 100) / 100, h: Math.round(h * 100) / 100, d: Math.round(d * 100) / 100 };
  };

  // Parse Walls
  const wallsList = data.walls || [];
  wallsList.forEach((w, idx) => {
    const tf = extractTransform(w);
    const dim = extractDimensions(w);
    const length = dim.w || 3.0;
    const thick = dim.d || 0.2;
    const height = dim.h || 2.8;
    const rad = (tf.rotY * Math.PI) / 180;

    // Vector start and end points from center + length along wall heading
    const halfL = length / 2;
    const dx = Math.cos(rad) * halfL;
    const dz = Math.sin(rad) * halfL;

    result.customWalls.push({
      id: w.identifier || `rp_wall_${idx + 1}`,
      x1: Math.round((tf.x - dx) * 100) / 100,
      z1: Math.round((tf.z - dz) * 100) / 100,
      x2: Math.round((tf.x + dx) * 100) / 100,
      z2: Math.round((tf.z + dz) * 100) / 100,
      length: Math.round(length * 100) / 100,
      height: Math.round(height * 100) / 100,
      thick: Math.round(thick * 100) / 100,
      wallMat: 'wall_white_chalk'
    });
  });

  // If walls exist, create an enclosing bounding room for floor and material rendering
  if (result.customWalls.length > 0) {
    const allX = result.customWalls.flatMap((cw) => [cw.x1, cw.x2]);
    const allZ = result.customWalls.flatMap((cw) => [cw.z1, cw.z2]);
    const minX = Math.min(...allX);
    const maxX = Math.max(...allX);
    const minZ = Math.min(...allZ);
    const maxZ = Math.max(...allZ);
    const roomW = Math.max(2.0, maxX - minX);
    const roomD = Math.max(2.0, maxZ - minZ);

    result.rooms.push({
      id: 'rp_room_main',
      type: 'living',
      name: 'Scanned Room Space',
      x: minX,
      z: minZ,
      w: Math.round(roomW * 100) / 100,
      d: Math.round(roomD * 100) / 100,
      h: 2.9,
      wallThick: 0.2,
      floorMat: 'marble_calacatta',
      wallMat: 'wall_white_chalk',
      doorSide: 'open'
    });
  }

  // Parse Doors
  const doorsList = data.doors || [];
  doorsList.forEach((d, idx) => {
    const tf = extractTransform(d);
    const dim = extractDimensions(d);
    result.openings.push({
      id: d.identifier || `rp_door_${idx + 1}`,
      type: 'door',
      style: 'single',
      x: tf.x,
      z: tf.z,
      w: dim.w || 0.9,
      h: dim.h || 2.1,
      thick: dim.d || 0.2,
      wallSide: 'north',
      offset: 0.5
    });
  });

  // Parse Windows
  const windowsList = data.windows || [];
  windowsList.forEach((win, idx) => {
    const tf = extractTransform(win);
    const dim = extractDimensions(win);
    result.openings.push({
      id: win.identifier || `rp_win_${idx + 1}`,
      type: 'window',
      style: 'casement',
      x: tf.x,
      z: tf.z,
      w: dim.w || 1.4,
      h: dim.h || 1.2,
      sillH: 0.9,
      thick: dim.d || 0.2,
      wallSide: 'south',
      offset: 0.5
    });
  });

  // Parse Objects / Furniture
  const objectsList = data.objects || data.furniture || [];
  objectsList.forEach((obj, idx) => {
    const tf = extractTransform(obj);
    const dim = extractDimensions(obj);
    const cat = (obj.category || obj.type || 'table').toLowerCase();

    let matchedType = 'table';
    let matchedName = 'Living Table';
    let color = '#4a2e1b';

    if (cat.includes('bed')) {
      matchedType = 'bed_king';
      matchedName = 'King Platform Bed';
      color = '#1e3a5f';
    } else if (cat.includes('sofa') || cat.includes('couch')) {
      matchedType = 'sofa_3seater';
      matchedName = 'Luxe 3-Seater Sofa';
      color = '#1e3a5f';
    } else if (cat.includes('chair')) {
      matchedType = 'lounge_chair';
      matchedName = 'Scandinavian Lounge Chair';
      color = '#334155';
    } else if (cat.includes('storage') || cat.includes('wardrobe') || cat.includes('closet')) {
      matchedType = 'wardrobe';
      matchedName = 'Wardrobe Unit';
      color = '#3e2716';
    } else if (cat.includes('refrigerator') || cat.includes('fridge')) {
      matchedType = 'kitchen_fridge';
      matchedName = 'Double Door Refrigerator';
      color = '#94a3b8';
    } else if (cat.includes('stove') || cat.includes('oven')) {
      matchedType = 'kitchen_cooktop';
      matchedName = 'Island Induction Cooktop';
      color = '#0f172a';
    } else if (cat.includes('tub') || cat.includes('bath')) {
      matchedType = 'luxury_bathtub';
      matchedName = 'Freestanding Bathtub';
      color = '#f8fafc';
    } else if (cat.includes('sink') || cat.includes('vanity')) {
      matchedType = 'bath_vanity';
      matchedName = 'Marble Vanity Unit';
      color = '#f8fafc';
    } else if (cat.includes('television') || cat.includes('screen') || cat.includes('tv')) {
      matchedType = 'media_wall_unit';
      matchedName = 'OLED TV Media Console';
      color = '#0f172a';
    }

    result.furniture.push({
      id: obj.identifier || `rp_furn_${idx + 1}`,
      type: matchedType,
      name: matchedName,
      x: tf.x,
      z: tf.z,
      w: Math.max(0.4, dim.w || 1.2),
      d: Math.max(0.4, dim.d || 0.8),
      h: Math.max(0.4, dim.h || 0.75),
      rot: tf.rotY || 0,
      color
    });
  });

  return result;
}

/**
 * Universal Importer: Detects Apple RoomPlan, OpenPlan3D, or WalkThePlan JSON schema
 */
export function parseUniversalFloorPlanJSON(jsonText) {
  let parsed;
  try {
    parsed = typeof jsonText === 'string' ? JSON.parse(jsonText) : jsonText;
  } catch (err) {
    throw new Error('Invalid JSON format: ' + err.message);
  }

  // Check if Apple RoomPlan format (has walls array with identifier or transform)
  if (parsed.walls && Array.isArray(parsed.walls) && parsed.walls.length > 0) {
    const firstWall = parsed.walls[0];
    if (firstWall.identifier || firstWall.transform || firstWall.dimensions) {
      return parseAppleRoomPlanJSON(parsed);
    }
  }

  // Check if OpenPlan3D / WalkThePlan project format
  const result = {
    buildingName: parsed.building?.name || parsed.buildingName || 'Imported Floor Plan',
    unit: parsed.building?.unit || parsed.unit || 'imperial',
    plotWidth: parsed.building?.plotWidth || parsed.plotWidth || 9.12,
    plotDepth: parsed.building?.plotDepth || parsed.plotDepth || 22.91,
    rooms: parsed.rooms || [],
    customWalls: parsed.walls || parsed.customWalls || [],
    openings: parsed.openings || [],
    columns: parsed.columns || [],
    furniture: parsed.furniture || [],
    settings: parsed.settings || {}
  };

  // If rooms exist but lack IDs, assign unique IDs
  result.rooms = result.rooms.map((r, i) => ({
    ...r,
    id: r.id || `room_${Date.now()}_${i}`
  }));

  // Ensure custom walls have valid coordinate pairs
  result.customWalls = result.customWalls.map((w, i) => ({
    ...w,
    id: w.id || `wall_${Date.now()}_${i}`,
    x1: Number(w.x1 || 0),
    z1: Number(w.z1 || 0),
    x2: Number(w.x2 || (w.x1 || 0) + (w.length || 3.0)),
    z2: Number(w.z2 || w.z1 || 0),
    height: Number(w.height || 3.0),
    thick: Number(w.thick || 0.23),
    wallMat: w.wallMat || 'wall_white_chalk'
  }));

  result.furniture = result.furniture.map((f, i) => ({
    ...f,
    id: f.id || `furn_${Date.now()}_${i}`
  }));

  return result;
}
