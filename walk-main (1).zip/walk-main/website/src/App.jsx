import React, { useEffect, lazy, Suspense } from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation, Navigate } from 'react-router-dom';
import Navbar from '@shared/components/Navbar';
import Footer from '@shared/components/Footer';
import DynamicBackground from '@shared/components/DynamicBackground';
import ScrollToTopButton from '@shared/components/ScrollToTopButton';
import InstantLeadModal from '@shared/components/InstantLeadModal';
import PageProgressBar from '@shared/components/PageProgressBar';
import BlueprintLoader from '@shared/components/BlueprintLoader';
import NotificationPrompt from '@shared/components/NotificationPrompt';
import SiteNotificationBanner from '@shared/components/SiteNotificationBanner';
import AIChatWidget from '@shared/components/AIChatWidget';
import { SettingsProvider, useSettings } from '@shared/context/SettingsContext';

// Website Pages
import Home from '@website/pages/Home';
const About = lazy(() => import('@website/pages/About'));
const Services = lazy(() => import('@website/pages/Services'));
const Franchise = lazy(() => import('@website/pages/Franchise'));
const Gallery = lazy(() => import('@website/pages/Gallery'));
const Blog = lazy(() => import('@website/pages/Blog'));
const BlogPost = lazy(() => import('@website/pages/BlogPost'));
const Career = lazy(() => import('@website/pages/Career'));
const TermsConditions = lazy(() => import('@website/pages/legal/TermsConditions'));
const PrivacyPolicy = lazy(() => import('@website/pages/legal/PrivacyPolicy'));
const LegalTabbedPages = lazy(() => import('@website/pages/legal/LegalTabbedPages'));

const ScrollToTop = () => {
  const { pathname, state } = useLocation();
  useEffect(() => {
    if (state && state.scrollTo) {
      const element = document.getElementById(state.scrollTo);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth', block: 'start' });
        window.history.replaceState({}, document.title);
        return;
      }
    }
    window.scrollTo(0, 0);
  }, [pathname, state]);
  return null;
};

const useScrollReveal = () => {
  const location = useLocation();
  useEffect(() => {
    const revealElements = document.querySelectorAll('.scroll-reveal');
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) entry.target.classList.add('active');
      });
    }, { threshold: 0.08, rootMargin: '0px 0px -40px 0px' });
    revealElements.forEach(el => observer.observe(el));
    return () => { revealElements.forEach(el => observer.unobserve(el)); };
  }, [location.pathname]);
};

const usePageTracker = () => {
  const location = useLocation();
  useEffect(() => {
    const path = location.pathname;
    try {
      let devId = localStorage.getItem('wtp_device_id');
      if (!devId || !/^DEV-\d{4,5}$/i.test(devId)) {
        let num = Math.floor(1000 + Math.random() * 9000);
        devId = `DEV-${num}`;
        localStorage.setItem('wtp_device_id', devId);
      }
      let vid = localStorage.getItem('wtp_vid');
      if (!vid) {
        vid = 'v_' + Math.random().toString(36).substring(2, 10) + Date.now().toString(36);
        localStorage.setItem('wtp_vid', vid);
      }
      let sid = sessionStorage.getItem('wtp_sid');
      if (!sid) {
        sid = 's_' + Math.random().toString(36).substring(2, 10) + Date.now().toString(36);
        sessionStorage.setItem('wtp_sid', sid);
      }
      let visitCount = parseInt(localStorage.getItem('wtp_visit_count') || '0', 10);
      let lastVisitAt = localStorage.getItem('wtp_last_visit_at');
      if (!sessionStorage.getItem('wtp_session_active')) {
        sessionStorage.setItem('wtp_session_active', '1');
        visitCount += 1;
        localStorage.setItem('wtp_visit_count', visitCount);
      }
      localStorage.setItem('wtp_last_visit_at', new Date().toISOString());

      const payload = {
        path,
        referrer: document.referrer || 'direct',
        title: document.title,
        device_id: devId,
        visitor_id: vid,
        session_id: sid,
        visit_count: visitCount,
        last_visit_at: lastVisitAt,
        screen_res: `${window.screen.width}x${window.screen.height}`,
        language: navigator.language || 'en'
      };

      fetch('/api/analytics/track', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      }).catch(() => {});
    } catch (_) {}
  }, [location.pathname]);
};

// Modular App Handoff Component (Local dev port switching vs VPS relative path)
const ModularAppHandoff = ({ localPort, path }) => {
  useEffect(() => {
    const isLocal = typeof window !== 'undefined' && (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1');
    const targetUrl = isLocal ? `http://localhost:${localPort}${path}` : path;
    window.location.replace(targetUrl);
  }, [localPort, path]);

  return <BlueprintLoader />;
};

const AppContent = () => {
  useScrollReveal();
  usePageTracker();
  const location = useLocation();
  const { isLeadModalOpen, leadModalStudio, openLeadModal, closeLeadModal } = useSettings();

  // Auto open "Book Your Appointment" popup on first visit / new session
  useEffect(() => {
    try {
      const hasSeenInSession = sessionStorage.getItem('wtp_session_appointment_shown');
      if (!hasSeenInSession) {
        sessionStorage.setItem('wtp_session_appointment_shown', '1');
        const timer = setTimeout(() => {
          openLeadModal('Gurugram HQ');
        }, 350);
        return () => clearTimeout(timer);
      }
    } catch (e) {
      const timer = setTimeout(() => { openLeadModal('Gurugram HQ'); }, 350);
      return () => clearTimeout(timer);
    }
  }, [openLeadModal]);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', minHeight: '100vh', position: 'relative', zIndex: 10 }}>
      <PageProgressBar />
      <ScrollToTop />
      <Navbar onOpenBooking={() => openLeadModal()} />
      <main
        key={location.pathname}
        className="page-change-wrapper"
        style={{ flex: 1, paddingTop: '80px', display: 'flex', flexDirection: 'column' }}
      >
        <Suspense fallback={<BlueprintLoader />}>
          <Routes>
            <Route path="/" element={<Home onOpenBooking={openLeadModal} />} />
            <Route path="/about" element={<About onOpenBooking={openLeadModal} />} />
            <Route path="/services" element={<Services onOpenBooking={openLeadModal} />} />
            <Route path="/franchise" element={<Franchise />} />
            <Route path="/terms" element={<TermsConditions />} />
            <Route path="/privacy" element={<PrivacyPolicy />} />
            <Route path="/refund" element={<LegalTabbedPages />} />
            <Route path="/shipping" element={<LegalTabbedPages />} />
            <Route path="/careers" element={<Career />} />
            <Route path="/gallery" element={<Gallery />} />
            <Route path="/blog" element={<Blog />} />
            <Route path="/blog/:slug" element={<BlogPost />} />
            <Route path="/contact" element={<Home forceContactScroll={true} onOpenBooking={openLeadModal} />} />

            {/* Modular Handoffs to Dedicated Apps */}
            <Route path="/projection" element={<ModularAppHandoff localPort="5175" path="/projection" />} />
            <Route path="/projection/*" element={<ModularAppHandoff localPort="5175" path="/projection" />} />
            <Route path="/admin" element={<ModularAppHandoff localPort="5176" path="/admin" />} />
            <Route path="/admin/*" element={<ModularAppHandoff localPort="5176" path="/admin" />} />
            <Route path="/login" element={<ModularAppHandoff localPort="5176" path="/admin/login" />} />
            <Route path="/fitscalez" element={<ModularAppHandoff localPort="5176" path="/fitscalez" />} />
            <Route path="/fitscalez/*" element={<ModularAppHandoff localPort="5176" path="/fitscalez" />} />
            <Route path="/crm" element={<ModularAppHandoff localPort="5174" path="/crm" />} />
            <Route path="/crm/*" element={<ModularAppHandoff localPort="5174" path="/crm" />} />
          </Routes>
        </Suspense>
      </main>
      <Footer onOpenBooking={openLeadModal} />
      <ScrollToTopButton />
      <SiteNotificationBanner />
      <NotificationPrompt />
      <InstantLeadModal
        isOpen={isLeadModalOpen}
        onClose={closeLeadModal}
        initialStudio={leadModalStudio}
      />
      <AIChatWidget />
    </div>
  );
};

export default function App() {
  return (
    <Router>
      <SettingsProvider>
        <DynamicBackground />
        <AppContent />
      </SettingsProvider>
    </Router>
  );
}
