import { useEffect } from 'react';

const BASE_URL = 'https://walktheplan.in';
const DEFAULT_IMAGE = `${BASE_URL}/uploads/gurgaon_studio.png`;

/**
 * Custom React hook for dynamic SEO management across pages
 * Updates document.title, meta descriptions, canonical link, Open Graph, Twitter Cards,
 * and injects structured data (JSON-LD) for rich search engine and AI indexing.
 */
export function usePageSEO({
  title,
  description,
  keywords,
  canonical,
  image = DEFAULT_IMAGE,
  type = 'website',
  breadcrumbs = null,
  schema = null,
} = {}) {
  useEffect(() => {
    // 1. Title Tag
    const fullTitle = title
      ? (title.includes('Walk The Plan') ? title : `${title} | Walk The Plan`)
      : 'Walk The Plan | 1:1 Scale Architectural Blueprint Projection Studio India';
    document.title = fullTitle;

    // Helper to get or create a meta element
    const setMeta = (attr, key, val) => {
      if (!val) return;
      let el = document.querySelector(`meta[${attr}="${key}"]`);
      if (!el) {
        el = document.createElement('meta');
        el.setAttribute(attr, key);
        document.head.appendChild(el);
      }
      el.setAttribute('content', val);
    };

    // 2. Primary Meta Tags
    setMeta('name', 'title', fullTitle);
    if (description) setMeta('name', 'description', description);
    if (keywords) setMeta('name', 'keywords', keywords);
    setMeta('name', 'author', 'Walk The Plan');

    // 3. Open Graph Tags
    const pageUrl = canonical
      ? (canonical.startsWith('http') ? canonical : `${BASE_URL}${canonical}`)
      : window.location.href;

    setMeta('property', 'og:title', fullTitle);
    if (description) setMeta('property', 'og:description', description);
    setMeta('property', 'og:url', pageUrl);
    setMeta('property', 'og:image', image.startsWith('http') ? image : `${BASE_URL}${image}`);
    setMeta('property', 'og:type', type);
    setMeta('property', 'og:site_name', 'Walk The Plan');
    setMeta('property', 'og:locale', 'en_IN');

    // 4. Twitter Card
    setMeta('name', 'twitter:card', 'summary_large_image');
    setMeta('name', 'twitter:title', fullTitle);
    if (description) setMeta('name', 'twitter:description', description);
    setMeta('name', 'twitter:image', image.startsWith('http') ? image : `${BASE_URL}${image}`);
    setMeta('name', 'twitter:url', pageUrl);

    // 5. Canonical Link
    let canonicalLink = document.querySelector('link[rel="canonical"]');
    if (!canonicalLink) {
      canonicalLink = document.createElement('link');
      canonicalLink.setAttribute('rel', 'canonical');
      document.head.appendChild(canonicalLink);
    }
    canonicalLink.setAttribute('href', pageUrl);

    // 6. JSON-LD Structured Data
    const scriptId = 'dynamic-page-schema';
    let scriptTag = document.getElementById(scriptId);

    const schemaGraph = [];

    // Add Breadcrumb schema if provided
    if (breadcrumbs && breadcrumbs.length > 0) {
      schemaGraph.push({
        '@type': 'BreadcrumbList',
        'itemListElement': breadcrumbs.map((b, idx) => ({
          '@type': 'ListItem',
          'position': idx + 1,
          'name': b.name,
          'item': b.item.startsWith('http') ? b.item : `${BASE_URL}${b.item}`
        }))
      });
    }

    // Add custom schema (e.g. FAQPage, Service)
    if (schema) {
      if (Array.isArray(schema)) {
        schemaGraph.push(...schema);
      } else {
        schemaGraph.push(schema);
      }
    }

    if (schemaGraph.length > 0) {
      if (!scriptTag) {
        scriptTag = document.createElement('script');
        scriptTag.id = scriptId;
        scriptTag.type = 'application/ld+json';
        document.head.appendChild(scriptTag);
      }
      scriptTag.textContent = JSON.stringify({
        '@context': 'https://schema.org',
        '@graph': schemaGraph
      });
    } else if (scriptTag) {
      scriptTag.remove();
    }

    return () => {
      // Optional cleanup on unmount
      const existingScript = document.getElementById(scriptId);
      if (existingScript) existingScript.remove();
    };
  }, [title, description, keywords, canonical, image, type, JSON.stringify(breadcrumbs), JSON.stringify(schema)]);
}

export default usePageSEO;
