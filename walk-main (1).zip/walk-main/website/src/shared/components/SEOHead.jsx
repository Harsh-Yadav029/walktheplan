import React from 'react';
import usePageSEO from '../utils/usePageSEO';

/**
 * Declarative component for page-specific SEO.
 * Place at the top of any page component.
 */
export default function SEOHead({
  title,
  description,
  keywords,
  canonical,
  image,
  type = 'website',
  breadcrumbs,
  schema
}) {
  usePageSEO({
    title,
    description,
    keywords,
    canonical,
    image,
    type,
    breadcrumbs,
    schema
  });

  return null;
}
