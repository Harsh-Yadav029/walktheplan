import React, { useState, useEffect, useRef } from 'react';
import {
  Sparkles,
  X,
  Send,
  MessageCircle,
  Phone,
  Building,
  MapPin,
  CheckCircle,
  ArrowRight,
  Maximize2,
  Minimize2,
  Layers,
  HelpCircle
} from 'lucide-react';
import { useSettings } from '@/shared/context/SettingsContext';
import './AIChatWidget.css';

const WHATSAPP_NUMBER = '+91 97110 22075';
const WHATSAPP_RAW = '919711022075';

const DEFAULT_SUGGESTIONS = [
  'How does 1:1 projection work?',
  'Packages & Pricing',
  'Find studio near me',
  'Book a 1:1 Walkthrough',
  'Try Free 3D & VR Tool',
  'Can we test real furniture?',
  'Franchise Inquiry'
];

export default function AIChatWidget() {
  const { isLeadModalOpen } = useSettings();
  const [isOpen, setIsOpen] = useState(false);
  const [showTeaser, setShowTeaser] = useState(false);
  const [inputMessage, setInputMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [unreadCount, setUnreadCount] = useState(1);
  const [activeFunnel, setActiveFunnel] = useState(null); // 'booking'

  // Hide teaser when appointment modal is active
  useEffect(() => {
    if (isLeadModalOpen) {
      setShowTeaser(false);
    }
  }, [isLeadModalOpen]);

  // Funnel Form State
  const [leadForm, setLeadForm] = useState({
    propertyType: 'Luxury Villa / Bungalow',
    studio: 'Gurugram HQ',
    area: '3,000 - 5,000 sq ft',
    name: '',
    phone: '',
    submitted: false,
    refId: null
  });

  const [messages, setMessages] = useState([
    {
      id: 1,
      sender: 'bot',
      text: `👋 **Welcome to Walk The Plan!**\n\nI am your **AI Spatial Architectural Consultant**. We beam your architectural blueprints onto our studio floor at **true 1:1 physical scale** so you can walk through your future home and test real movable furniture before laying a single brick!\n\nHow can I assist you today?`,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      suggestions: DEFAULT_SUGGESTIONS
    }
  ]);

  const messagesEndRef = useRef(null);

  // Auto-scroll to bottom of chat
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
      setUnreadCount(0);
      setShowTeaser(false);
    }
  }, [messages, isOpen, isTyping, activeFunnel]);

  // Gentle auto-teaser bubble after 5 seconds on first visit
  useEffect(() => {
    const hasSeenChat = localStorage.getItem('wtp_ai_chat_opened');
    if (!hasSeenChat) {
      const timer = setTimeout(() => {
        setShowTeaser(true);
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleOpenChat = () => {
    setIsOpen(true);
    setShowTeaser(false);
    setUnreadCount(0);
    try {
      localStorage.setItem('wtp_ai_chat_opened', '1');
    } catch (_) {}
  };

  const handleCloseChat = () => {
    setIsOpen(false);
  };

  // Send a message to AI backend
  const handleSend = async (textToSend) => {
    const query = (textToSend || inputMessage).trim();
    if (!query) return;

    const userMsgId = Date.now();
    const userMsg = {
      id: userMsgId,
      sender: 'user',
      text: query,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputMessage('');
    setIsTyping(true);

    // If query matches booking intent, trigger interactive lead funnel
    const lowerQuery = query.toLowerCase();
    if (
      lowerQuery.includes('book a 1:1') ||
      lowerQuery.includes('book walkthrough') ||
      lowerQuery.includes('schedule visit') ||
      lowerQuery.includes('reserve slot')
    ) {
      setTimeout(() => {
        setIsTyping(false);
        setActiveFunnel('booking');
        setMessages((prev) => [
          ...prev,
          {
            id: Date.now() + 1,
            sender: 'bot',
            text: `🎯 **Let's tailor your 1:1 Walkthrough Experience!**\n\nPlease select your property type and preferred studio location below:`,
            time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
          }
        ]);
      }, 600);
      return;
    }

    if (lowerQuery.includes('try free 3d') || lowerQuery.includes('launch 3d')) {
      setTimeout(() => {
        setIsTyping(false);
        setMessages((prev) => [
          ...prev,
          {
            id: Date.now() + 1,
            sender: 'bot',
            text: `🥽 **Access the Online 1:1 Architectural & VR Modeler:**\n\nYou can draft 2D walls, insert doors/windows, position structural columns, and project your floor plan in 1:1 scale stereoscopic VR right here:\n\n👉 **[Open Walk The Plan 3D & VR Studio](/projection)**`,
            time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            suggestions: ['Book In-Studio Walkthrough', 'Packages & Pricing', 'Find studio near me']
          }
        ]);
      }, 500);
      return;
    }

    try {
      const response = await fetch('/api/ai-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: query,
          visitorContext: {
            projectType: leadForm.propertyType,
            studio: leadForm.studio,
            platform: 'AI Chatbot'
          }
        })
      });

      if (!response.ok) throw new Error('API request failed');

      const data = await response.json();
      setIsTyping(false);

      setMessages((prev) => [
        ...prev,
        {
          id: Date.now() + 2,
          sender: 'bot',
          text: data.reply,
          capturedLead: data.capturedLead,
          suggestions: data.suggestions || DEFAULT_SUGGESTIONS,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    } catch (err) {
      console.warn('AI Chat fallback triggered:', err);
      setIsTyping(false);
      setMessages((prev) => [
        ...prev,
        {
          id: Date.now() + 2,
          sender: 'bot',
          text: `✨ **Need immediate architectural assistance?**\n\nOur senior spatial consultants are available right now on WhatsApp! You can message us directly with your floor plan PDF or questions.`,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          showWhatsAppCTA: true,
          suggestions: ['Packages & Pricing', 'Find studio near me', 'Book a 1:1 Walkthrough']
        }
      ]);
    }
  };

  // Submit Interactive Lead Funnel
  const handleFunnelSubmit = async (e) => {
    e.preventDefault();
    if (!leadForm.name.trim() || !leadForm.phone.trim()) {
      alert('Please provide your name and 10-digit mobile number.');
      return;
    }

    setIsTyping(true);
    const combinedNotes = `[AI CHAT QUALIFIED LEAD]
Property: ${leadForm.propertyType}
Studio: ${leadForm.studio}
Area: ${leadForm.area}
Customer Name: ${leadForm.name}
Phone: ${leadForm.phone}`;

    try {
      const res = await fetch('/api/bookings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: leadForm.name.trim(),
          phone: leadForm.phone.trim(),
          email: `${leadForm.phone.trim().replace(/[^0-9]/g, '')}@lead.walktheplan.in`,
          message: combinedNotes,
          type: 'ai_chat_lead',
          package_name: `1:1 Walkthrough (${leadForm.studio})`,
          price: 5000,
          payment_status: 'Unpaid / AI Chat Lead',
          platform: 'AI Chatbot',
          studio: leadForm.studio,
          project_type: leadForm.propertyType,
          plot_size: leadForm.area
        })
      });

      const data = await res.json();
      const ref = data.id || data.booking_id || Math.floor(1000 + Math.random() * 9000);

      setLeadForm((prev) => ({ ...prev, submitted: true, refId: ref }));
      setActiveFunnel(null);
      setIsTyping(false);

      setMessages((prev) => [
        ...prev,
        {
          id: Date.now(),
          sender: 'bot',
          text: `🎉 **VIP Appointment Request Received! (Ref: #WTP-${ref})**\n\nThank you, **${leadForm.name}**! Our senior spatial architect in **${leadForm.studio}** has been notified and is preparing sample 1:1 walkthrough video previews for your **${leadForm.propertyType}**.\n\nClick below to connect instantly on WhatsApp:`,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          showWhatsAppCTA: true,
          suggestions: ['Studio Packages & Pricing', 'Try Free 3D & VR Tool', 'Find studio near me']
        }
      ]);
    } catch (err) {
      setIsTyping(false);
      setActiveFunnel(null);
      setMessages((prev) => [
        ...prev,
        {
          id: Date.now(),
          sender: 'bot',
          text: `🎉 **Thank you, ${leadForm.name}!** We have noted your request. Please click below to send us a quick greeting on WhatsApp for instant VIP confirmation!`,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          showWhatsAppCTA: true,
          suggestions: ['Packages & Pricing', 'Find studio near me']
        }
      ]);
    }
  };

  const createWhatsAppUrl = (customText) => {
    const text = customText || `Hi Walk The Plan! I am on your website and would like to book a 1:1 Scale Floor Plan Walkthrough for my project.`;
    return `https://wa.me/${WHATSAPP_RAW}?text=${encodeURIComponent(text)}`;
  };

  // Helper to format bot markdown text cleanly
  const renderMessageContent = (msg) => {
    const formatted = msg.text
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.*?)\*/g, '<em>$1</em>')
      .replace(/\[(.*?)\]\((.*?)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer" style="color: #efc719; text-decoration: underline;">$1</a>');

    return (
      <div>
        <div dangerouslySetInnerHTML={{ __html: formatted }} style={{ whiteSpace: 'pre-line' }} />

        {/* Direct WhatsApp CTA Button */}
        {msg.showWhatsAppCTA && (
          <a
            href={createWhatsAppUrl(`Hi Walk The Plan! I just requested a 1:1 Walkthrough for my ${leadForm.propertyType} in ${leadForm.studio}. Please share slot details.`)}
            target="_blank"
            rel="noopener noreferrer"
            className="wtp-ai-whatsapp-cta"
          >
            <MessageCircle size={16} />
            Confirm on WhatsApp ({WHATSAPP_NUMBER})
          </a>
        )}
      </div>
    );
  };

  if (isLeadModalOpen) return null;

  return (
    <aside aria-label="AI Architectural Advisor" className="wtp-ai-widget-container">
      {/* 1. Closed State: Floating Launcher Button */}
      {!isOpen && (
        <>
          {showTeaser && (
            <div className="wtp-ai-teaser" onClick={handleOpenChat}>
              <button
                className="wtp-ai-teaser-close"
                onClick={(e) => {
                  e.stopPropagation();
                  setShowTeaser(false);
                }}
              >
                ×
              </button>
              <div style={{ fontWeight: 700, color: '#efc719', marginBottom: 4, display: 'flex', alignItems: 'center', gap: 6 }}>
                <Sparkles size={14} /> AI Architectural Advisor
              </div>
              👋 Thinking of building or renovating? Walk inside your floor plan at actual 1:1 scale before construction!
            </div>
          )}

          <button
            type="button"
            className="wtp-ai-launcher"
            onClick={handleOpenChat}
            aria-label="Open AI Architectural Advisor Chat"
          >
            <div className="wtp-ai-launcher-icon-wrap">
              <div className="wtp-ai-pulse-ring" />
              <Sparkles size={18} />
            </div>

            <div className="wtp-ai-launcher-text">
              <span className="wtp-ai-launcher-title">Architectural AI</span>
              <span className="wtp-ai-launcher-status">
                <span className="wtp-ai-status-dot" /> Online • 1:1 Advisor
              </span>
            </div>

            {unreadCount > 0 && <span className="wtp-ai-badge">{unreadCount}</span>}
          </button>
        </>
      )}

      {/* 2. Open State: Expanded Chat Window */}
      {isOpen && (
        <section aria-label="Walk The Plan AI Chat" className="wtp-ai-window">
          {/* Header */}
          <div className="wtp-ai-header">
            <div className="wtp-ai-header-left">
              <div className="wtp-ai-header-avatar">
                <Sparkles size={18} />
              </div>
              <div className="wtp-ai-header-info">
                <h4>
                  Walk The Plan AI <span className="wtp-ai-status-dot" />
                </h4>
                <p>1:1 Scale Spatial Blueprint Advisor</p>
              </div>
            </div>

            <div className="wtp-ai-header-actions">
              <a
                href={createWhatsAppUrl()}
                target="_blank"
                rel="noopener noreferrer"
                className="wtp-ai-header-btn"
                title="Direct WhatsApp"
              >
                <Phone size={15} />
              </a>
              <button
                type="button"
                className="wtp-ai-header-btn"
                onClick={handleCloseChat}
                title="Close Chat"
              >
                <X size={16} />
              </button>
            </div>
          </div>

          {/* Messages Thread */}
          <div className="wtp-ai-messages">
            {messages.map((msg) => (
              <div key={msg.id} className={`wtp-ai-msg ${msg.sender}`}>
                <div className="wtp-ai-bubble">{renderMessageContent(msg)}</div>
                <span className="wtp-ai-msg-time">{msg.time}</span>
              </div>
            ))}

            {/* Interactive Lead Funnel Card inside Chat */}
            {activeFunnel === 'booking' && (
              <div className="wtp-ai-lead-card">
                <div className="wtp-ai-lead-card-title">
                  <Building size={16} /> Step 1: Select Property Type
                </div>
                <div className="wtp-ai-lead-options">
                  {['Luxury Villa', 'Apartment/Flat', 'Commercial Office', 'Farmhouse'].map((type) => (
                    <button
                      key={type}
                      type="button"
                      className={`wtp-ai-lead-btn ${leadForm.propertyType === type ? 'active' : ''}`}
                      onClick={() => setLeadForm((prev) => ({ ...prev, propertyType: type }))}
                    >
                      {type}
                    </button>
                  ))}
                </div>

                <div className="wtp-ai-lead-card-title" style={{ marginTop: 6 }}>
                  <MapPin size={16} /> Step 2: Nearest Studio
                </div>
                <div className="wtp-ai-lead-options">
                  {['Gurugram HQ', 'Hyderabad', 'Dehradun', 'Varanasi'].map((st) => (
                    <button
                      key={st}
                      type="button"
                      className={`wtp-ai-lead-btn ${leadForm.studio === st ? 'active' : ''}`}
                      onClick={() => setLeadForm((prev) => ({ ...prev, studio: st }))}
                    >
                      {st}
                    </button>
                  ))}
                </div>

                <div className="wtp-ai-lead-card-title" style={{ marginTop: 6 }}>
                  <CheckCircle size={16} /> Step 3: Your Contact Details
                </div>
                <form onSubmit={handleFunnelSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                  <input
                    type="text"
                    placeholder="Your Full Name"
                    className="wtp-ai-lead-input"
                    value={leadForm.name}
                    onChange={(e) => setLeadForm({ ...leadForm, name: e.target.value })}
                    required
                  />
                  <input
                    type="tel"
                    placeholder="10-Digit Mobile / WhatsApp Number"
                    className="wtp-ai-lead-input"
                    value={leadForm.phone}
                    onChange={(e) => setLeadForm({ ...leadForm, phone: e.target.value })}
                    required
                  />
                  <button type="submit" className="wtp-ai-lead-submit">
                    Confirm VIP Slot Request <ArrowRight size={14} />
                  </button>
                </form>
              </div>
            )}

            {isTyping && (
              <div className="wtp-ai-typing">
                <div className="wtp-ai-typing-dot" />
                <div className="wtp-ai-typing-dot" />
                <div className="wtp-ai-typing-dot" />
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Quick Action Suggestion Chips */}
          <div className="wtp-ai-suggestions">
            {DEFAULT_SUGGESTIONS.map((sug, i) => (
              <button
                key={i}
                type="button"
                className="wtp-ai-chip"
                onClick={() => handleSend(sug)}
              >
                {sug}
              </button>
            ))}
          </div>

          {/* Input Bar */}
          <form
            className="wtp-ai-input-bar"
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
          >
            <input
              type="text"
              placeholder="Ask about 1:1 projection, pricing, locations..."
              className="wtp-ai-text-input"
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
            />
            <button
              type="submit"
              className="wtp-ai-send-btn"
              disabled={!inputMessage.trim()}
              title="Send Message"
            >
              <Send size={16} />
            </button>
          </form>
        </section>
      )}
    </aside>
  );
}
