import React, { lazy, Suspense } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { SettingsProvider } from './context/SettingsContext';

const AdminDashboard = lazy(() => import('./pages/AdminDashboard'));
const AdminLogin = lazy(() => import('./pages/AdminLogin'));
const FitscalezAdmin = lazy(() => import('./pages/FitscalezAdmin'));
const PublicLeadsPanel = lazy(() => import('./pages/PublicLeadsPanel'));

const ProtectedAdminRoute = ({ children }) => {
  const token = localStorage.getItem('token');
  if (!token) {
    return <Navigate to="/admin/login" replace />;
  }
  return children;
};

export default function App() {
  return (
    <SettingsProvider>
      <Router>
        <Suspense fallback={<div style={{ background: '#0a0a0c', height: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#f59e0b', fontFamily: 'monospace' }}>Loading Admin Dashboard...</div>}>
          <Routes>
            <Route path="/admin/login" element={<AdminLogin />} />
            <Route path="/login" element={<Navigate to="/admin/login" replace />} />
            <Route
              path="/admin"
              element={
                <ProtectedAdminRoute>
                  <AdminDashboard />
                </ProtectedAdminRoute>
              }
            />
            <Route path="/admin/public-leads" element={<PublicLeadsPanel />} />
            <Route path="/fitscalez" element={<FitscalezAdmin />} />
            <Route path="/" element={<Navigate to="/admin" replace />} />
            <Route path="*" element={<Navigate to="/admin" replace />} />
          </Routes>
        </Suspense>
      </Router>
    </SettingsProvider>
  );
}
