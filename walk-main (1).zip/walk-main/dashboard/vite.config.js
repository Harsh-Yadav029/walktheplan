import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

export default defineConfig({
  plugins: [react()],
  base: '/admin/',
  resolve: {
    alias: {
      '@/shared/context/SettingsContext': path.resolve(__dirname, './src/context/SettingsContext.jsx'),
      '@/admin/components/AdminSuspendedNotice': path.resolve(__dirname, './src/components/AdminSuspendedNotice.jsx'),
      '@/shared/components/BlueprintLoader': path.resolve(__dirname, './src/components/BlueprintLoader.jsx'),
      '@/shared/config/adminLock': path.resolve(__dirname, './src/config/adminLock.js'),
      '@/shared/utils/pushNotifications': path.resolve(__dirname, './src/utils/pushNotifications.js'),
      '@': path.resolve(__dirname, './src'),
    }
  },
  server: {
    port: 5176,
    proxy: {
      '/api': {
        target: 'http://localhost:5000',
        changeOrigin: true
      },
      '/uploads': {
        target: 'http://localhost:5000',
        changeOrigin: true
      }
    }
  }
});
